# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Setting Up the Project on a New System

Follow these steps to set up and run the project on a new system:

### 1. Install Node.js and npm

Download and install Node.js from the [official website](https://nodejs.org/). npm (Node Package Manager) is included with Node.js.

### 2. Open the Project

If you have received the project as a ZIP file:

1. Extract the ZIP file to a desired location.
2. Open the extracted folder in a terminal or command prompt.
3. Then goto step 4.

If you want to clone the repository from GitHub, run the following command:

```
git clone <repository-url>
```

Replace `<repository-url>` with the actual URL of your repository.

### 3. Navigate to the Project Directory

```
cd <project-folder>
```

Replace `<project-folder>` with your project directory name.

### 4. Install Dependencies

```
npm install
```

This will install all required node modules.

### 5. Start the Development Server

```
npm start
```

This runs the app in development mode.
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

Only install MUI if it gives error of MUI on running command (npm start)

### 6. Install Material-UI

Since this project uses Material-UI for UI components, install it using:

```
npm install @mui/material @emotion/react @emotion/styled
```

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.
The page will reload when you make changes.
You may also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified, and the filenames include the hashes.
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.

### `npm run eject`

**Note: this is a one-way operation. Once you `eject`, you can't go back!**

If you aren't satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (webpack, Babel, ESLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you're on your own.

You don't have to ever use `eject`. The curated feature set is suitable for small and middle deployments, and you shouldn't feel obligated to use this feature. However we understand that this tool wouldn't be useful if you couldn't customize it when you are ready for it.

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).

### Code Splitting

This section has moved here: [https://facebook.github.io/create-react-app/docs/code-splitting](https://facebook.github.io/create-react-app/docs/code-splitting)

### Analyzing the Bundle Size

This section has moved here: [https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size](https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size)

### Making a Progressive Web App

This section has moved here: [https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app](https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app)

### Advanced Configuration

This section has moved here: [https://facebook.github.io/create-react-app/docs/advanced-configuration](https://facebook.github.io/create-react-app/docs/advanced-configuration)

### Deployment

This section has moved here: [https://facebook.github.io/create-react-app/docs/deployment](https://facebook.github.io/create-react-app/docs/deployment)

### `npm run build` fails to minify

This section has moved here: [https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify](https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify)
