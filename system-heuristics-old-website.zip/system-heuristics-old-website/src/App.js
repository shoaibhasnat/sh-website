/*
Component Description: App

1. Root component with routes for Home, About, Services, etc.
2. Integrates AOS animations using `useEffect` and `AOS.init()`.
3. Supports light/dark themes with MUI's `ThemeProvider` and `toggleTheme`.
4. Lazily loads `Navbar` for performance.
5. Uses `HelmetProvider` for dynamic meta tags.
6. Layout constrained to 1550px width using `Box`.
7. Dynamic routes for project, industry, and service pages.
8. Fallback `NotFound` for undefined paths.
9. Renders `Main` with `toggleTheme` for theme switching.
*/

import { Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import About from "./pages/About";
import Careers from "./pages/Careers";
import Services from "./pages/Services/Services";
import Portfolio from "./pages/Portfolio/Portfolio";
import Industries from "./pages/Industries/Industries";
import ContactUs from "./pages/ContactUs";
import "./global.css";
import AOS from "aos";
import "aos/dist/aos.css";
import React, { useEffect, useState, Suspense } from "react";
import { Box, ThemeProvider, createTheme } from "@mui/material";
import CssBaseline from "@mui/material/CssBaseline";
import Main from "./components/Footer/Main";
import HealthCare from "./pages/Industries/SpecificIndustry";
import SpecificService from "./pages/Services/SpecificService";
import SpecificProject from "./pages/Portfolio/SpecificProject";
import NotFound from "./pages/NotFound";
import { HelmetProvider } from "react-helmet-async";

const LazyNavbar = React.lazy(() => import("./components/Navbar/Navbar"));
function App() {
  useEffect(() => {
    AOS.init({
      duration: 1000,
    });
  }, []);

  const [mode, setMode] = useState("light");

  const theme = createTheme({
    palette: {
      mode: mode,
    },
    typography: {
      fontFamily: "var(--font-family-primary)", // Use CSS variable
    },
  });

  const toggleTheme = () => {
    setMode((prevMode) => (prevMode === "light" ? "dark" : "light"));
  };

  return (
    <HelmetProvider>
      <ThemeProvider theme={theme}>
        <CssBaseline /> {/* Ensures background is consistent */}
        <Box maxWidth={"1550px"} mx={"auto"}>
          <Suspense fallback={<div>Loading Navbar...</div>}>
            <LazyNavbar />
          </Suspense>
        </Box>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/home" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/portfolio" element={<Portfolio />} />
          <Route path="/industries" element={<Industries />} />
          <Route path="/careers" element={<Careers />} />
          <Route path="/contact" element={<ContactUs />} />

          {/* Specific Industries  */}
          <Route path="/fintech" element={<HealthCare />} />
          <Route path="/healthcare" element={<HealthCare />} />
          <Route path="/real-estate" element={<HealthCare />} />
          <Route path="/logistics" element={<HealthCare />} />
          <Route path="/legal" element={<HealthCare />} />
          <Route path="/education" element={<HealthCare />} />

          {/* Specific Services  */}
          <Route path="/generative-ai" element={<SpecificService />} />
          <Route path="/machine-learning" element={<SpecificService />} />
          <Route path="/language-processing" element={<SpecificService />} />
          <Route path="/computer-vision" element={<SpecificService />} />
          <Route path="/data-analytics" element={<SpecificService />} />
          <Route path="/ai-driven-security" element={<SpecificService />} />

          {/* Specific Projects */}

          <Route path="/project/:projectId" element={<SpecificProject />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        <Main toggleTheme={toggleTheme} />
      </ThemeProvider>
    </HelmetProvider>
  );
}

export default App;
