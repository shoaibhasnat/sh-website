/*
AboutUs component description:

1. Introduces the company and its values.  
2. Loads dynamic content from `About.json`.  
3. Styled "Who We Are?" heading with responsive design.  
4. Displays `teamInfo` list with custom bullet icons.  
5. Hover effect shifts items for interactivity.  
6. Responsive layout using MUI Stack.  
7. Switches images based on light/dark theme.  
8. AOS animations enhance visual entrance.  
9. Uses MUI `sx` and CSS vars for styling.  
10. Semantic HTML and alt text for accessibility/SEO.
*/

import { Box, List, Stack, Typography, useTheme } from "@mui/material";
import React from "react";
import arrow from "../../images/arrowfilled.png";
import AboutData from "../About.json";
function AboutUs() {
  const aboutUsData = AboutData.aboutUs;
  const theme = useTheme();
  const isDarkMode = theme.palette.mode === "dark";

  return (
    <>
      <Stack
        direction={["column", "column", "row"]}
        justifyContent={"space-evenly"}
        alignItems={"center"}
        mt={[10, 10, 10]}
        mb={[10, 10, 20]}
        gap={[5, 5, 15]}
        mx={[3, 3, 5, 10]}
      >
        <Box data-aos="fade-right" maxWidth={["100%", "100%", "60%", "40%"]}>
          <Typography
            color="var(--color-primary)"
            fontWeight={600}
            fontSize={[
              "var(--font-sm)",
              "var(--font-sm)",
              "var(--font-md)",
              "var(--font-standard)",
            ]}
          >
            Who We Are?
          </Typography>
          <Typography
            fontSize={[
              "var(--font-md)",
              "var(--font-md)",
              "var(--font-standard)",
              "var(--font-lg)",
            ]}
            fontWeight={600}
            mb={1}
          >
            {aboutUsData.heading}
          </Typography>
          {aboutUsData.teamInfo.map((item, index) => (
            <Stack
              key={index}
              direction={"row"}
              justifyContent={"flex-start"}
              alignItems={"flex-start"}
              gap={1}
              textAlign={"justify"}
              mb={-1}
              sx={{
                ":hover": {
                  ml: 1,
                  cursor: "pointer",
                },
                transition: "margin-left 0.3s ease-in-out",
              }}
            >
              <Box height={30} width={30} mt={1}>
                <img src={arrow} alt="arrow" height={30} width={30} />
              </Box>

              <List
                sx={{
                  fontSize: {
                    xs: "var(--font-xs)",
                    sm: "var(--font-xs)",
                    md: "var(--font-xs)",
                    lg: "var(--font-sm)",
                  },
                }}
              >
                <strong>{item.title}: </strong> {item.description}
              </List>
            </Stack>
          ))}
        </Box>
        <Box data-aos="flip-left">
          <img
            style={{
              borderTop: "5px solid #1475ff",
            }}
            src={
              isDarkMode
                ? aboutUsData.darkModeImage
                : aboutUsData.lightModeImage
            }
            alt="About Us"
            height={"100%"}
            width={"100%"}
          />
        </Box>
      </Stack>
    </>
  );
}

export default AboutUs;
