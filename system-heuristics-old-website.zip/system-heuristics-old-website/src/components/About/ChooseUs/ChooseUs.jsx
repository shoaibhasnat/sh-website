/*
ChooseUs component description:

1. Renders the "Why Choose Us" section to highlight key company features.
2. Loads dynamic content (heading, description, image, reasons) from `About.json`.
3. Splits into two parts: static content panel (image & text) and dynamic feature cards.
4. Left panel (on large screens) remains sticky while scrolling the right section.
5. Displays feature cards with icons, animated headings, and AOS `fade-left` effects.
6. Uses MUI `Stack` and `Box` for responsive, consistent styling.
7. Typography and spacing managed via CSS variables for unified theming.
8. Gradient text animation applied to headings using CSS keyframes.
9. Adapts across screen sizes with flex wrap and responsive arrays.
10. Applies lazy loading to images for better performance.
*/

import { Box, Stack, Typography } from "@mui/material";
import React from "react";
import ChooseUsData from "../About.json";

function ChooseUs() {
  const whyChooseUsData = ChooseUsData?.chooseUs; //Fetching Industry Process data from Industries.json file

  return (
    // Main Container
    <Stack
      p={3}
      px={[1, 1, 5, 15]}
      py={10}
      my={10}
      direction={["column", "column", "row"]}
      justifyContent={"space-evenly"}
      gap={[3, 3, 3]}
      // bgcolor={"#f4f4f5"}
    >
      {/* How we work? Section  */}
      <Stack
        p={1}
        height={"100%"}
        minWidth={["100%", "100%", "45%"]}
        alignItems={"center"}
        position={["unset", "unset", "sticky"]}
        top={"2%"}
        px={[3, 10, 0]}
      >
        <Typography fontSize={"var(--heading)"} mb={1} mt={3}>
          {" "}
          {whyChooseUsData?.heading}
        </Typography>
        <Box
          component={"img"}
          height={["300px", "300px", "400px"]}
          width={["300px", "300px", "400px"]}
          src={whyChooseUsData?.chooseUsImage}
          alt="Why Choose Us"
          loading="lazy"
        ></Box>
        <Typography
          textAlign={"center"}
          fontSize={"var(--description)"}
          lineHeight={1.5}
          color="#898989"
        >
          {whyChooseUsData?.description}
        </Typography>
      </Stack>

      {/* Industry Process Steps Section */}
      <Stack
        p={1}
        gap={5}
        position={"relative"}
        zIndex={99}
        direction={["row"]}
        flexWrap={"wrap"}
        justifyContent={"center"}
        sx={{
          overflowX: "hidden",
        }}
      >
        {whyChooseUsData?.reasons.map((reason, index) => (
          <Stack
            key={index}
            data-aos="fade-left"
            justifyContent={"center"}
            alignItems={"flex-start"}
            gap={1}
            p={3}
            minHeight={200}
            maxWidth={[400, 300, 400, 600]}
            borderRadius={"var(--radius)"}
            bgcolor={"white"}
            boxShadow={3}
          >
            {/* <img src={reason.img} alt={reason.title} height={50} width={50} /> */}
            <Box
              height={50}
              width={50}
              borderRadius={"var(--rounded)"}
              bgcolor={"white"}
            >
              <img
                src={reason?.icon}
                alt={reason?.title}
                height={"100%"}
                width={"100%"}
                loading="lazy"
              />
            </Box>
            <Typography
              variant="h5"
              fontWeight={"bold"}
              sx={{
                background:
                  "linear-gradient(90deg, #62b6ff, #2769d9, #62b6ff,rgb(98, 145, 255))",
                backgroundSize: "300% 100%",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                animation: "gradientMove 4s ease-in-out infinite",
                "@keyframes gradientMove": {
                  "0%": { backgroundPosition: "0% 50%" },
                  "50%": { backgroundPosition: "100% 50%" },
                  "100%": { backgroundPosition: "0% 50%" },
                },
              }}
            >
              {reason.title}
            </Typography>
            <Typography color="#898989">{reason.content}</Typography>
          </Stack>
        ))}
      </Stack>
    </Stack>
  );
}

export default ChooseUs;
