/*
Collaborate component description:

1. Renders a call-to-action section for collaboration or contact.
2. Fetches dynamic content (image, title, description, button) from `About.json`.
3. Styled with a vibrant primary background and white text for contrast.
4. Displays a left-aligned, responsive image using MUI `Box`.
5. Title includes a FontAwesome phone icon for a contact-related visual cue.
6. Text alignment adjusts based on screen size using MUI’s responsive props.
7. Features a styled `Button` with hover effects for interaction feedback.
8. Uses `react-router-dom` for navigation, ensuring scroll-to-top on redirect.
9. AOS `flip-up` animation enhances visual appeal.
10. Mobile-friendly layout with `flexWrap` and responsive spacing.
*/

import { Box, Button, Stack, Typography } from "@mui/material";
import React from "react";
import AboutData from "../About.json";
import { faArrowRight, faPhone } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useNavigate } from "react-router-dom";

function Collaborate() {
  const collaborateData = AboutData.collaborate;

  const navigate = useNavigate();

  const handleClick = (path) => {
    navigate(path);
    window.scrollTo(0, 0);
  };

  return (
    <>
      <Stack
        data-aos="flip-up"
        direction={"row"}
        justifyContent={"space-evenly"}
        gap={[5, 2]}
        alignItems={"center"}
        borderRadius={"var(--radius)"}
        minHeight={400}
        mb={[10]}
        mx={[3, 3, 5, 25]}
        bgcolor={"var(--color-primary)"}
        color={"white"}
        flexWrap={"wrap"}
        px={2}
        py={[5, 5, 2]}
      >
        <Box height={200} width={200}>
          <img
            src={collaborateData.image}
            alt="Schedule"
            height={"100%"}
            width={"100%"}
          />
        </Box>

        <Box m={1} p={1} textAlign={["center", "left"]}>
          <Typography fontSize={20}>
            {" "}
            <FontAwesomeIcon icon={faPhone} size="lg" /> {collaborateData.title}
          </Typography>
          <Typography
            fontSize={"var(--font-sm)"}
            fontWeight={"var(--font-regular)"}
            mt={1}
            maxWidth={400}
          >
            {collaborateData.description}
          </Typography>
        </Box>
        <Button
          variant="Outlined"
          sx={{
            borderRadius: "var(--rounded)",
            textTransform: "none",
            bgcolor: "white",
            px: 3,
            color: "black",
            transition: "0.2s ease-in-out",
            fontSize: "var(--font-sm)",
            border: "2px solid white",
            ":hover": {
              bgcolor: "var(--color-primary)",
              color: "white",
              border: "2px solid white",
              fontWeight: "semi-bold",
            },
          }}
          onClick={() => handleClick("/contact")}
        >
          {collaborateData.buttonText}
          <FontAwesomeIcon style={{ marginLeft: 5 }} icon={faArrowRight} />
        </Button>
      </Stack>
    </>
  );
}

export default Collaborate;
