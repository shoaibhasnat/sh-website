/*
Main component description:

1. Serves as the entry point for rendering the About page layout.
2. Composes multiple feature sections for a complete company narrative.
3. <Banner /> introduces the page with a visual header or mission statement.
4. <AboutUs /> provides an overview or background of the organization.
5. <Principles /> outlines core values and guiding beliefs.
6. <OurExpertise /> highlights technical and business specialties.
7. <ChooseUs /> presents reasons to select the company.
8. <OurTeam /> showcases team members and their roles.
9. <Milestones /> displays major achievements and company timeline.
10. <Testimonials /> builds credibility with customer feedback, while <Collaborate /> invites engagement.
*/

import React from "react";
import Principles from "./Principles/Principles";
import Collaborate from "./Collaborate/Collaborate";
// import OurTeam from "./OurTeam/OurTeam";
import OurExpertise from "./OurExperties/OurExperties";
import Testimonials from "./Testimonials/Testimonials";
import ChooseUs from "./ChooseUs/ChooseUs";
import Milestones from "./Milestones/Milestones";
import AboutUs from "./AboutUs/AboutUs";
import Banner from "./Banner/Banner";

function Main() {
  return (
    <>
      <Banner />
      <AboutUs />
      <Principles />
      <OurExpertise />
      <ChooseUs />
      {/* <OurTeam /> */}
      <Milestones />
      <Testimonials />
      <Collaborate />
    </>
  );
}

export default Main;
