/*
Milestones component description:

1. Displays company milestones with animated numerical statistics.
2. Fetches milestone data (count, suffix, description) from `About.json`.
3. Uses `react-countup` to animate numbers incrementing from 0.
4. Triggers animation using `react-intersection-observer` when 20% visible.
5. Each milestone card has a shadowed container and hover animations.
6. Uses AOS `zoom-in-down` animation for smooth fade-in effects.
7. `clip-path` hover effect expands a background circle with color inversion.
8. Wrapped in a responsive `Stack` with `flexWrap` for adaptability.
9. Typography and spacing managed via MUI props and CSS variables.
10. Optimized for performance and accessibility with lazy rendering.
*/

import { Box, Stack, Typography } from "@mui/material";
import React from "react";
import CountUp from "react-countup";
import { useInView } from "react-intersection-observer";
import AboutData from "../About.json";

const Milestones = () => {
  const milestonesData = AboutData.milestones;

  const { ref, inView } = useInView({
    triggerOnce: true, // Animation triggers only once
    threshold: 0.2, // Percentage of the component visible in the viewport before triggering
  });

  return (
    <>
      <Typography textAlign={"center"} fontSize={"var(--heading)"} pb={5}>
        Milestones And Achievements
      </Typography>
      <Stack
        mb={[10, 10, 20]}
        ref={ref}
        direction={"row"}
        flexWrap={"wrap"}
        justifyContent={"space-evenly"}
        alignItems={"center"}
        px={[3, 3, 3, 10]}
        gap={[3, 3, 3, 1]}
      >
        {milestonesData.cards.map((card, index) => (
          <Stack
            data-aos="zoom-in-down"
            key={index}
            className="container"
            boxShadow={10}
            height={150}
            width={250}
            alignItems={"center"}
            justifyContent={"center"}
          >
            <Box className="content" textAlign={"center"}>
              <Typography variant="h3" fontWeight={600}>
                {inView && (
                  <CountUp
                    start={0}
                    end={card.count}
                    duration={5}
                    suffix={card.suffix}
                  />
                )}
              </Typography>
              <Typography variant="h6">{card.description}</Typography>
            </Box>
          </Stack>
        ))}
      </Stack>

      <style>{`

        .container {
          background: white;
          cursor: pointer;
          border-radius: var(--radius);
          position: relative;
          padding: 20px 30px;
          color: var(--color-primary);
          overflow: hidden;
        }

        .container::after {
          content: '';
          background: var(--color-primary);
          border-radius: var(--radius);
          height: 100%;
          width: 100%;
          position: absolute;
          left: 0;
          top: 0;
          z-index: 0;
          clip-path: circle(20% at 0% 0%);
          transition: all 0.3s ease-in;
        }

        .content {
          position: relative;
          z-index: 1;
          transition: all 0.3s ease-in;
        }

        .container:hover::after {
          clip-path: circle(100%);
        }

        .container:hover .content {
          color: white;
        }
      `}</style>
    </>
  );
};

export default Milestones;
