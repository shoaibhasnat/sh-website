/*
OurExpertise component description:

1. Displays key technical and domain expertise areas.
2. Fetches structured data (title, icon, route, button text) from `About.json`.
3. Uses MUI’s `Grid` for a responsive layout with up to 3 items per row.
4. Expertise boxes include FontAwesome icons with `fa-bounce` hover effects.
5. Cards have interactive hover effects for background and text color.
6. Clicking a card navigates via `react-router-dom` and scrolls to the top.
7. Includes a styled button linking to the full services page with animations.
8. Adapts colors dynamically using MUI’s `useTheme` for dark/light modes.
9. Accessibility features like `alt` text and tooltips enhance usability.
10. AOS `flip-left` animation adds smooth entrance effects on scroll.
*/

import React from "react";
import {
  Grid,
  Typography,
  Box,
  Stack,
  Button,
  useTheme,
  Tooltip,
} from "@mui/material";
import arrowIcon from "../../images/arrow-icon.png";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faBrain,
  faDesktop,
  faHeadSideVirus,
  faLock,
  faMagnifyingGlassChart,
  faMicrochip,
} from "@fortawesome/free-solid-svg-icons";
import AboutData from "../About.json";
import { useNavigate } from "react-router-dom";

const iconMapping = {
  faBrain: faBrain,
  faMicrochip: faMicrochip,
  faHeadSideVirus: faHeadSideVirus,
  faDesktop: faDesktop,
  faMagnifyingGlassChart: faMagnifyingGlassChart,
  faLock: faLock,
};

const OurExpertise = () => {
  const expertiseData = AboutData.ourExpertise;
  const theme = useTheme(); // Access the theme to detect mode

  const navigate = useNavigate();

  const handleClick = (path) => {
    navigate(path);
    window.scrollTo(0, 0);
  };
  return (
    <Box
      sx={{
        padding: "40px",

        backgroundColor: theme.palette.mode === "dark" ? "#121212" : "#f9f9f9",
      }}
      mb={[10]}
    >
      <Typography
        fontSize={"var(--heading)"}
        align="center"
        gutterBottom
        pb={5}
      >
        Our Expertise
      </Typography>
      <Grid
        container
        sx={{ borderRadius: "var(--radius)" }}
        width={["100%", "100%", "100%", "70%"]}
        mx={"auto"}
      >
        {expertiseData.expertise.map((item, index) => (
          <Grid
            p={3}
            item
            xs={12}
            sm={4} // Ensure 3 items per row
            sx={{
              borderBottom: {
                xs: "none",
                sm:
                  index < expertiseData.expertise.length - 3
                    ? "2px solid #ddd"
                    : "transparent",
              },
              borderRight: {
                xs: "none",
                sm: (index + 1) % 3 !== 0 ? "2px solid #ddd" : "transparent",
              },
            }}
            key={index}
          >
            <Stack
              onClick={() => handleClick(item.route)}
              data-aos="flip-left"
              justifyContent={"center"}
              alignItems={"center"}
              spacing={5}
              sx={{
                padding: "20px",
                textAlign: "center",
                backgroundColor: "#fff",
                transition: "0.2s ease-in-out",
                color: "black",
                "&:hover": {
                  bgcolor: "var(--color-primary)",

                  color: "white",
                  borderRadius: "var(--radius)",
                  cursor: "pointer",
                },
              }}
              className="hover-bounce"
            >
              <FontAwesomeIcon
                icon={iconMapping[item.icon]}
                size="3x"
                style={{
                  "fa-bounce-height": 0.5,
                  "fa-bounce-start-scale-x": 1,
                  "fa-bounce-start-scale-y": 1,
                  "fa-bounce-jump-scale-x": 1,
                  "fa-bounce-jump-scale-y": 1,
                  "fa-bounce-land-scale-x": 1,
                  "fa-bounce-land-scale-y": 1,
                  "fa-bounce-rebound": 0,
                }}
              />
              <style>
                {`
          .hover-bounce:hover {
            animation: fa-bounce 1.5s ;

            }
            `}
              </style>
              <Typography variant="h6" fontWeight={"bold"}>
                {item.title}
              </Typography>
            </Stack>
          </Grid>
        ))}
      </Grid>

      <Tooltip title="View More Services" arrow>
        <Button
          sx={{
            mt: 3,
            marginX: "auto",
            borderRadius: "var(--rounded)",
            overflow: "hidden",
            position: "relative",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "5px 10px 5px 15px",
            fontWeight: "bold",
            textTransform: "none",
            "&:hover .img-container": {
              transform: "translateX(-50%)",
            },
            bgcolor: "var(--color-primary)",
          }}
          variant="contained"
          size="large"
          onClick={() => handleClick("/services")}
        >
          {expertiseData.buttonText}
          <Box
            className="img-container"
            sx={{
              borderRadius: "var(--rounded)",
              height: 30,
              width: 30,
              border: 1,
              bgcolor: "white",
              ml: 5,
              mr: -2,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              transition: "transform 0.3s ease-in-out",
              transform: "translateX(-100%)",
            }}
          >
            <img
              src={arrowIcon}
              alt="Let's talk"
              height={"100%"}
              width={"100%"}
              style={{ display: "block" }}
            />
          </Box>
        </Button>
      </Tooltip>
    </Box>
  );
};

export default OurExpertise;
