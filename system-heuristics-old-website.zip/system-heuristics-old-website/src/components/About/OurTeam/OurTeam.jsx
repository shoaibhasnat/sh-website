/*
OurTeam component description:

1. Displays team members in a `react-slick` carousel slider.
2. Fetches team data (name, role, image) dynamically from `About.json`.
3. Adjusts visible slides based on screen width (1 to 4 per view).
4. Cards have hover effects that scale and enhance visibility.
5. Features a modern diagonal-rounded border radius design.
6. Uses FontAwesome arrows for manual carousel navigation.
7. Autoplay pauses when hovering to prevent unwanted slides.
8. Background images improve performance with smooth transitions.
9. Wrapped in a Stack for responsive structure and spacing.
10. AOS `fade-up` and `flip-left` animations enhance visual appeal.
*/

import React from "react";
import Slider from "react-slick";
import { Card, Typography, Box, Stack } from "@mui/material";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircleArrowLeft } from "@fortawesome/free-solid-svg-icons";
import { useState } from "react";
import AboutData from "../About.json";

const OurTeam = () => {
  const ourTeamData = AboutData.ourTeam;
  const sliderRef = React.useRef(null);

  const [isHovered, setIsHovered] = useState(false);

  const settings = {
    dots: false,
    arrows: false,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 300000,
    responsive: [
      {
        breakpoint: 1500,
        settings: {
          slidesToShow: 4,
        },
      },
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 900,
        settings: {
          slidesToShow: 1,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  };

  const handlePrev = () => {
    sliderRef.current.slickPrev();
  };

  const handleNext = () => {
    if (!isHovered) {
      sliderRef.current.slickNext();
    }
  };

  return (
    <>
      <Typography fontSize={"var(--heading)"} align="center" py={3}>
        Meet Our <span style={{ color: "var(--color-primary)" }}>Team</span>
      </Typography>
      <Stack
        data-aos="fade-up"
        px={[2, 10, 10, 10, 20]}
        mb={[10]}
        direction={"row"}
        alignItems={"center"}
        justifyContent={"center"}
      >
        <FontAwesomeIcon
          icon={faCircleArrowLeft}
          size="2x"
          style={{ color: "var(--color-primary)", cursor: "pointer" }}
          onClick={handlePrev}
        />
        <Stack
          sx={{
            maxWidth: {
              xs: "250px",
              sm: "310px",
              md: "800px",
              lg: "1100px",
              xl: "1200px",
            },
            margin: "auto",
            padding: "20px",
            position: "relative",
          }}
        >
          <Slider ref={sliderRef} {...settings}>
            {ourTeamData.teamMembers.map((member, index) => (
              <Box
                key={index}
                sx={{ padding: "20px 10px 20px 10px" }}
                data-aos="flip-left"
              >
                <Card
                  sx={{
                    border: "1px solid white",
                    minHeight: {
                      xs: 280,
                      md: 320,
                      lg: 350,
                      xl: 355,
                    },
                    minWidth: {
                      xs: 180,
                      md: 220,
                      lg: 250,
                      xl: 255,
                    },
                    p: 1,
                    bgcolor: "white",
                    color: "white",
                    position: "relative",
                    borderTopLeftRadius: 60,
                    borderTopRightRadius: 0,
                    borderBottomRightRadius: 60,
                    borderBottomLeftRadius: 0,
                    boxShadow: 6,

                    transition: "transform 0.3s ease, filter 0.3s ease",
                    "&:hover": {
                      transform: "scale(1.05)",
                    },
                    "&:hover .nameArea": {
                      filter: "brightness(1)",
                    },
                  }}
                  onMouseEnter={() => setIsHovered(true)}
                  onMouseLeave={() => setIsHovered(false)}
                >
                  <Box
                    sx={{
                      minHeight: {
                        xs: 280,
                        md: 320,
                        lg: 350,
                        xl: 350,
                      },
                      minWidth: {
                        xs: 180,
                        md: 220,
                        lg: 250,
                        xl: 250,
                      },
                      bgcolor: "white",
                      color: "white",
                      backgroundImage: `url(${member.profile})`,
                      backgroundSize: "cover",
                      backgroundPosition: "center",
                      backgroundRepeat: "no-repeat",
                      objectFit: "cover",
                      borderTopLeftRadius: 60,
                      borderTopRightRadius: 0,
                      borderBottomRightRadius: 60,
                      borderBottomLeftRadius: 0,
                    }}
                  ></Box>
                  <Box
                    className="nameArea"
                    bottom={0}
                    position={"absolute"}
                    width={"100%"}
                    bgcolor={"rgba(0, 0, 0, 0.5)"}
                    my={1}
                    mx={[1, 1, 5]}
                    pl={3}
                    color={"white"}
                    borderRadius={10}
                  >
                    <Typography
                      fontSize={[
                        "var(--font-md)",
                        "var(--font-md)",
                        "var(--font-standard)",
                      ]}
                      fontWeight={"bold"}
                    >
                      {member.name}
                    </Typography>
                    <Typography
                      fontSize={[
                        "var(--font-xs)",
                        "var(--font-sm)",
                        "var(--font-sm)",
                      ]}
                    >
                      {member.role}
                    </Typography>
                  </Box>
                </Card>
              </Box>
            ))}
          </Slider>{" "}
        </Stack>
        <FontAwesomeIcon
          icon={faCircleArrowLeft}
          size="2x"
          style={{ color: "var(--color-primary)", cursor: "pointer" }}
          rotation={180}
          onClick={handleNext}
        />
      </Stack>
    </>
  );
};

export default OurTeam;
