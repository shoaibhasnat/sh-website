/*
Principles component description:

1. Displays Mission, Vision, and Values in an interactive rotating slider.
2. Loads principle data (title, image, content) from `About.json`.
3. Auto-transitions between slides every 3 seconds using `useState` & `useEffect`.
4. Pauses auto-slide when the user hovers over a slide.
5. Enables manual navigation with FontAwesome chevron icons.
6. Uses a circular conic-gradient background for distinct styling.
7. Clips images into circles matching the gradient and border.
8. Formats `Mission` text with line breaks for better readability.
9. Applies AOS `fade-up` animation for smooth entry effects.
10. Ensures responsiveness using MUI’s `Stack`, `Box`, and Typography.
*/

import React, { useState, useEffect } from "react";
import { Box, Stack, Typography } from "@mui/material";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faChevronUp } from "@fortawesome/free-solid-svg-icons";
import AboutData from "../About.json";

const Principles = () => {
  const principlesData = AboutData.principles;

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const nextSlide = () => {
    setCurrentIndex(
      (prevIndex) => (prevIndex + 1) % principlesData.items.length
    );
  };

  const prevSlide = () => {
    setCurrentIndex(
      (prevIndex) =>
        (prevIndex - 1 + principlesData.items.length) %
        principlesData.items.length
    );
  };

  useEffect(() => {
    if (!isPaused) {
      const interval = setInterval(nextSlide, 3000);
      return () => clearInterval(interval);
    }
  });

  return (
    <>
      <Typography fontSize={"var(--heading)"} textAlign={"center"} pb={3}>
        Our Principles
      </Typography>
      <Stack
        data-aos="fade-up"
        mb={[10, 10, 20]}
        direction={"row"}
        justifyContent={"space-between"}
        alignItems={"center"}
        px={[2, 2, 5, 10, 20]}
      >
        <Box
          border={"1px solid white"}
          position="relative"
          overflow="hidden"
          display="flex"
          alignItems="center"
          width="100%"
          minHeight={["400px", "350px", "400px"]}
          boxShadow={10}
          borderRadius={["var(--radius)", "var(--radius)", "var(--radius)"]}
        >
          {principlesData.items.map((item, index) => (
            <Stack
              key={index}
              direction={"row"}
              justifyContent={"space-between"}
              alignItems={"center"}
              textAlign={"center"}
              px={2}
              sx={{
                position: "absolute",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                opacity: index === currentIndex ? 1 : 0,
                transition: "opacity 0.5s ease-in-out",
              }}
              onMouseEnter={() => setIsPaused(true)}
              onMouseLeave={() => setIsPaused(false)}
            >
              {" "}
              <FontAwesomeIcon
                icon={faChevronUp}
                rotation={270}
                size="lg"
                onClick={prevSlide}
                style={{
                  cursor: "pointer",
                }}
              />
              <Stack
                direction={["column", "column", "row"]}
                justifyContent={["center", "center", "space-evenly"]}
                alignItems={"center"}
              >
                <Stack
                  display={["none", "none", "flex"]}
                  direction={"row"}
                  justifyContent={"center"}
                  alignItems={"center"}
                  sx={{
                    width: 200,
                    height: 200,
                    borderRadius: "50%",
                    background:
                      item.title === "Mission"
                        ? "conic-gradient(#d90b06 0% 25%, #fff 25% 50%, #d90b06 50% 75%, #fff 75% 100%)"
                        : item.title === "Vision"
                        ? "conic-gradient(black 0% 25%, #fff 25% 50%, black 50% 75%, #fff 75% 100%)"
                        : item.title === "Values"
                        ? "conic-gradient(var(--color-primary) 0% 25%, #fff 25% 50%, var(--color-primary) 50% 75%, #fff 75% 100%)"
                        : "white",
                  }}
                >
                  <Box
                    border={
                      item.title === "Mission"
                        ? "10px solid #d90b06"
                        : item.title === "Vision"
                        ? "10px solid black"
                        : item.title === "Values"
                        ? "10px solid var(--color-primary)"
                        : "10px solid white"
                    }
                    sx={{
                      width: "90%",
                      height: "90%",
                      borderRadius: "50%",
                      background: "white",
                      borderTopWidth: 10,
                      borderLeftWidth: 0,
                      borderRightWidth: 0,
                      borderBottomWidth: 10,
                      overflow: "hidden",
                    }}
                  >
                    <img
                      src={item.image}
                      alt={item.title}
                      height={"100%"}
                      width={"100%"}
                      style={{
                        borderRadius: "100%",
                      }}
                    />
                  </Box>
                </Stack>
                <Box
                  maxWidth={["100%", "90%", "60%"]}
                  p={2}
                  pt={3}
                  borderRadius={"var(--radius)"}
                  textAlign={"justify"}
                  fontSize={[
                    "var(--font-lg)",
                    "var(--font-lg)",
                    "var(--font-xl)",
                  ]}
                >
                  <span
                    style={{
                      fontWeight: "var(--font-regular)",
                      borderTop:
                        item.title === "Mission"
                          ? "5px solid #d90b06"
                          : item.title === "Vision"
                          ? "5px solid black"
                          : item.title === "Values"
                          ? "5px solid var(--color-primary)"
                          : "5px solid white",
                    }}
                  >
                    {item.title}
                  </span>
                  <Typography
                    fontSize={[
                      "var(--font-xs)",
                      "var(--font-xs)",
                      "var(--font-sm)",
                    ]}
                  >
                    {index === 0 ? (
                      item.content.split(".").map((sentence, index) => (
                        <React.Fragment key={index}>
                          {sentence.trim()}
                          {sentence && <br />}
                        </React.Fragment>
                      ))
                    ) : (
                      <React.Fragment>{item.content}</React.Fragment>
                    )}
                  </Typography>
                </Box>
              </Stack>
              <FontAwesomeIcon
                icon={faChevronUp}
                size="lg"
                rotation={90}
                onClick={nextSlide}
                style={{
                  cursor: "pointer",
                }}
              />
            </Stack>
          ))}
        </Box>
      </Stack>
    </>
  );
};

export default Principles;
