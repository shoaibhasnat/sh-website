/*
TestimonialSection component description:

1. Displays client testimonials in an auto-rotating slider with manual navigation.
2. Loads dynamic testimonial data (image, content, name, rating, location) from `About.json`.
3. Uses `useState` & `useEffect` for auto-slide every 3 seconds, pausing on hover.
4. Enables manual navigation with FontAwesome chevron icons.
5. Client images are styled within a double-layered circular frame.
6. Includes italicized feedback, bold name, dynamic star rating, and location.
7. Uses a helper function to render filled/unfilled stars based on rating.
8. Background has a themed image with a primary color overlay for contrast.
9. Smooth transitions via CSS opacity changes for fade-in/fade-out effects.
10. Ensures responsiveness using MUI’s `Box` and `Stack` components.
*/

import React from "react";
import { Box, Stack, Typography } from "@mui/material";
// import startingQuote from "../../images/About-Testimonials-StartingQuote.png";
// import endingQuote from "../../images/About-Testimonials-EndingQuote.png";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircleChevronLeft, faStar } from "@fortawesome/free-solid-svg-icons";
import { useEffect } from "react";
import { useState } from "react";
import AboutData from "../About.json";

const TestimonialSection = () => {
  const testimonialsData = AboutData.testimonials;

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonialsData.length);
  };

  const prevSlide = () => {
    setCurrentIndex(
      (prevIndex) =>
        (prevIndex - 1 + testimonialsData.length) % testimonialsData.length
    );
  };

  useEffect(() => {
    if (!isPaused) {
      const interval = setInterval(nextSlide, 3000);
      return () => clearInterval(interval);
    }
  });

  // Dynamic Rating Function
  const renderStars = (rating) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <FontAwesomeIcon
          key={i}
          icon={faStar}
          color={i <= rating ? "#FFEE00" : "lightgray"} // Yellow for filled stars, light gray for empty
        />
      );
    }
    return stars;
  };

  return (
    <>
      <Box
        pt={5}
        color={"white"}
        bgcolor={"var(--color-primary)"}
        sx={{
          backgroundImage: "url('/images/Testimonials-Bg.avif')", // Background image for larger screens

          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      >
        <Typography fontSize={"var(--heading)"} textAlign={"center"}>
          Testimonials
        </Typography>
        <Typography
          fontSize={"var(--description)"}
          textAlign={"center"}
          // color="grey"
          pb={1}
        >
          See what Our Client Say's
        </Typography>
        <Stack
          data-aos="zoom-in"
          mb={[10, 10, 10]}
          direction={"row"}
          justifyContent={"space-between"}
          alignItems={"center"}
          mx={["1%", "3%", "5%", "18%"]}
        >
          <FontAwesomeIcon
            icon={faCircleChevronLeft}
            style={{
              color: "white",
              // color: "var(--color-primary)",
              cursor: "pointer",
            }}
            size="2x"
            onClick={currentIndex === 0 ? undefined : prevSlide}
          />
          {/* Testimonials Box  */}
          <Box
            position="relative"
            overflow="hidden"
            display="flex"
            alignItems="center"
            width="100%"
            height={["600px", "600px", "400px"]}
          >
            {testimonialsData.map((item, index) => (
              <Stack
                direction={"row"}
                justifyContent={"space-evenly"}
                alignItems={"center"}
                key={index}
                sx={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  right: 0,
                  bottom: 0,
                  opacity: index === currentIndex ? 1 : 0,
                  transition: "opacity 0.5s ease-in-out",

                  textAlign: "center",
                }}
                onMouseEnter={() => setIsPaused(true)}
                onMouseLeave={() => setIsPaused(false)}
              >
                <Stack
                  direction={["column", "column", "row"]}
                  justifyContent={"center"}
                  alignItems={["center", "center", "flex-start"]}
                  gap={[10, 10, 20]}
                >
                  <Box
                    ml={[-10]}
                    width={["150px", "150px", "160px"]}
                    height={["150px", "150px", "160px"]}
                    sx={{
                      backgroundColor: "white",
                      borderRadius: "50%",
                      position: "relative",
                      zIndex: 1,
                    }}
                  >
                    <Box
                      width={["200px", "200px", "200px"]}
                      height={["200px", "200px", "200px"]}
                      sx={{
                        mt: "12%",
                        ml: "20%",
                        backgroundColor: "white",
                        borderRadius: "50%",
                        position: "relative",
                        zIndex: 2,
                      }}
                    >
                      <Box
                        component="img"
                        src={item.profile}
                        loading="lazy"
                        alt=""
                        mt={["10%", "10%", "10%"]}
                        sx={{
                          zIndex: 3,
                          borderRadius: "100%",
                          borderTop: "3px solid white",
                          borderLeft: "3px solid white",
                          borderRight: "3px solid white",
                          backgroundColor: "#E4F2FF",
                          height: {
                            xs: 180,
                            sm: 180,
                            md: 180,
                          },
                          width: {
                            xs: 180,
                            sm: 180,
                            md: 180,
                          },
                        }}
                      />
                    </Box>
                  </Box>

                  {/* Testimonial Content */}
                  <Box textAlign={["center", "center", "left"]}>
                    <Typography
                      variant="body1"
                      sx={{
                        fontStyle: "italic",
                        maxWidth: "500px",
                      }}
                      component={"span"}
                    >
                      "{item.content}"
                    </Typography>
                    <Typography
                      mt={1}
                      variant="h4"
                      sx={{
                        fontWeight: "var(--font-bold)",
                        color: "white",
                        // color: "var(--color-primary)",
                      }}
                    >
                      {item.name}
                    </Typography>
                    {/* Stars */}

                    <Stack
                      direction={"row"}
                      my={1}
                      justifyContent={["center", "center", "flex-start"]}
                    >
                      {renderStars(item.rating)}{" "}
                    </Stack>

                    <Typography
                      fontSize={"var(--font-xs)"}
                      // sx={{ color: "gray" }}
                    >
                      {item.location}
                    </Typography>
                  </Box>
                </Stack>
              </Stack>
            ))}
          </Box>

          <FontAwesomeIcon
            icon={faCircleChevronLeft}
            style={{
              color: "white",
              // color: "var(--color-primary)",
              cursor: "pointer",
            }}
            size="2x"
            rotation={180}
            onClick={nextSlide}
          />
        </Stack>{" "}
      </Box>
    </>
  );
};

export default TestimonialSection;
