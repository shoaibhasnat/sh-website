/*
Banner Component Description

1. Renders a full-screen banner for the careers page with an animated background.
2. Uses Material-UI components, Lottie for animation, and JSON data for dynamic content.
3. Background animation includes floating circular elements via pure CSS.
4. Adapts background color based on the current theme (dark/light) using MUI’s theme hook.
5. Structured with a responsive Stack layout for different screen sizes.
6. Fetches heading and description dynamically from a JSON file.
7. Includes a call-to-action button with smooth scrolling and animated styling.
8. Displays a Lottie animation on the right, resizing responsively.
9. Uses inline styles and styled-components for better responsiveness.
10. Ensures text content stays above background elements with z-index and positioning.
*/

import { Box, Link, Stack, Typography, useTheme } from "@mui/material";
import React from "react";
import styled from "styled-components";
import animationData from "./Careers-Banner-Animation.json";
import CareersData from "../Careers.json"; // Import the JSON file
import Lottie from "react-lottie-player";

function Banner() {
  const careersData = CareersData.banner;
  const theme = useTheme(); // Access the theme to detect mode
  return (
    <>
      <Box
        // mt={7}
        pt={[7, 7, 0]}
        height={"100vh"}
        position={"relative"}
        overflow={"hidden"}
        bgcolor={theme.palette.mode === "dark" ? "black" : "#F0F8FF"}
      >
        {/* Background animation */}

        <style>{`
        .circles {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          overflow: hidden;
          margin: 0;
          padding: 0;
          list-style: none;
          }
          
          
          .circles li {
            border-radius:100%;
          position: absolute;
          display: block;
          width: 20px;
          height: 20px;
          background: var(--color-primary);
          bottom: -150px;
          animation: animate 25s linear infinite;
        }

        .circles li:nth-child(1) {
          left: 5%;
          width: 80px;
          height: 80px;
          animation-delay: 0s;
        }

        .circles li:nth-child(2) {
          left: 10%;
          width: 80px;
          height: 80px;
          animation-delay: 2s;
          animation-duration: 12s;
        }

        .circles li:nth-child(3) {
          left: 15%;
          width: 20px;
          height: 20px;
          animation-delay: 4s;
        }

        .circles li:nth-child(4) {
          left: 20%;
          width: 60px;
          height: 60px;
          animation-delay: 0s;
          animation-duration: 8s;
        }

        .circles li:nth-child(5) {
          left: 25%;
          width: 20px;
          height: 20px;
          animation-delay: 6s;
          animation-duration: 5s;
        }

        .circles li:nth-child(6) {
          left: 30%;
          width: 110px;
          height: 110px;
          animation-delay: 3s;
          animation-duration: 18s;
        }

        .circles li:nth-child(7) {
          left: 60%;
          width: 150px;
          height: 150px;
          animation-delay: 7s;
        }

        .circles li:nth-child(8) {
          left: 40%;
          width: 25px;
          height: 25px;
          animation-delay: 15s;
          animation-duration: 45s;
        }

        .circles li:nth-child(9) {
          left: 45%;
          width: 15px;
          height: 15px;
          animation-delay: 12s;
          animation-duration: 35s;
        }

        .circles li:nth-child(10) {
          left: 10%;
          width: 150px;
          height: 150px;
          animation-delay: 0s;
          animation-duration: 10s;
        }
        .circles li:nth-child(11) {
          left: 55%;
          width: 15px;
          height: 15px;
          animation-delay: 14s;
          animation-duration: 53s;
        }
           .circles li:nth-child(12) {
          left: 60%;
          width: 15px;
          height: 15px;
          animation-delay: 2s;
          animation-duration: 15s;
        }
           .circles li:nth-child(13) {
          left: 65%;
          width: 25px;
          height: 25px;
          animation-delay: 15s;
          animation-duration: 5s;
        }
        .circles li:nth-child(14) {
          left: 50%;
          width: 70px;
          height: 70px;
          animation-delay: 7s;
        }

        .circles li:nth-child(15) {
          left: 98%;
          width: 110px;
          height: 110px;
          animation-delay: 3s;
          animation-duration: 25s;
        }
  .circles li:nth-child(16) {
          left: 80%;
          width: 20px;
          height: 20px;
          animation-delay: 0s;
        }
         .circles li:nth-child(17) {
          left: 85%;
          width: 60px;
          height: 60px;
          animation-delay: 0s;
          animation-duration: 18s;
        }

  .circles li:nth-child(18) {
          left: 90%;
          width: 20px;
          height: 20px;
          animation-delay: 4s;
        }
    .circles li:nth-child(19) {
          left: 95%;
          width: 20px;
          height: 20px;
          animation-delay: 2s;
          animation-duration: 12s;
        }
 
        @keyframes animate {
          0% {
            transform: translateY(0) rotate(0deg);
            opacity: 1;
            border-radius: 100%;
          
          }
          
          100% {
            transform: translateY(-1000px) rotate(720deg);
            opacity: 0;
            border-radius: 100%;  
          
          }
        }
      `}</style>
        <ul className="circles">
          {[...Array(20)].map((_, index) => (
            <li key={index}></li>
          ))}
        </ul>
        <Stack
          mx={[1, 5, 2, 10]}
          color={theme.palette.mode === "dark" ? "white" : "black"}
          direction={["column", "column", "row"]}
          justifyContent={"center"}
          alignItems={"center"}
          height={"100%"}
          zIndex={1}
          position={"absolute"}
          gap={1}
          mt={["15%", "15%", 0]}
        >
          <Stack px={2} maxWidth={["100%", "100%", "50%"]}>
            <Typography
              fontSize={[
                "var(--font-standard)",
                "var(--font-lg)",
                "var(--font-lg)",
                "var(--font-2xl)",
              ]}
              fontWeight={[
                "var(--font-medium)",
                "var(--font-medium)",
                "var(--font-regular)",
              ]}
            >
              {careersData.heading}
            </Typography>
            <Typography mt={3} lineHeight={[1.5, 1.5, 2]} textAlign={"justify"}>
              {careersData.description}
            </Typography>
            <StyledWrapper style={{ marginTop: 30 }}>
              <Link
                href="#heading"
                sx={{
                  scrollBehavior: "smooth",
                  textDecoration: "none",
                }}
              >
                <button className="animated-button">
                  <svg
                    viewBox="0 0 24 24"
                    className="arr-2"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z" />
                  </svg>

                  <span className="text">Explore Categories</span>
                  <span className="circle" />
                  <svg
                    viewBox="0 0 24 24"
                    className="arr-1"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z" />
                  </svg>
                </button>
              </Link>
            </StyledWrapper>
          </Stack>

          <Box
            mt={[-15, -15, 0]}
            height={["120%", "100%", "100%", "100%"]}
            width={["120%", "100%", "100%", "100%"]}
          >
            <Lottie
              loop
              animationData={animationData}
              play
              style={{ height: "100%", width: "100%" }}
            />
          </Box>
        </Stack>
      </Box>
    </>
  );
}

const StyledWrapper = styled.div`
  .animated-button {
    position: relative;
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 12px 36px;
    border: 4px solid;
    border-color: var(--color-primary-hover);
    font-size: 16px;
    background-color: inherit;
    border-radius: 100px;
    font-weight: 600;
    color: var(--color-primary-hover);
    cursor: pointer;
    overflow: hidden;
    transition: all 0.6s cubic-bezier(0.23, 1, 0.32, 1);
  }

  .animated-button svg {
    position: absolute;
    width: 24px;
    fill: var(--color-primary-hover);
    z-index: 9;
    transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
  }

  @media (max-width: 500px) {
    .animated-button {
      padding: 10px 26px;
      border: 3px solid;
      font-size: 14px;
    }
    .animated-button svg {
      width: 20px;
    }
  }

  .animated-button .arr-1 {
    right: 16px;
  }

  .animated-button .arr-2 {
    left: -25%;
  }

  .animated-button .circle {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 20px;
    height: 20px;
    background-color: var(--color-primary);
    border-radius: 50%;
    opacity: 0;
    transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
  }

  .animated-button .text {
    position: relative;
    z-index: 1;
    transform: translateX(-12px);
    transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
  }

  @media (min-width: 900px) {
    .animated-button:hover {
      box-shadow: 0 0 0 12px transparent;
      color: white;
      border-radius: 12px;
    }

    .animated-button:hover .arr-1 {
      right: -25%;
    }

    .animated-button:hover .arr-2 {
      left: 16px;
    }

    .animated-button:hover .text {
      transform: translateX(12px);
    }

    .animated-button:hover svg {
      fill: white;
    }

    .animated-button:active {
      scale: 0.95;
      box-shadow: 0 0 0 4px var(--color-primary);
    }

    .animated-button:hover .circle {
      width: 220px;
      height: 220px;
      opacity: 1;
    }
  }
`;

export default Banner;
