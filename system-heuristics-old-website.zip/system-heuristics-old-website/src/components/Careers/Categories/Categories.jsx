/*
1. Displays job categories and listings fetched from a JSON file.
2. Uses tab-based navigation to filter jobs by category.
3. Shows only jobs related to the selected category.
4. Each listing includes title, summary, job type, and pay range.
5. Clicking "View" or "Read more..." opens a job details dialog.
6. Dialog displays department, employment type, and location.
7. "Didn't Find the Job?" section allows resume submissions.
8. Styled and structured using Material-UI components.
9. Uses FontAwesome icons for job type and location visuals.
10. Supports light and dark themes via Material-UI settings.
*/

import { faPaperPlane } from "@fortawesome/free-regular-svg-icons";
import {
  faBriefcase,
  faCircleDot,
  faInfo,
  faLaptopFile,
  faLocationDot,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  Box,
  Button,
  Divider,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Stack,
  Tab,
  Tabs,
  Typography,
  List,
  ListItem,
  ListItemText,
  keyframes,
  useTheme,
  Link,
  Tooltip,
} from "@mui/material";
import React from "react";
import CareersData from "../Careers.json";
import { useState } from "react";

function Categories() {
  const careersData = CareersData.careers;

  const [value, setValue] = useState(0);
  const [open, setOpen] = useState(false);

  // const [isExpanded, setIsExpanded] = useState(false);

  const [selectedJob, setSelectedJob] = useState(null);

  const theme = useTheme();
  const isDarkMode = theme.palette.mode === "dark";

  const handleClickOpen = (job) => {
    setSelectedJob(job);
    setOpen(true);
    // setIsExpanded(false);
  };

  const handleClose = () => {
    // Move focus to a specific element
    const fallbackFocusElement = document.getElementById(
      "fallback-focus-element"
    );
    if (fallbackFocusElement) {
      fallbackFocusElement.focus();
    }
    setOpen(false);
    setSelectedJob(null);
  };

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const currentJobs =
    value === 0
      ? careersData.jobData
      : careersData.jobData.filter(
          (job) => job.category === careersData.categories[value]
        );

  const fadeIn = keyframes`
  0% { opacity: 0; transform: scale(0.95); }
  100% { opacity: 1; transform: scale(1); }
`;
  return (
    <>
      <Stack spacing={2} id="heading" pt={10}>
        <Box textAlign={"center"}>
          <Typography fontSize={"var(--heading)"}>
            Explore By Categories
          </Typography>
          <Typography fontSize={"var(--description)"} my={3}>
            Find your dream job
          </Typography>
        </Box>
        {/* Categories Tabs */}
        <Box>
          <Tabs
            value={value}
            onChange={handleChange}
            variant="scrollable"
            scrollButtons
            allowScrollButtonsMobile
            aria-label="scrollable force tabs example"
            sx={{
              mx: 3,
              "& .MuiTabs-flexContainer": {
                justifyContent: {
                  xs: "unset",
                  md: "center",
                },
              },
            }}
          >
            {careersData.categories.map((category, index) => (
              <Tab key={index} label={category} />
            ))}
          </Tabs>
        </Box>
      </Stack>

      {/* Content Box */}
      <Box mb={15} mt={3} mx={[3, 3, 10, 30]}>
        {currentJobs.length > 0 ? (
          currentJobs.map((job, index) => (
            <Stack
              data-aos="fade-up"
              key={index}
              sx={{
                borderRadius: "var(--radius)",
                mb: 2,
              }}
            >
              <Divider
                sx={{
                  mb: 2,
                  mt: 5,
                  border: "1px solid var(--color-secondary)",
                }}
              />

              <Stack
                direction={"row"}
                justifyContent={"space-between"}
                alignItems={"flex-start"}
                flexWrap={["wrap", "wrap", "wrap", "nowrap"]}
                gap={[1, 1, 1, 10]}
              >
                <Box width={["100%", "100%", "80%"]}>
                  <Typography
                    fontSize={"var(--font-standard)"}
                    fontWeight={"var(--font-medium)"}
                  >
                    {job.title}
                  </Typography>
                  <Typography
                    sx={{
                      overflow: "hidden",
                      maxWidth: "100%",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {job.positionSummary}
                  </Typography>

                  <Tooltip title="View Detail" arrow>
                    <span
                      style={{
                        cursor: "pointer",
                        "&:hover": {
                          textDecoration: "underline",
                        },
                      }}
                      onClick={() => handleClickOpen(job)}
                    >
                      read more...
                    </span>
                  </Tooltip>

                  <Stack
                    direction={"row"}
                    justifyContent={"flex-start"}
                    alignItems={"center"}
                    gap={1}
                    mt={3}
                    fontSize={"var(--font-sm)"}
                  >
                    {" "}
                    <span
                      style={{
                        border: "2px solid var(--color-primary)",
                        padding: "3px 12px",
                        borderRadius: "var(--rounded)",
                        color: "var(--color-primary)",
                      }}
                    >
                      {job.jobType === "Remote" ? (
                        <FontAwesomeIcon
                          style={{ marginRight: 5 }}
                          icon={faLaptopFile}
                        />
                      ) : (
                        <FontAwesomeIcon
                          style={{ marginRight: 5 }}
                          icon={faBriefcase}
                        />
                      )}
                      {job.jobType}
                    </span>
                    <span
                      style={{
                        border: "2px solid var(--color-primary)",
                        padding: "2.5px 12px",
                        borderRadius: "var(--rounded)",
                        color: "var(--color-primary)",
                      }}
                    >
                      {job.payRange}
                    </span>
                  </Stack>
                </Box>

                <Tooltip title="View Detail" arrow>
                  <Button
                    variant="contained"
                    sx={{
                      size: {
                        xs: "small",
                        lg: "large",
                      },
                      textTransform: "capitalize",
                      borderRadius: "var(--rounded)",
                      px: 5,
                      mt: {
                        xs: 2,
                        sm: 2,
                        md: 0,
                      },
                      "&:hover": {
                        backgroundColor: "var(--color-primary-hover)",
                      },
                    }}
                    onClick={() => handleClickOpen(job)}
                  >
                    View
                    <FontAwesomeIcon
                      style={{
                        marginLeft: 5,

                        border: isDarkMode
                          ? "2px solid black"
                          : "2px solid white",
                        padding: "3px 7px",
                        borderRadius: "100%",
                      }}
                      size="xs"
                      icon={faInfo}
                    />
                  </Button>
                </Tooltip>
              </Stack>
            </Stack>
          ))
        ) : (
          <Typography>No Jobs Available</Typography>
        )}
      </Box>

      {/* Don't Find Job Section  */}
      <Stack
        data-aos="flip-down"
        direction={"column"}
        justifyContent={"center"}
        alignItems={"center"}
        gap={2}
        border={"3px dashed"}
        borderColor={theme.palette.mode === "dark" ? "white" : "black"}
        mb={15}
        mx={[3, 3, 10, 20, 30]}
        p={5}
        bgcolor={theme.palette.mode === "dark" ? "transparent" : "#f9f9f9"}
        sx={{
          // backgroundColor: "#f9f9f9",
          borderRadius: "var(--radius)",
          boxShadow: "0 2px 8px rgba(0, 0, 0, 0.1)",
        }}
      >
        {/* Heading */}
        <Typography
          variant="h5"
          sx={{ fontWeight: "bold" }}
          textAlign={"center"}
          color={theme.palette.mode === "dark" ? "white" : "black"}
        >
          Didn’t Find the Job You Were Looking For?
        </Typography>

        {/* Description */}
        <Typography
          variant="body1"
          sx={{ textAlign: "center", color: "text.secondary", mb: 2 }}
        >
          We understand that everyone's career journey is unique. If you
          couldn't find your desired role in our current listings, don't worry!
          Share your area of interest with us, and drop your resume so we can
          connect with you for future opportunities.
        </Typography>

        {/* Action Button */}
        <Button
          onClick={() => {
            window.open(
              "https://forms.gle/eo26vCXvdJu6jpt88",
              "_blank",
              "noopener,noreferrer"
            );
          }}
          sx={{
            backgroundColor: "var(--color-primary)",
            "&:hover": {
              backgroundColor: "var(--color-primary-hover)",
            },
            fontWeight: "var(--font-medium)",
            boxShadow: "none",
            borderRadius: "var(--rounded)",
            paddingX: 3,
            color: "white",
          }}
        >
          Submit Your Resume
          <FontAwesomeIcon style={{ marginLeft: 5 }} icon={faPaperPlane} />
        </Button>
      </Stack>

      <Button id="fallback-focus-element" style={{ display: "none" }}>
        Hidden Button
      </Button>

      {/* Job Details Dialog */}

      <Dialog
        open={open}
        onClose={handleClose}
        fullWidth
        sx={{
          animation: `${fadeIn} 0.3s ease-out`,
          "& .MuiPaper-root": {
            borderRadius: "var(--radius)",
          },
          boxShadow: "none",
          mx: -2,
        }}
        disableEnforceFocus // Ensure focus stays within the Dialog
      >
        {selectedJob && (
          <>
            <DialogTitle>
              <Typography
                sx={{
                  fontSize: "var(--font-md)",
                  fontWeight: "var(--font-medium)",
                  WebkitBackgroundClip: "text",
                  textAlign: "center",
                }}
              >
                Job Title:
                <span
                  style={{
                    fontWeight: "var(--font-regular)",
                  }}
                >
                  {" "}
                  {selectedJob?.title}
                </span>
              </Typography>
            </DialogTitle>
            <DialogContent>
              <Typography
                fontSize="var(--font-sm)"
                fontWeight="var(--font-medium)"
                mt={2}
                gutterBottom
              >
                Department:{" "}
                <span
                  style={{
                    fontWeight: "var(--font-regular)",
                  }}
                >
                  {selectedJob?.category}
                </span>
              </Typography>

              <Stack
                direction={"row"}
                justifyContent={"flex-start"}
                alignItems={"center"}
                gap={1}
                mt={2}
                fontSize={"var(--font-sm)"}
              >
                <span
                  style={{
                    border: "2px solid var(--color-primary)",
                    padding: "2px 8px",
                    borderRadius: "var(--rounded)",
                    color: "var(--color-primary)",
                    display: "flex",
                    alignItems: "center",
                  }}
                >
                  {selectedJob.jobType === "Remote" ? (
                    <FontAwesomeIcon
                      icon={faLaptopFile}
                      size="sm"
                      style={{ marginRight: 5 }}
                    />
                  ) : (
                    <FontAwesomeIcon
                      icon={faBriefcase}
                      size="sm"
                      style={{ marginRight: 5 }}
                    />
                  )}
                  {selectedJob.jobType}
                </span>
                <span
                  style={{
                    border: "2px solid var(--color-primary)",
                    padding: "2px 8px",
                    borderRadius: "var(--rounded)",
                    color: "var(--color-primary)",
                  }}
                >
                  {selectedJob.payRange}
                </span>
              </Stack>

              <Typography
                fontSize="var(--font-sm)"
                fontWeight="var(--font-medium)"
                mt={2}
                gutterBottom
              >
                Employment Type:{" "}
                <span
                  style={{
                    fontWeight: "var(--font-regular)",
                  }}
                >
                  {selectedJob?.employmentType}
                </span>
              </Typography>

              <Tooltip title="Click To View" arrow>
                <Link
                  href="https://maps.app.goo.gl/Sgc1VWzix8r3P4dx6"
                  sx={{
                    textDecoration: "none",
                    color: isDarkMode ? "white" : "black",
                  }}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Typography variant="body2" sx={{ mb: 2, cursor: "pointer" }}>
                    <FontAwesomeIcon
                      icon={faLocationDot}
                      size="xl"
                      style={{
                        marginRight: "8px",
                        color: "var(--color-primary)",
                      }}
                    />

                    {selectedJob?.location}
                  </Typography>
                </Link>
              </Tooltip>

              {[
                { label: "About Us", value: selectedJob?.aboutUs },
                {
                  label: "Position Summary",
                  value: selectedJob?.positionSummary,
                },
                {
                  label: "Key Responsibilities",
                  value: selectedJob?.keyResponsibilities,
                },
                {
                  label: "Qualifications (Required)",
                  value: selectedJob?.qualificationsRequired,
                },
                {
                  label: "Qualifications (Preferred)",
                  value: selectedJob?.qualificationsPreferred,
                },
                {
                  label: "Personal Attributes",
                  value: selectedJob?.personalAttributes,
                },
                { label: "What We Offer", value: selectedJob?.whatWeOffer },
                {
                  label: "Application Instructions",
                  value: selectedJob?.applicationInstructions,
                },
                {
                  label: "Equal Opportunity Employer Statement",
                  value: selectedJob?.equalOpportunityStatement,
                },
              ].map((section, idx) => (
                <Box key={idx} mt={2}>
                  <Typography
                    fontSize="var(--font-sm)"
                    fontWeight="var(--font-medium)"
                    gutterBottom
                  >
                    {section.label}:
                  </Typography>
                  {Array.isArray(section.value) ? (
                    <List>
                      {section.value.map((item, index) => (
                        <ListItem key={index} sx={{ mt: -2 }}>
                          <FontAwesomeIcon
                            icon={faCircleDot}
                            size="xs"
                            style={{
                              marginRight: 5,
                              color: "var(--color-primary)",
                            }}
                          />
                          <ListItemText primary={item} />
                        </ListItem>
                      ))}
                    </List>
                  ) : (
                    <Typography>{section.value}</Typography>
                  )}
                </Box>
              ))}
            </DialogContent>
            <DialogActions>
              <Button
                onClick={() => {
                  window.open(
                    "https://forms.gle/eo26vCXvdJu6jpt88",
                    "_blank",
                    "noopener,noreferrer"
                  );
                }}
                color="secondary"
                variant="contained"
                sx={{
                  backgroundColor: "var(--color-primary)",
                  "&:hover": {
                    backgroundColor: "var(--color-primary-hover)",
                  },
                  fontWeight: "var(--font-medium)",
                  boxShadow: "none",
                  borderRadius: "var(--rounded)",
                  mb: 1,
                  mr: 1,
                }}
              >
                Apply
                <FontAwesomeIcon
                  style={{ marginLeft: 5 }}
                  icon={faPaperPlane}
                />
              </Button>
            </DialogActions>
          </>
        )}
      </Dialog>
    </>
  );
}

export default Categories;
