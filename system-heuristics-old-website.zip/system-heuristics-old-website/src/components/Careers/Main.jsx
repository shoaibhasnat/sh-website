/*
1. Main component serving as the homepage container.
2. Imports React to define a functional component.
3. Imports Banner for visual or promotional content.
4. Imports Categories to showcase job or product categories.
5. Uses React Fragment (<></>) to avoid extra DOM nodes.
6. Renders Banner first, followed by Categories.
7. Banner likely displays an introductory or featured section.
8. Categories organizes content for better navigation.
9. Does not maintain state or handle interactions.
10. Exported as default for use in other components.
*/

import React from "react";
import Banner from "./Banner/Banner";
import Categories from "./Categories/Categories";

function Main() {
  return (
    <>
      <Banner />
      <Categories />
    </>
  );
}

export default Main;
