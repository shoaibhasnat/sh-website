/*
Banner Component:

1. Renders a banner for the contact page with an animated background, heading, description, and Lottie animation.
2. Imports Material-UI components, styled components, and JSON data for dynamic content.
3. Uses `useTheme` to adjust the background color based on light or dark mode.
4. Applies CSS animation for floating circular background elements.
5. Displays a heading, button, and description dynamically fetched from `ContactData.banner`.
6. Includes a responsive Lottie animation alongside text content.
7. Uses `Stack` for a responsive layout across different screen sizes.
8. `StyledWrapper` applies a text animation effect on the button.
9. Maintains a structured and adaptive design with Material-UI’s flex properties.
10. Exported as `Banner` for use in other components.
*/

import { Box, Stack, Typography, useTheme } from "@mui/material";
import React from "react";
import styled from "styled-components";
import animationData from "./Contact-Banner-Animation.json";
import ContactData from "../Contact.json"; // Import the JSON file
import Lottie from "react-lottie-player";

function Banner() {
  const contactData = ContactData.banner;
  const theme = useTheme(); // Access the theme to detect mode
  return (
    <>
      <Box
        id="Contact"
        // mt={7}
        pt={[7, 7, 0]}
        height={"100vh"}
        position={"relative"}
        overflow={"hidden"}
        mb={10}
        // bgcolor={"#F0F8FF"}
        bgcolor={theme.palette.mode === "dark" ? "black" : "#F0F8FF"}
      >
        {/* Background animation */}

        <style>{`
        .circles {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          overflow: hidden;
          margin: 0;
          padding: 0;
          list-style: none;
        }

        .circles li {
          position: absolute;
          display: block;
          width: 20px;
          height: 20px;
          background: var(--color-primary);
          bottom: -150px;
          animation: animate 25s linear infinite;
        }

        .circles li:nth-child(1) {
          left: 5%;
          width: 80px;
          height: 80px;
          animation-delay: 0s;
        }

        .circles li:nth-child(2) {
          left: 10%;
          width: 80px;
          height: 80px;
          animation-delay: 2s;
          animation-duration: 12s;
        }

        .circles li:nth-child(3) {
          left: 15%;
          width: 20px;
          height: 20px;
          animation-delay: 4s;
        }

        .circles li:nth-child(4) {
          left: 20%;
          width: 60px;
          height: 60px;
          animation-delay: 0s;
          animation-duration: 8s;
        }

        .circles li:nth-child(5) {
          left: 25%;
          width: 20px;
          height: 20px;
          animation-delay: 6s;
          animation-duration: 5s;
        }

        .circles li:nth-child(6) {
          left: 30%;
          width: 110px;
          height: 110px;
          animation-delay: 3s;
          animation-duration: 18s;
        }

        .circles li:nth-child(7) {
          left: 60%;
          width: 150px;
          height: 150px;
          animation-delay: 7s;
        }

        .circles li:nth-child(8) {
          left: 40%;
          width: 25px;
          height: 25px;
          animation-delay: 15s;
          animation-duration: 45s;
        }

        .circles li:nth-child(9) {
          left: 45%;
          width: 15px;
          height: 15px;
          animation-delay: 12s;
          animation-duration: 35s;
        }

        .circles li:nth-child(10) {
          left: 10%;
          width: 150px;
          height: 150px;
          animation-delay: 0s;
          animation-duration: 10s;
        }
        .circles li:nth-child(11) {
          left: 55%;
          width: 15px;
          height: 15px;
          animation-delay: 14s;
          animation-duration: 53s;
        }
           .circles li:nth-child(12) {
          left: 60%;
          width: 15px;
          height: 15px;
          animation-delay: 2s;
          animation-duration: 15s;
        }
           .circles li:nth-child(13) {
          left: 65%;
          width: 25px;
          height: 25px;
          animation-delay: 15s;
          animation-duration: 5s;
        }
        .circles li:nth-child(14) {
          left: 50%;
          width: 70px;
          height: 70px;
          animation-delay: 7s;
        }

        .circles li:nth-child(15) {
          left: 98%;
          width: 110px;
          height: 110px;
          animation-delay: 3s;
          animation-duration: 25s;
        }
  .circles li:nth-child(16) {
          left: 80%;
          width: 20px;
          height: 20px;
          animation-delay: 0s;
        }
         .circles li:nth-child(17) {
          left: 85%;
          width: 60px;
          height: 60px;
          animation-delay: 0s;
          animation-duration: 18s;
        }

  .circles li:nth-child(18) {
          left: 90%;
          width: 20px;
          height: 20px;
          animation-delay: 4s;
        }
    .circles li:nth-child(19) {
          left: 95%;
          width: 20px;
          height: 20px;
          animation-delay: 2s;
          animation-duration: 12s;
        }
 
    

      
      
        

        @keyframes animate {
          0% {
            transform: translateY(0) rotate(0deg);
            opacity: 1;
            border-radius: 0;
          }
          100% {
            transform: translateY(-1000px) rotate(720deg);
            opacity: 0;
            border-radius: 50%;
          }
        }
      `}</style>
        <ul className="circles">
          {[...Array(20)].map((_, index) => (
            <li key={index}></li>
          ))}
        </ul>
        <Stack
          mx={[2, 5, 2, 10]}
          color={theme.palette.mode === "dark" ? "white" : "black"}
          direction={["column", "column", "row"]}
          justifyContent={"center"}
          alignItems={"center"}
          height={"100%"}
          zIndex={1}
          position={"absolute"}
          gap={1}
        >
          <Box maxWidth={["100%", "100%", "50%"]} mt={[10, 10, 0]}>
            <Typography
              fontSize={[
                "var(--font-lg)",
                "var(--font-lg)",
                "var(--font-standard)",
                "var(--font-lg)",
              ]}
            >
              {contactData.heading}{" "}
              <StyledWrapper>
                <button className="button" data-text="Awesome">
                  <span className="actual-text">
                    &nbsp;System&nbsp;Heuristics...!!!&nbsp;
                  </span>
                  <span aria-hidden="true" className="hover-text">
                    &nbsp;System&nbsp;Heuristics...!!!&nbsp;
                  </span>
                </button>
              </StyledWrapper>
            </Typography>
            <Typography mt={3} lineHeight={[1.5, 1.5, 2]}>
              {contactData.description}
            </Typography>
          </Box>

          <Box
            mt={[-5, -5, 0]}
            height={["100%", "80%", "40%", "60%"]}
            width={["100%", "80%", "40%", "60%"]}
          >
            <Lottie
              loop
              animationData={animationData}
              play
              style={{ height: "100%", width: "100%" }}
            />
          </Box>
        </Stack>
      </Box>
    </>
  );
}

const StyledWrapper = styled.div`
  /* === removing default button style ===*/
  .button {
    margin: 0;
    height: auto;
    background: transparent;
    padding: 0;
    border: none;
    cursor: pointer;
  }

  /* button styling */
  .button {
    --border-right: 6px;
    --text-stroke-color: rgba(255, 255, 255, 0.6);
    /*--animation-color: rgb(55, 195, 255);*/
    --animation-color: var(--color-primary);
    --fs-size: 1.5em;
    letter-spacing: 3px;
    text-decoration: none;
    font-size: var(--fs-size);
    font-family: "Arial";
    position: relative;
    text-transform: uppercase;
    color: black;
    -webkit-text-stroke: 1px var(--text-stroke-color);
  }

  /* Responsive font size for screens less than 600px */
  @media (min-width: 0px) {
    .button {
      --fs-size: 0.4em;
      font-size: var(--fs-size);
    }
  }
  @media (min-width: 300px) {
    .button {
      --fs-size: 0.6em;
      font-size: var(--fs-size);
    }
  }
  @media (min-width: 400px) {
    .button {
      --fs-size: 0.8em;
      font-size: var(--fs-size);
    }
  }
  @media (min-width: 550px) {
    .button {
      --fs-size: 1.2em;
      font-size: var(--fs-size);
    }
  }
  @media (min-width: 700px) {
    .button {
      --fs-size: 1.5em;
      font-size: var(--fs-size);
    }
  }

  /* this is the text, when you hover on button */
  .hover-text {
    position: absolute;
    box-sizing: border-box;
    content: attr(data-text);
    color: var(--animation-color);
    width: 0%;
    inset: 0;
    border-right: var(--border-right) solid var(--animation-color);
    overflow: hidden;
    transition: 0.5s;
    -webkit-text-stroke: 1px var(--animation-color);
  }
  /* hover */
  .button:hover .hover-text {
    width: 100%;
    /*filter: drop-shadow(0 0 23px var(--animation-color));*/
  }
`;

export default Banner;
