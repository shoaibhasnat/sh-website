/*
Contact Form Component:

1. Renders a contact form for users to submit inquiries about a project.
2. Displays company contact details, including phone number, email, and address.
3. Users can copy the phone number and email address to the clipboard by clicking on them.
4. Allows users to select an interest category (e.g., UI/UX design, Web design) using clickable chips.
5. Sends form data via EmailJS, handling both success and failure responses.
6. Includes a honeypot email field for spam prevention and bot detection.
7. Adjusts theme dynamically based on light or dark mode using MUI's `useTheme` hook.
8. Displays social media links (Instagram, LinkedIn, Facebook) with FontAwesome icons.
9. Ensures a responsive layout using MUI’s `Box`, `Stack`, and `Grid` components.
10. Dynamically changes background images based on the selected theme for an enhanced visual experience.
*/

import React from "react";
import {
  Box,
  Typography,
  TextField,
  Button,
  Grid,
  Chip,
  Stack,
  useTheme,
  Tooltip,
  Link,
} from "@mui/material";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faFacebookF,
  faInstagram,
  faLinkedinIn,
} from "@fortawesome/free-brands-svg-icons";
import { faEnvelope, faFaceSmile } from "@fortawesome/free-regular-svg-icons";
import { faLocationDot, faPhone } from "@fortawesome/free-solid-svg-icons";
import styled from "styled-components";
import { useState } from "react";
import emailjs from "emailjs-com"; // Import EmailJS
import Bg1 from "../../images/Contact-Email.png";
import Bg2 from "../../images/Contact-Email2.png";
import FooterData from "../../About/About.json";

const ContactForm = () => {
  const footerData = FooterData.footer;
  const theme = useTheme(); // Access the theme to detect mode
  const [selectedInterest, setSelectedInterest] = useState("UI/UX design");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [padding, setPadding] = useState("");
  const [message, setMessage] = useState("");
  const [phoneCopySuccess, setPhoneCopySuccess] = useState(false);
  const phoneCopied = footerData.contact.phoneNumber; // The phone number to copy
  const [emailCopySuccess, setEmailCopySuccess] = useState(false);
  const emailCopied = footerData.contact.email; // The phone number to copy

  const paddingBg = theme.palette.mode === "dark" ? Bg2 : Bg1;

  const fallbackCopyTextToClipboard = (text) => {
    const textArea = document.createElement("textarea");
    textArea.value = text;
    textArea.style.position = "fixed"; // Avoid scrolling to bottom of the page
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    try {
      document.execCommand("copy");
      // alert("Copied to clipboard!");
    } catch (err) {
      console.error("Fallback: Could not copy text: ", err);
    }
    document.body.removeChild(textArea);
  };

  const handleCopyPhone = () => {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard
        .writeText(phoneCopied)
        .then(() => {
          setPhoneCopySuccess(true);
          setTimeout(() => setPhoneCopySuccess(false), 2000);
        })
        .catch((err) => console.error("Error copying text: ", err));
    } else {
      fallbackCopyTextToClipboard(phoneCopied);
    }
  };

  const handleCopyEmail = () => {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard
        .writeText(emailCopied)
        .then(() => {
          setEmailCopySuccess(true);
          setTimeout(() => setEmailCopySuccess(false), 2000);
        })
        .catch((err) => console.error("Error copying text: ", err));
    } else {
      fallbackCopyTextToClipboard(emailCopied);
    }
  };

  const handleChipClick = (item) => {
    setSelectedInterest(item);
  };

  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent the default form submission
    setName("");
    setPadding("");
    setMessage("");

    // Honeypot check: if the hidden email field is filled, it's a bot
    const honeypotEmail = e.target.email.value;

    if (honeypotEmail) {
      alert("You Are Not A Human");
      return;
    }

    const templateParams = {
      name,
      padding,
      message,
      selectedInterest,
    };

    emailjs
      .send(
        "service_pzfo0w6", // Your service ID
        "template_qkfjbxt", // Your template ID
        templateParams,
        "UBdqO_nqgGUPH2Uvk" // Your user ID from EmailJS
      )
      .then(
        (result) => {
          console.log("Email successfully sent:", result.text);
          alert("Form Submit successfully!");
        },
        (error) => {
          console.error("Error sending email:", error.text);
          alert("Error sending message. Please try again later.");
        }
      );
  };
  return (
    <>
      <Typography textAlign={"center"} fontSize={"var(--heading)"} mb={2}>
        Tell Us About Your Project
      </Typography>
      <Stack
        data-aos="flip-left"
        direction={["column", "column", "row"]}
        mb={10}
        mx={[2, 2, "auto"]}
        py={4}
        px={[2, 2, 4]}
        sx={{
          bgcolor: "var(--color-primary)",
          color: "white",
          borderRadius: "var(--radius)",
          maxWidth: 800,
        }}
      >
        {/* Left Section */}
        <Box sx={{ flex: 1, pr: 1 }}>
          <Typography
            fontSize={["var(--font-standard)", "var(--font-lg)"]}
            sx={{ fontWeight: "var(--font-bold)", mb: 2 }}
          >
            Let’s discuss on something{" "}
            <span style={{}}>
              C
              <FontAwesomeIcon
                icon={faFaceSmile}
                className="fa-spin"
                size="sm"
              />
              <FontAwesomeIcon
                icon={faFaceSmile}
                className="fa-spin fa-spin-reverse"
                size="sm"
              />
              L
            </span>{" "}
            together
          </Typography>

          <Stack
            direction={["column", "row", "column"]}
            justifyContent={"space-between"}
            alignItems={["flex-start", "center", "flex-start"]}
            gap={[1, 10]}
          >
            <Box>
              <Stack direction={"row"} variant="body2" sx={{ mb: 2 }}>
                <FontAwesomeIcon
                  icon={faPhone}
                  size="lg"
                  className="hover-bounce"
                  style={{
                    marginRight: "10px",

                    faBounceHeight: 0.5,
                    faBounceStartScaleX: 1,
                    faBounceStartScaleY: 1,
                    faBounceJumpScaleX: 1,
                    faBounceJumpScaleY: 1,
                    faBounceLandScaleX: 1,
                    faBounceLandScaleY: 1,
                    faBounceRebound: 0,
                    cursor: "pointer",
                  }}
                />
                <style>
                  {`
                                .hover-bounce:hover {
                                  animation: fa-bounce 1.5s ;
            
                                }
                              `}
                </style>

                <Tooltip
                  title={phoneCopySuccess ? "Copied!" : "Click to Copy"}
                  arrow
                >
                  <a href="tel:+923349989995">
                    <img
                      height={16}
                      width={120}
                      src={"/images/Footer-PhoneNumber.avif"}
                      alt="Contact Number"
                      onClick={handleCopyPhone}
                      style={{
                        cursor: "pointer",
                      }}
                      loading="lazy"
                    />
                  </a>
                </Tooltip>
              </Stack>

              <Stack direction={"row"} variant="body2" sx={{ mb: 2 }}>
                <FontAwesomeIcon
                  icon={faEnvelope}
                  size="lg"
                  className="hover-bounce"
                  style={{
                    marginRight: "10px",

                    faBounceHeight: 0.5,
                    faBounceStartScaleX: 1,
                    faBounceStartScaleY: 1,
                    faBounceJumpScaleX: 1,
                    faBounceJumpScaleY: 1,
                    faBounceLandScaleX: 1,
                    faBounceLandScaleY: 1,
                    faBounceRebound: 0,
                    cursor: "pointer",
                  }}
                />
                <style>
                  {`
                                .hover-bounce:hover {
                                  animation: fa-bounce 1.5s ;
            
                                }
                              `}
                </style>
                <Tooltip
                  title={emailCopySuccess ? "Copied!" : "Click to Copy"}
                  arrow
                >
                  <a href="mailto:info@systemheuristics.com">
                    <img
                      height={22}
                      width={200}
                      src={"/images/Footer-Email.avif"}
                      alt="Email"
                      onClick={handleCopyEmail}
                      style={{
                        cursor: "pointer", // Change cursor to indicate clickability
                      }}
                      loading="lazy"
                    />
                  </a>
                </Tooltip>
              </Stack>

              <Tooltip title="Click To View" arrow>
                <Link
                  href="https://maps.app.goo.gl/Sgc1VWzix8r3P4dx6"
                  sx={{ textDecoration: "none", color: "white" }}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Typography variant="body2" sx={{ mb: 2 }}>
                    <FontAwesomeIcon
                      icon={faLocationDot}
                      size="xl"
                      className="hover-bounce"
                      style={{
                        marginRight: "16px",

                        faBounceHeight: 0.5,
                        faBounceStartScaleX: 1,
                        faBounceStartScaleY: 1,
                        faBounceJumpScaleX: 1,
                        faBounceJumpScaleY: 1,
                        faBounceLandScaleX: 1,
                        faBounceLandScaleY: 1,
                        faBounceRebound: 0,
                        cursor: "pointer",
                      }}
                    />
                    <style>
                      {`
                                .hover-bounce:hover {
                                  animation: fa-bounce 1.5s ;
            
                                }
                              `}
                    </style>
                    {footerData.contact.address}
                  </Typography>
                </Link>
              </Tooltip>
            </Box>

            <Box>
              <StyledWrapper>
                <div className="card">
                  <div className="background"></div>
                  <div className="logo">Connect</div>
                  <a
                    href="https://www.instagram.com/system.heuristics?igsh=MXYyanl0b24xMTJ5ag=="
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <div className="box box1">
                      <span className="icon">
                        <FontAwesomeIcon
                          icon={faInstagram}
                          size="lg"
                          style={{ color: "white" }}
                        />
                      </span>
                    </div>
                  </a>
                  <a
                    href="https://www.linkedin.com/company/system-heuristics-sh/?viewAsMember=true"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <div className="box box2">
                      {" "}
                      <span className="icon">
                        <FontAwesomeIcon
                          icon={faLinkedinIn}
                          size="lg"
                          style={{ color: "white" }}
                        />
                      </span>
                    </div>
                  </a>
                  <a
                    href="https://www.facebook.com/share/1946wQnqLh/"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <div className="box box3">
                      <span className="icon">
                        <FontAwesomeIcon
                          icon={faFacebookF}
                          size="lg"
                          style={{ color: "white" }}
                        />
                      </span>
                    </div>
                  </a>
                </div>
              </StyledWrapper>
            </Box>
          </Stack>
        </Box>

        {/* Right Section */}
        <Box
          mt={[2, 2, 0]}
          sx={{
            flex: 1,

            backgroundColor: theme.palette.mode === "dark" ? "black" : "white",
            color: "black",
            borderRadius: "var(--radius)",
            p: 3,
          }}
        >
          <Typography
            variant="body1"
            sx={{
              mb: 2,
              fontWeight: "bold",
              color: theme.palette.mode === "dark" ? "white" : "black",
            }}
          >
            I’m interested in...
          </Typography>

          <Grid container spacing={1} sx={{ mb: 3 }}>
            {[
              "UI/UX design",
              "Web design",
              "Graphic design",
              "Design system",
              "Other",
            ].map((item) => (
              <Grid item key={item}>
                <Chip
                  label={item}
                  clickable
                  onClick={() => handleChipClick(item)}
                  sx={{
                    bgcolor:
                      item === selectedInterest
                        ? "var(--color-primary)"
                        : theme.palette.mode === "dark"
                        ? "white"
                        : "rgba(0, 0, 0, 0.08)",
                    color: item === selectedInterest ? "white" : "black",
                    "&:hover": {
                      bgcolor: "var(--color-primary)",
                      color: "white",
                    },
                  }}
                />
              </Grid>
            ))}
          </Grid>

          <form onSubmit={handleSubmit}>
            <TextField
              required
              label="Your Name"
              variant="standard"
              fullWidth
              sx={{ mb: 2 }}
              value={name}
              onChange={(e) => setName(e.target.value)}
              InputLabelProps={{
                required: false, // Disable the asterisk
              }}
            />
            {/* Hidden Honeypot email field */}
            <TextField
              id="email"
              name="email"
              label="Email"
              type="email"
              value={email}
              sx={{ display: "none" }}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter Email" // Placeholder text for bot
            />

            {/* Original Email input */}
            {/* <TextField
              required
              name="padding"
              id="padding"
              variant="standard"
              fullWidth
              type="email"
              sx={{
                mb: 2,
                "& .MuiInputBase-root": {
                  backgroundImage: padding ? "none" : `url(${paddingBg})`, // Hide background if value exists
                  backgroundSize: {
                    xs: "50% 120%",
                    sm: "60% 120%",
                    md: "50% 120%",
                  }, // 50% width and 100% height
                  backgroundRepeat: "no-repeat",
                  backgroundPosition: "left center", // Align to the left and vertically center
                  maxWidth: 400,
                },
                "& .MuiInputBase-root:focus-within": {
                  backgroundImage: "none", // Hide background on focus
                },
                "& .MuiInputBase-input": {
                  cursor: "text",
                },
              }}
              value={padding}
              onChange={(e) => setPadding(e.target.value)}
              InputLabelProps={{
                required: false, // Disable the asterisk
              }}
              loading="lazy"
            /> */}
            <TextField
              required
              name="padding"
              id="padding"
              variant="standard"
              fullWidth
              type="email"
              sx={{
                mb: 2,
                "& .MuiInputBase-root": {
                  backgroundImage: padding ? "none" : `url(${paddingBg})`,
                  backgroundSize: "contain",
                  backgroundRepeat: "no-repeat",
                  backgroundPosition: "left center",
                  maxWidth: "100%",
                  backgroundClip: "padding-box",
                },
                "& .MuiInput-underline:before": {
                  borderBottom: `2px solid ${
                    theme.palette.mode === "dark"
                      ? "rgba(255, 255, 255, 0.7)"
                      : "rgba(0, 0, 0, 0.42)"
                  }!important`,
                },
                "& .MuiInput-underline:hover:before": {
                  borderBottom: `2px solid ${
                    theme.palette.mode === "dark" ? "white" : "black"
                  } !important`,
                },
                "& .MuiInput-underline:after": {
                  borderBottom: "2px solid var(--color-primary) !important",
                },
              }}
              value={padding}
              onChange={(e) => setPadding(e.target.value)}
              InputLabelProps={{
                required: false, // Disable the asterisk
              }}
              loading="lazy"
            />

            <TextField
              required
              label="Your Message"
              variant="standard"
              fullWidth
              multiline
              rows={4}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              sx={{ mb: 2 }}
              InputLabelProps={{
                required: false, // Disable the asterisk
              }}
            />

            <Button
              variant="contained"
              sx={{
                bgcolor: "var(--color-primary)",
                "&:hover": { bgcolor: "var(--color-primary-hover)" },
                color: "white",
                padding: "10px 20px",
              }}
              type="submit" // Submit the form
            >
              Send Message
            </Button>
          </form>
        </Box>
      </Stack>
    </>
  );
};

const StyledWrapper = styled.div`
  .card {
    position: relative;
    width: 150px;
    height: 150px;
    background: lightgrey;
    border-radius: var(--radius);
    overflow: hidden;
    box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
    transition: all 1s ease-in-out;
  }

  .background {
    position: absolute;
    inset: 0;
    background: radial-gradient(
      circle at 100% 107%,
      rgb(47, 255, 248) 0%,
      rgb(80, 170, 255) 60%,
      rgb(66, 252, 255) 100%
    );
  }

  .logo {
    font-size: 20px;
    font-weight: bold;
    position: absolute;
    right: 50%;
    bottom: 50%;
    transform: translate(50%, 50%);
    transition: all 0.6s ease-in-out;
  }

  .logo .logo-svg {
    fill: white;
    width: 30px;
    height: 30px;
  }

  .icon {
    display: inline-block;
    width: 20px;
    height: 20px;
  }

  .icon {
    fill: rgba(255, 255, 255, 0.797);
    width: 100%;
    transition: all 0.5s ease-in-out;
  }

  .box {
    position: absolute;
    padding: 10px;
    text-align: right;
    background: rgba(255, 255, 255, 0.389);
    border-top: 2px solid rgb(255, 255, 255);
    border-right: 1px solid white;
    border-radius: 10% 13% 42% 0%/10% 12% 75% 0%;
    box-shadow: rgba(100, 100, 111, 0.364) -7px 7px 29px 0px;
    transform-origin: bottom left;
    transition: all 1s ease-in-out;
  }

  .box::before {
    content: "";
    position: absolute;
    inset: 0;
    border-radius: inherit;
    opacity: 0;
    transition: all 0.5s ease-in-out;
  }

  .box:hover .svg {
    fill: white;
  }

  .box1 {
    width: 70%;
    height: 70%;
    bottom: -70%;
    left: -70%;
  }

  .box1::before {
    background: radial-gradient(
      circle at 30% 107%,
      #fdf497 0%,
      #fdf497 5%,
      #ff53d4 60%,
      #62c2fe 90%
    );
  }

  .box1:hover::before {
    opacity: 1;
  }

  .box1:hover .icon {
    filter: drop-shadow(0 0 5px white);
  }

  .box2 {
    width: 50%;
    height: 50%;
    bottom: -50%;
    left: -50%;
    transition-delay: 0.2s;
  }

  .box2::before {
    background: radial-gradient(circle at 30% 107%, #91e9ff 0%, #00acee 90%);
  }

  .box2:hover::before {
    opacity: 1;
  }

  .box2:hover .icon {
    filter: drop-shadow(0 0 5px white);
  }

  .box3 {
    width: 30%;
    height: 30%;
    bottom: -30%;
    left: -30%;
    transition-delay: 0.4s;
  }

  .box3::before {
    background: radial-gradient(
      circle at 30% 107%,
      rgb(83, 155, 255) 0%,
      rgb(28, 119, 255) 90%
    );
  }

  .box3:hover::before {
    opacity: 1;
  }

  .box3:hover .icon {
    filter: drop-shadow(0 0 5px white);
  }

  .card:hover {
    transform: scale(1.1);
  }

  .card:hover .box {
    bottom: -1px;
    left: -1px;
  }

  .card:hover .logo {
    transform: translate(50px, -32px);
    letter-spacing: 0px;
  }
`;

export default ContactForm;
