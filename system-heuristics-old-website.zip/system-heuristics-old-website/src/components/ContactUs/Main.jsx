/*
Main Component:

1. Acts as the homepage container, rendering `Banner`, `ContactForm`, and `Schedule`.
2. `Banner` provides an introductory visual header.
3. `ContactForm` allows users to submit inquiries.
4. `Schedule` displays contact details and scheduling options.
5. Imports child components for modular organization.
6. Uses JSX fragments (`<>...</>`) to avoid extra DOM elements.
7. Structurally combines and orders homepage sections.
8. Exported as the default component for reuse.
9. No props are passed; components manage their own state or use static content.
*/

import React from "react";
import Banner from "./Banner/Banner";
import ContactForm from "./Form/ContactForm";
import Schedule from "./Schedule/Schedule";

function Main() {
  return (
    <>
      <Banner />
      <ContactForm />

      <Schedule />
    </>
  );
}

export default Main;
