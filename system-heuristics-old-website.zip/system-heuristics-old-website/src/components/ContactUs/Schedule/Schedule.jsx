/*
Schedule Component:

1. Displays contact details (phone, email, location) with Material-UI and FontAwesome icons.
2. Fetches data dynamically from `FooterData` and `ScheduleData` JSON files.
3. Provides copy-to-clipboard functionality with UI feedback for phone and email.
4. Implements a fallback for unsupported `navigator.clipboard.writeText`.
5. Uses Material-UI (`Box`, `Typography`, `Tooltip`, `Stack`, `Link`) for responsiveness.
6. Features a "snake border" animated button linking to a Google Form.
7. Enhances UI with CSS animations, inline styles, and `data-aos="zoom-in"` effects.
8. Displays external images (`numberImage`, `emailImage`) for better visuals.
*/

import React from "react";
import { Box, Typography, Tooltip, Stack, Link } from "@mui/material";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEnvelope } from "@fortawesome/free-regular-svg-icons";
import { faLocationDot, faPhone } from "@fortawesome/free-solid-svg-icons";
import numberImage from "../../images/Footer-PhoneNumber.png";
import emailImage from "../../images/Footer-Email.png";
import FooterData from "../../About/About.json";
import ScheduleData from "../Contact.json";
import { useState } from "react";

const Schedule = () => {
  const footerData = FooterData.footer;
  const scheduleData = ScheduleData.schedule;

  const [phoneCopySuccess, setPhoneCopySuccess] = useState(false);
  const phoneCopied = footerData.contact.phoneNumber; // The phone number to copy
  const [emailCopySuccess, setEmailCopySuccess] = useState(false);
  const emailCopied = footerData.contact.email; // The phone number to copy

  const fallbackCopyTextToClipboard = (text) => {
    const textArea = document.createElement("textarea");
    textArea.value = text;
    textArea.style.position = "fixed"; // Avoid scrolling to bottom of the page
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    try {
      document.execCommand("copy");
      // alert("Copied to clipboard!");
    } catch (err) {
      console.error("Fallback: Could not copy text: ", err);
    }
    document.body.removeChild(textArea);
  };

  const handleCopyPhone = () => {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard
        .writeText(phoneCopied)
        .then(() => {
          setPhoneCopySuccess(true);
          setTimeout(() => setPhoneCopySuccess(false), 2000);
        })
        .catch((err) => console.error("Error copying text: ", err));
    } else {
      fallbackCopyTextToClipboard(phoneCopied);
    }
  };

  const handleCopyEmail = () => {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard
        .writeText(emailCopied)
        .then(() => {
          setEmailCopySuccess(true);
          setTimeout(() => setEmailCopySuccess(false), 2000);
        })
        .catch((err) => console.error("Error copying text: ", err));
    } else {
      fallbackCopyTextToClipboard(emailCopied);
    }
  };

  return (
    <Box
      data-aos="zoom-in"
      mb={10}
      mx={[2, 10, 20]}
      borderRadius={"var(--radius)"}
      sx={{
        bgcolor: "var(--color-primary)",
        color: "white",
        textAlign: "center",
        py: 6,
        px: 2,
      }}
    >
      <Typography
        fontSize={"var(--heading)"}
        sx={{ fontWeight: "bold", mb: 2 }}
      >
        {scheduleData.heading}
      </Typography>

      <Typography fontSize={"var(--description)"} sx={{ mb: 4 }}>
        {scheduleData.description}
      </Typography>

      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          gap: 2,
          mb: 4,
          flexWrap: "wrap",
        }}
      >
        <Stack
          direction={"row"}
          variant="body2"
          sx={{ mb: 2, mt: 0.5 }}
          alignItems={"flex-start"}
        >
          <FontAwesomeIcon
            icon={faPhone}
            size="lg"
            className="hover-bounce"
            style={{
              marginRight: "10px",

              faBounceHeight: 0.5,
              faBounceStartScaleX: 1,
              faBounceStartScaleY: 1,
              faBounceJumpScaleX: 1,
              faBounceJumpScaleY: 1,
              faBounceLandScaleX: 1,
              faBounceLandScaleY: 1,
              faBounceRebound: 0,
              cursor: "pointer",
            }}
          />
          <style>
            {`
                                .hover-bounce:hover {
                                  animation: fa-bounce 1.5s ;
            
                                }
                              `}
          </style>

          <Tooltip title={phoneCopySuccess ? "Copied!" : "Click to Copy"} arrow>
            <a href="tel:+923349989995">
              <img
                height={16}
                width={120}
                src={numberImage}
                alt=""
                onClick={handleCopyPhone}
                style={{
                  cursor: "pointer",
                }}
              />
            </a>
          </Tooltip>
        </Stack>
        |
        <Stack direction={"row"} variant="body2" sx={{ mb: 2 }}>
          <FontAwesomeIcon
            icon={faEnvelope}
            size="lg"
            className="hover-bounce"
            style={{
              marginRight: "10px",

              faBounceHeight: 0.5,
              faBounceStartScaleX: 1,
              faBounceStartScaleY: 1,
              faBounceJumpScaleX: 1,
              faBounceJumpScaleY: 1,
              faBounceLandScaleX: 1,
              faBounceLandScaleY: 1,
              faBounceRebound: 0,
              cursor: "pointer",
            }}
          />
          <style>
            {`
                                .hover-bounce:hover {
                                  animation: fa-bounce 1.5s ;
            
                                }
                              `}
          </style>
          <Tooltip title={emailCopySuccess ? "Copied!" : "Click to Copy"} arrow>
            <a href="mailto:info@systemheuristics.com">
              <img
                height={22}
                width={200}
                src={emailImage}
                alt=""
                onClick={handleCopyEmail}
                style={{
                  cursor: "pointer", // Change cursor to indicate clickability
                }}
              />
            </a>
          </Tooltip>
        </Stack>
        |
        <Tooltip title="Click To View" arrow>
          <Link
            href="https://maps.app.goo.gl/Sgc1VWzix8r3P4dx6"
            sx={{ textDecoration: "none", color: "white" }}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Box sx={{ display: "flex", alignItems: "center", mb: 2, gap: 1 }}>
              <FontAwesomeIcon icon={faLocationDot} />
              <Typography>Valencia Town, 54000, Lahore.</Typography>
            </Box>
          </Link>
        </Tooltip>
      </Box>

      <style>
        {`.btn {
  position: relative;
  display: inline-block;
  padding: 12px 20px;
  color: #fff;
  font-size: 16px;
  letter-spacing: 2px;
  border-radius: var(--radius);
  outline: none;
  border: none;
  cursor: pointer;
  text-transform: uppercase;
  box-sizing: border-box;
  box-shadow:120px
}


/* Hover effect */
.btn--snakeBorder:hover {
  background-color: var(--color-primary-hover); 
}

.btn--snakeBorder {
  background: var(--color0primary);
  overflow: hidden;
}

.btn--snakeBorder::before {
  content: "";
  position: absolute;
  top: 2px;
  left: 2px;
  bottom: 2px;
}

.btn--snakeBorder span {
  position: absolute;
}

.btn--snakeBorder span:nth-child(1) {
  top: 0;
  left: 0;
  width: 100%;
  height: 2px;
  background: linear-gradient(to right,rgb(255, 255, 255), #1779ff);
  animation: borderAnimation1 2s linear infinite;
}

@keyframes borderAnimation1 {
  0% {
    transform: translateX(-100%);
  }
  100% {
    transform: translateX(100%);
  }
}

.btn--snakeBorder span:nth-child(2) {
  top: 0;
  right: 0;
  width: 2px;
  height: 100%;
  background: linear-gradient(to bottom,rgb(255, 255, 255), #1779ff);
  animation: borderAnimation2 2s linear infinite;
  animation-delay: 1s;
}

@keyframes borderAnimation2 {
  0% {
    transform: translateY(-100%);
  }
  100% {
    transform: translateY(100%);
  }
}

.btn--snakeBorder span:nth-child(3) {
  bottom: 0;
  left: 0;
  width: 100%;
  height: 2px;
  background: linear-gradient(to left,rgb(255, 255, 255), #1779ff);
  animation: borderAnimation3 2s linear infinite;
}

@keyframes borderAnimation3 {
  0% {
    transform: translateX(100%);
  }
  100% {
    transform: translateX(-100%);
  }
}

.btn--snakeBorder span:nth-child(4) {
  top: 0;
  left: 0;
  width: 2px;
  height: 100%;
  background: linear-gradient(to top,rgb(255, 255, 255), #1779ff);
  animation: borderAnimation4 2s linear infinite;
  animation-delay: 1s;
}

@keyframes borderAnimation4 {
  0% {
    transform: translateY(100%);
  }
  100% {
    transform: translateY(-100%);
  }
}
`}
      </style>

      <button
        className="btn btn--snakeBorder"
        onClick={() => {
          window.open(
            "https://forms.gle/eo26vCXvdJu6jpt88",
            "_blank",
            "noopener,noreferrer"
          );
        }}
      >
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        {scheduleData.buttonText}
      </button>
    </Box>
  );
};

export default Schedule;
