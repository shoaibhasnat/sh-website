/**
 Banner Component:

 1. Displays a full-screen banner with dynamic background video based on screen width.
 2. Uses `useState` and `useEffect` to update video source on window resize.
 3. Initializes AOS for scroll animations.
 4. Uses `useNavigate` to scroll to the "#services" section.
 5. Displays heading, subheading, and a button with hover animation.
 6. Button triggers smooth scroll to the "#services" section.
 7. Uses MUI components for layout and responsive styling.
 */

import { Box, Link, Typography } from "@mui/material";
import AOS from "aos";
import "aos/dist/aos.css";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const Banner = () => {
  const [videoSrc, setVideoSrc] = useState(
    window.innerWidth > 900
      ? "/images/Aurora-Home-Desktop-Banner.mp4"
      : "/images/Aurora-Home-Mobile-Banner.mp4"
  );

  useEffect(() => {
    const handleResize = () => {
      setVideoSrc(
        window.innerWidth > 900
          ? "/images/Aurora-Home-Desktop-Banner.mp4"
          : "/images/Aurora-Home-Mobile-Banner.mp4"
      );
    };

    window.addEventListener("resize", handleResize);

    return () => window.removeEventListener("resize", handleResize);
  }, []);
  useEffect(() => {
    AOS.init({ duration: 1200 });
  }, []);

  const navigate = useNavigate();

  const handleClick = () => {
    navigate("#services");
    window.scrollTo(0, 0);
  };

  return (
    <Box
      pt={[25, 25, 20]}
      bgcolor={videoSrc ? "transparent" : "black"}
      justifyContent={["flex-start", "flex-start", "center"]}
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        textAlign: "center",
        px: 3,
        pb: 10,
        position: "relative",
        height: "100vh",
        maxHeight: "1000px",
        overflow: "hidden",
      }}
    >
      {/* Background video */}
      <video
        autoPlay
        loop
        muted
        playsInline
        preload="auto"
        fetchpriority="high"
        key={videoSrc}
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          objectFit: "cover",
          zIndex: -1,
          backgroundColor: "black",
        }}
      >
        <source src={videoSrc} type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      <Typography
        mb={[3, 3, 0]}
        sx={{
          bgcolor: "#f2f2f2",
          px: 2,
          py: 0.5,
          borderRadius: "var(--rounded)",
          fontSize: "12px",
          fontWeight: "500",
          textTransform: "uppercase",
          display: "inline-block",
          zIndex: 1,
          color: "black",
        }}
      >
        AI-Driven Solutions
      </Typography>

      <Typography
        variant="h3"
        data-aos="fade-up"
        fontSize={[32, 64]}
        sx={{
          fontWeight: "bold",
          my: 4,
          maxWidth: "1000px",
          zIndex: 1,
          color: "white",
        }}
      >
        Transforming Businesses with AI-Powered Heuristics
      </Typography>

      {/* Subheading */}
      <Typography
        sx={{
          color: "#f2f2f2",
          mt: 2,
          maxWidth: "600px",
          fontSize: { xs: "14px", sm: "16px" },
          zIndex: 1,
        }}
      >
        At System Heuristics, we specialize in delivering cutting-edge
        technology and AI-driven solutions tailored specifically to your
        business needs. We harness the power of Machine Learning, Data Science,
        Natural Language Processing, and Computer Vision to automate processes,
        enhance decision-making, and accelerate growth.
      </Typography>

      {/* CTA Button */}
      <style>
        {`.btn {
  position: relative;
  display: inline-block;
  padding: 12px 20px;
  color: #fff;
  font-size: 16px;
  letter-spacing: 2px;
  border-radius: 5px;
  outline: none;
  border: none;
  cursor: pointer;
  text-transform: uppercase;
  box-sizing: border-box;
  box-shadow:120px;
  margin-top: 60px;
  transition:0.3s;
}


/* Hover effect */
.btn--snakeBorder:hover {
  background-color: rgba(25, 118, 210, 0.61) !important; 
}

.btn--snakeBorder {
  background: transparent;
  overflow: hidden;
}

.btn--snakeBorder::before {
  content: "";
  position: absolute;
  top: 2px;
  left: 2px;
  bottom: 2px;
}

.btn--snakeBorder span {
  position: absolute;
}

.btn--snakeBorder span:nth-child(1) {
  top: 0;
  left: 0;
  width: 100%;
  height: 2px;
  background: linear-gradient(to right,rgb(0, 0, 0), #1779ff);
  animation: borderAnimation1 2s linear infinite;
}

@keyframes borderAnimation1 {
  0% {
    transform: translateX(-100%);
  }
  100% {
    transform: translateX(100%);
  }
}

.btn--snakeBorder span:nth-child(2) {
  top: 0;
  right: 0;
  width: 2px;
  height: 100%;
  background: linear-gradient(to bottom,rgb(0, 0, 0), #1779ff);
  animation: borderAnimation2 2s linear infinite;
  animation-delay: 1s;
}

@keyframes borderAnimation2 {
  0% {
    transform: translateY(-100%);
  }
  100% {
    transform: translateY(100%);
  }
}

.btn--snakeBorder span:nth-child(3) {
  bottom: 0;
  left: 0;
  width: 100%;
  height: 2px;
  background: linear-gradient(to left,rgb(0, 0, 0), #1779ff);
  animation: borderAnimation3 2s linear infinite;
}

@keyframes borderAnimation3 {
  0% {
    transform: translateX(100%);
  }
  100% {
    transform: translateX(-100%);
  }
}

.btn--snakeBorder span:nth-child(4) {
  top: 0;
  left: 0;
  width: 2px;
  height: 100%;
  background: linear-gradient(to top,rgb(0, 0, 0), #1779ff);
  animation: borderAnimation4 2s linear infinite;
  animation-delay: 1s;
}

@keyframes borderAnimation4 {
  0% {
    transform: translateY(100%);
  }
  100% {
    transform: translateY(-100%);
  }
}
`}
      </style>
      <Link
        href="#services"
        sx={{
          scrollBehavior: "smooth",
          textDecoration: "none",
        }}
      >
        <button
          className="btn btn--snakeBorder"
          onClick={() => {
            handleClick();
          }}
        >
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          Explore Our Solutions
        </button>
      </Link>
    </Box>
  );
};

export default Banner;
