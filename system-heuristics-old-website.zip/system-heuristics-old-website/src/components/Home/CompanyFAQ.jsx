/**
 CompanyFAQ Component:

 1. Displays FAQs in an interactive accordion format.
 2. Fetches data from `Home.json` and maps through the list.
 3. Tracks expanded accordion item with `useState`.
 4. Uses `handleAccordionChange` to allow only one open at a time.
 5. Utilizes MUI components for a structured UI.
 6. Implements Framer Motion and AOS animations.
 7. Adds a downward arrow icon for expandable items.
 8. Enhances UX with a visually appealing, animated FAQ section.
 */

import React from "react";
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  Box,
} from "@mui/material";
import { motion } from "framer-motion";
import ArrowDownwardIcon from "@mui/icons-material/ArrowDownward";
import { useState } from "react";
import OurResultsData from "./Home.json";

const CompanyFAQ = () => {
  const faqsData = OurResultsData?.faqs;
  const [expandedIndex, setExpandedIndex] = useState(null);

  const handleAccordionChange = (index) => {
    setExpandedIndex(expandedIndex === index ? null : index);
  };
  return (
    <>
      {/* Main FAQ's Section  */}
      <Box my={10} mx={[3, 5, 10, 20]} data-aos="zoom-in">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="max-w-3xl mx-auto p-6"
        >
          <Typography fontSize={"var(--heading)"} align="center" gutterBottom>
            Frequently Asked Questions
          </Typography>
          {faqsData?.map((faq, index) => (
            // framer motion for animation
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.2 }}
            >
              {/* Accordion */}
              <Accordion
                expanded={expandedIndex === index}
                onChange={() => handleAccordionChange(index)}
                sx={{
                  my: 2,
                  marginTop: expandedIndex === index ? "20px" : "20px",
                  transition: "margin-top 0.3s ease-in-out",
                }}
              >
                <AccordionSummary
                  expandIcon={<ArrowDownwardIcon />}
                  aria-controls="panel1-content"
                  id={`panel1-header-${index}`}
                >
                  <Typography component="span">{faq.question}</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>{faq.answer}</Typography>
                </AccordionDetails>
              </Accordion>
            </motion.div>
          ))}
        </motion.div>
      </Box>
    </>
  );
};

export default CompanyFAQ;
