/**
 HomeContactForm Component:

 1. Wrapper for the `ContactForm` component.
 2. Uses MUI’s `Box` for structural styling.
 3. Renders `ContactForm` from `../ContactUs/Form/ContactForm`.
 4. Modular and reusable structure.
 5. Enhances code maintainability and reusability.
 */

import React from "react";
import ContactForm from "../ContactUs/Form/ContactForm";
import { Box } from "@mui/material";

function HomeContactForm() {
  return (
    <Box>
      <ContactForm />
    </Box>
  );
}

export default HomeContactForm;
