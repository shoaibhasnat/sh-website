/**
 HomePageIndustries Component:
 
 1. Displays `IndustriesSection` showcasing different industries.
 2. Uses `useNavigate` from `react-router-dom` for navigation.
 3. Implements `handleNavigate` to navigate to "/industries".
 4. Scrolls to the top after navigation using `window.scrollTo(0, 0)`.
 5. Wraps "Explore More" button in `Box` for alignment and spacing.
 6. Uses MUI `Button` with "contained" variant for styling.
 7. Ensures smooth navigation to industry-related content.
 8. Keeps a clean, modular structure for better organization.
 */

import React from "react";
import IndustriesSection from "../Industries/IndustrySection/IndustrySection";
import { Box, Button } from "@mui/material";
import { useNavigate } from "react-router-dom";
import IndustriesData from "../Industries/IndustrySection/SpecificIndustry/SpecificIndustry.json";

function HomePageIndustries() {
  const navigate = useNavigate();

  const handleNavigate = () => {
    navigate("/industries");

    window.scrollTo(0, 0);
  };
  return (
    <>
      {IndustriesData?.industries?.length > 0 && (
        <>
          <IndustriesSection />
          <Box textAlign={"center"} mt={-5} mb={10}>
            <Button variant="contained" onClick={handleNavigate}>
              Explore More
            </Button>
          </Box>
        </>
      )}
    </>
  );
}

export default HomePageIndustries;
