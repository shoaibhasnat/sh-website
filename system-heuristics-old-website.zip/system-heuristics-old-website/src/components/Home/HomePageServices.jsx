/**
 HomePageServices Component:

 1. Renders `ServicesSection` displaying different services offered.
 2. Uses `useNavigate` from `react-router-dom` for navigation.
 3. Wraps `ServicesSection` inside `Box` with `id="services"` for anchor linking.
 4. Implements `handleNavigate` to navigate to "/services".
 5. Scrolls to the top after navigation using `window.scrollTo(0, 0)`.
 6. Includes a centered "Explore More" button inside `Box` for UI.
 7. Uses MUI `Button` with "contained" variant for styling.
 8. Maintains modular structure for reusability.
 */

import React from "react";
import { Box, Button } from "@mui/material";
import { useNavigate } from "react-router-dom";

import ServicesSection from "../Services/ServicesSection/ServicesSection";
import ServicesData from "../Services/ServicesSection/SpecificService/SpecificService.json";

const HomePageServices = () => {
  const navigate = useNavigate();

  const handleNavigate = () => {
    navigate("/services");

    window.scrollTo(0, 0);
  };

  return (
    <>
      {ServicesData?.services?.length > 0 && (
        <>
          <Box id="services">
            <ServicesSection />
          </Box>
          <Box textAlign={"center"} mb={10} mt={[0]}>
            <Button variant="contained" onClick={handleNavigate}>
              Explore More
            </Button>
          </Box>
        </>
      )}
    </>
  );
};

export default HomePageServices;
