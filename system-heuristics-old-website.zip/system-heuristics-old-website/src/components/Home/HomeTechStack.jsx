/**
 * HomeTechStack Component:
 
  1. This component serves as a wrapper for the `TechStack` component.
  2. Uses Material-UI's `Box` component to add spacing around the `TechStack`.
  3. The `mb={[10]}` prop in `Box` provides bottom margin for proper layout spacing.
  4. Keeps the code modular by separating the tech stack section into its own file.
  5. Can be easily reused and included in different parts of the homepage or other pages.
 */

import { Box } from "@mui/material";
import React from "react";
import TechStack from "../Services/TechStack";

function HomeTechStack() {
  return (
    <>
      <Box mb={[10]}>
        <TechStack />
      </Box>
    </>
  );
}

export default HomeTechStack;
