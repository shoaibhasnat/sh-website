/**
 * HomeTestimonials Component:
 
  1. This component is responsible for displaying the testimonials section on the homepage.
  2. It imports and renders the `TestimonialSection` component from the About page directory.
  3. Uses Material-UI's `Box` component to maintain proper layout structure.
  4. Helps keep the code modular and reusable by encapsulating the testimonial section.
  5. Can be easily integrated into different parts of the homepage or other sections.
 */

import React from "react";
import { Box } from "@mui/material";
import TestimonialSection from "../About/Testimonials/Testimonials";

function HomeTestimonials() {
  return (
    <>
      <Box>
        <TestimonialSection />
      </Box>
    </>
  );
}

export default HomeTestimonials;
