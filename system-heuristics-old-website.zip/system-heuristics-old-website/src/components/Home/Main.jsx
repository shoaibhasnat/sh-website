/**
 Main Component:

 1. Layout component for the homepage.
 2. Renders multiple sections to structure the page.
 3. Displays a `Banner` at the top to introduce the website.
 4. Includes `HomePageServices` to showcase services.
 5. Displays `OurResults` for key company achievements.
 6. Adds `HomePageIndustries` to highlight industries served.
 7. Integrates `PortfolioSlider` for past projects.
 8. Features `ChooseUs` to highlight reasons to choose the company.
 9. Shows `HomeTechStack` for company technologies.
 10. Includes `HomeContactForm` for contact option.
 11. Displays `HomeTestimonials` for client reviews.
 12. Ends with `CompanyFAQ` for customer inquiries.
 */

import React from "react";
import Banner from "./Banner";
import ChooseUs from "../About/ChooseUs/ChooseUs";
import CompanyFAQ from "./CompanyFAQ";
import OurResults from "./OurResults";
import HomePageServices from "./HomePageServices";
import HomePageIndustries from "./HomePageIndustries";
import HomeTestimonials from "./HomeTestimonials";
import HomeTechStack from "./HomeTechStack";
import HomeContactForm from "./HomeContactForm";
import OurClients from "./OurClients";

// updated by nadeem
// import PortfolioSlider from "./PortfolioSlider";
// import OurTeam from "../About/OurTeam/OurTeam"

function Main() {
  return (
    <>
      <Banner />
      <HomePageServices />
      <OurResults />
      <HomePageIndustries />

      {/* update by nadeem */}
      {/* <PortfolioSlider /> */}
      {/* <OurTeam /> */}
      <OurClients />
      <ChooseUs />
      <HomeTechStack />
      <HomeContactForm />
      <HomeTestimonials />
      <CompanyFAQ />
    </>
  );
}

export default Main;
