import { Box, Typography, Link, Stack, Tooltip } from "@mui/material";
import Slider from "react-slick";
import OurClientsData from "./Home.json";

const OurClients = () => {
  const clientsData = OurClientsData?.ourClients;
  console.log("clientsData: ", clientsData);

  const settingsTopRow = {
    infinite: true,
    speed: 4000, // Reduce speed for smoother control
    slidesToShow: 5,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 1, // Small value to allow pausing
    pauseOnHover: true, // This should now work
    arrows: false,
    responsive: [
      { breakpoint: 1340, settings: { slidesToShow: 5 } },
      { breakpoint: 1024, settings: { slidesToShow: 4 } },
      { breakpoint: 900, settings: { slidesToShow: 2 } },
      { breakpoint: 600, settings: { slidesToShow: 1 } },
    ],
  };

  return (
    <Box
      sx={{
        py: 8,
      }}
    >
      <Typography
        variant="h5"
        align="center"
        fontWeight="bold"
        fontSize={"var(--heading)"}
        mb={1}
      >
        Our Clients
      </Typography>
      <Typography
        textAlign={"center"}
        color="text.secondary"
        maxWidth={600}
        mx={"auto"}
        mb={10}
      >
        Innovative businesses trust System Heuristics to build scalable digital
        solutions that drive growth and performance. We collaborate with
        future-ready companies to transform their vision into impactful
        technology.
      </Typography>

      <Slider {...settingsTopRow}>
        {clientsData.map((client, index) => (
          <Tooltip title={client?.name} arrow>
            <Stack
              justifyContent={"center"}
              direction={"row"}
              alignItems={"center"}
              mb={3}
            >
              <Link
                href={client.webLink}
                target="_blank"
                rel="noopener"
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  height: 80,
                  minWidth: "100%",
                  "& img": {
                    width: "100%",
                    maxHeight: 70,
                    objectFit: "contain",
                  },
                }}
              >
                <img src={client.logo} alt={client.name} />
              </Link>
            </Stack>
          </Tooltip>
        ))}
      </Slider>
    </Box>
  );
};

export default OurClients;
