/**
 OurResults Component:

 1. Displays company metrics (achievements, clients, projects).
 2. Fetches data from `Home.json` (`ourResults` array).
 3. Uses `react-intersection-observer` for visibility detection.
 4. Triggers a light animation and dot fall effect.
 5. Implements `react-countup` to animate numbers.
 6. Manages `showLight` state for light effect visibility.
 7. Delays light effect by 2 seconds to sync with dot animation.
 8. Uses `styled-components` for button and light effects.
 9. Applies responsive design with media queries.
 10. Uses `Box` for container with background and padding.
 11. Displays title "Our Results" with `Typography`.
 12. Arranges results in a flexible `Stack`.
 13. Wraps results in `StyledWrapper` with light animation.
 14. Uses `CountUp` for smooth numerical animation.
 */

import { Box, Stack, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import CountUp from "react-countup";
import { useInView } from "react-intersection-observer";
import OurResultsData from "./Home.json";
import styled from "styled-components";

function OurResults() {
  const ourResultsData = OurResultsData?.ourResults;

  const { ref, inView } = useInView({
    triggerOnce: true, // Ensures animation triggers only once
    threshold: 0.3, // Adjust visibility threshold for triggering
  });

  const [showLight, setShowLight] = useState(false);

  useEffect(() => {
    if (inView) {
      setTimeout(() => {
        setShowLight(true);
      }, 2000); // Delay to match dot's fall time
    }
  }, [inView]);

  return (
    <Box
      mb={[5, 5, 5]}
      bgcolor={"var(--color-primary)"}
      pb={10}
      ref={ref}
      pt={[0, 0, 5]}
    >
      <Typography
        textAlign={"center"}
        fontSize={"var(--heading)"}
        py={3}
        color="white"
      >
        Our Results
      </Typography>

      <Stack
        px={[3, 15, 10, 25, 10]}
        direction={"row"}
        justifyContent={"center"}
        alignItems={"center"}
        gap={10}
        flexWrap={"wrap"}
        mt={[6, 6, 6, 6, 0]}
      >
        {ourResultsData?.map((result, index) => (
          <StyledWrapper key={index}>
            <div className="light-button">
              <button className="bt">
                <div className="light-holder">
                  <div className={`dot ${inView ? "falling-dot" : ""}`} />
                  {showLight && <div className="light" />}
                </div>
                <div className="button-holder">
                  <Box height={[40, 50, 60]} width={[40, 50, 60]}>
                    <img
                      src={result.image}
                      alt={result.title}
                      height={"100%"}
                      width={"100%"}
                      loading="lazy"
                    />
                  </Box>
                  <Typography
                    fontSize={[40, 36, 40, 45]}
                    fontWeight={"bold"}
                    mt={1}
                  >
                    {inView ? (
                      <CountUp start={0} end={result.number} duration={5} />
                    ) : (
                      "0"
                    )}
                    {/* added by nadeem */}
                    {result.title === "Success score" || result.title === "Repeating clients" ?(
                      "%"
                    ):(
                      "+"
                    )}
                    
                  </Typography>
                  <Typography fontSize={[24, 18, 20, 24]}>
                    {result.title}
                  </Typography>
                </div>
              </button>
            </div>
          </StyledWrapper>
        ))}
      </Stack>
    </Box>
  );
}

// Lamp Light Animation
const StyledWrapper = styled.div`
  .light-button button.bt {
    position: relative;
    height: 300px;
    display: flex;
    align-items: flex-end;
    outline: none;
    background: none;
    border: none;
    justify-content: center;
  }

  .light-button button.bt .button-holder {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 200px;
    width: 200px;
    background-color: rgb(238, 238, 238);
    border-radius: 5px;
    font-weight: 700;
    transition: 300ms;
    outline: 2px solid rgb(255, 255, 255);
    outline-offset: 2px;
    color: rgba(25, 118, 210, 1);
  }

  .light-button button.bt .light-holder {
    position: absolute;
    height: 300px;
    width: 200px;
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  .light-button button.bt .light-holder .dot {
    position: absolute;
    top: -80px; /* Start from above */
    width: 15px;
    height: 15px;
    background-color: rgb(225, 225, 225);
    border-radius: 10px;
    z-index: 2;
    transition: transform 2s ease-out;
  }

  .falling-dot {
    transform: translateY(80px); /* Moves dot to final position */
  }

  .light-button button.bt .light-holder .light {
    position: absolute;
    top: 0;
    width: 600px;
    height: 250px;
    clip-path: polygon(50% 0%, 25% 100%, 75% 100%);
    background: linear-gradient(
      180deg,
      rgb(255, 255, 255) 0%,
      rgba(255, 255, 255, 0) 75%,
      rgba(255, 255, 255, 0) 100%
    ); /* Always applied */
  }

  /* Media query for screen size 1200px or less */
  @media (max-width: 1200px) {
    .light-button button.bt .light-holder .light {
      width: 400px;
    }

    .light-button button.bt .button-holder {
      height: 190px;
      width: 190px;
    }
  }

  /* Media query for screen size 900px or less */
  @media (max-width: 900px) {
    .light-button button.bt .light-holder .light {
      width: 400px;
    }

    .light-button button.bt .button-holder {
      height: 180px;
      width: 180px;
    }
  }

  /* Media query for screen size 600px or less */
  @media (max-width: 600px) {
    .light-button button.bt .light-holder .light {
      width: 350px;
    }

    .light-button button.bt .button-holder {
      height: 200px;
      width: 200px;
    }
  }
`;

export default OurResults;
