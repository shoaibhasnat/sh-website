/*
Industries Banner Component:

1. Displays the top banner section of the Industries page.
2. Plays a Lottie animation from a JSON file using `lottie-react`.
3. Features floating animated cubes in the background via CSS keyframes.
4. Adapts to light and dark themes using MUI’s `useTheme` hook.
5. Dynamically loads text content (heading, description, button) from `Industries.json`.
6. Uses MUI’s `Stack` and `Box` for responsive layout and spacing.
7. Includes an animated SVG-enhanced call-to-action button.
8. Clicking the button smoothly scrolls to `#industriesSection`.
9. Ensures smooth UX with animation delays and error handling.
10. Creates a modern, engaging entry point for the Industries section.
*/

import { Box, Link, Stack, Typography, useTheme } from "@mui/material";
import React from "react";
import { useState, useEffect } from "react";
import styled from "styled-components";
import Lottie from "react-lottie-player";
import IndustriesData from "../Industries.json";

function Banner() {
  const [animationData, setAnimationData] = useState(null);
  const bannerData = IndustriesData.banner; //Fetching industry banner data from Industries.json file

  useEffect(() => {
    // Fetch JSON file from public folder
    fetch(bannerData?.bannerAnimation)
      .then((response) => response.json()) // Parse JSON
      .then((data) => setAnimationData(data)) // Store data in state
      .catch((error) =>
        console.error("Error loading Lottie animation:", error)
      );
  }, [bannerData.bannerAnimation]);

  const theme = useTheme(); // Access the theme to detect mode
  const borderColor =
    theme.palette.mode === "dark"
      ? "var(--color-primary-hover)"
      : "var(--color-primary)";

  return (
    <>
      <Box
        // mt={7}
        pt={[7, 7, 0]}
        height={["100vh"]}
        position={"relative"}
        overflow={"hidden"}
        bgcolor={theme.palette.mode === "dark" ? "black" : "#F0F8FF"}
      >
        {/* Background animation */}

        <style>
          {`
      
.cube {
  position: absolute;
  top: 640px;
  left: 720px;
  width: 10px;
  height: 10px;
  border: 1px solid  ${borderColor};
  transform-origin: top left;
  transform: scale(0) rotate(0deg) translate(-50%, -50%);
  animation: cube 8s ease-in forwards infinite;
}

.cube:nth-child(2n) {
  // border-color: #0054f5;
  
  border-color=${borderColor};

  }


.cube:nth-child(2) {
  animation-delay: -2s;
  left: 400px;
  top: 320px;
}

.cube:nth-child(3) {
  animation-delay: -1s;
  left: 1200px;
  top: 400px;
}

.cube:nth-child(4) {
  animation-delay: 2s;
  left: 1440px;
  top: 280px;
}

.cube:nth-child(5) {
  animation-delay: 0s;
  left: 160px;
  top: 680px;
}

.cube:nth-child(6) {
  animation-delay: 1s;
  left: 1100px;
  top: 100px;
}
.cube:nth-child(7) {
  animation-delay: 2s;
  left: 500px;
  top: 600px;
}
.cube:nth-child(8) {
  animation-delay: -1s;
  left: 100px;
  top: 200px;
}
.cube:nth-child(9) {
  animation-delay: 4s;
  left: 1200px;
  top: 900px;
}
.cube:nth-child(10) {
  animation-delay: 5s;
  left: 1400px;
  top: 500px;

}
.cube:nth-child(11) {
  animation-delay: 6s;
  left: 900px;
  top: 600px;

}.cube:nth-child(12) {
  animation-delay: 1s;
  left: 200px;
  top: 50px;

}.cube:nth-child(13) {
  animation-delay: 8s;
  left: 600px;
  top: 150px;

}

.cube:nth-child(14) {
  animation-delay: 8s;
  left: 10px;
  top: 520px;
}

.cube:nth-child(15) {
  animation-delay: 1s;
  left: 200px;
  top: 400px;
}
.cube:nth-child(16) {
  animation-delay: 5s;
  left: 350px;
  top: 500px;
}
.cube:nth-child(17) {
  animation-delay: -2s;
  left: 100px;
  top: 800px;
}


@keyframes cube {
  from {
    transform: scale(0) rotate(0deg) translate(-50%, -50%);
    opacity: 1;
  }
  to {
    transform: scale(10) rotate(960deg) translate(-50%, -50%);
    opacity: 0;
  }
}

`}
        </style>
        <div className="cube"></div>
        <div className="cube"></div>
        <div className="cube"></div>
        <div className="cube"></div>
        <div className="cube"></div>
        <div className="cube"></div>
        <div className="cube"></div>
        <div className="cube"></div>
        <div className="cube"></div>
        <div className="cube"></div>
        <div className="cube"></div>
        <div className="cube"></div>
        <div className="cube"></div>
        <div className="cube"></div>
        <div className="cube"></div>
        <div className="cube"></div>
        <Stack
          mx={[1, 5, 2, 10]}
          color={theme.palette.mode === "dark" ? "white" : "black"}
          direction={["column", "column", "row"]}
          justifyContent={"center"}
          alignItems={"center"}
          height={"100%"}
          zIndex={1}
          position={"absolute"}
          gap={1}
          pt={["20%", "15%", 0]}
        >
          <Stack px={2} maxWidth={["100%", "100%", "50%"]}>
            <Typography
              fontSize={[
                "var(--font-standard)",
                "var(--font-lg)",
                "var(--font-lg)",
                "var(--font-2xl)",
              ]}
              fontWeight={[
                "var(--font-medium)",
                "var(--font-medium)",
                "var(--font-regular)",
              ]}
            >
              {bannerData.heading}
            </Typography>
            <Typography mt={1} lineHeight={[1.5, 1.5, 2]} textAlign={"justify"}>
              {bannerData.description}
            </Typography>

            {/* Animated Button  */}

            <StyledWrapper style={{ marginTop: 30 }}>
              <Link
                href="#industriesSection"
                sx={{
                  scrollBehavior: "smooth",
                  textDecoration: "none",
                }}
              >
                <button className="animated-button">
                  <svg
                    viewBox="0 0 24 24"
                    className="arr-2"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z" />
                  </svg>

                  <span className="text">{bannerData.buttonText} </span>
                  <span className="circle" />
                  <svg
                    viewBox="0 0 24 24"
                    className="arr-1"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z" />
                  </svg>
                </button>
              </Link>
            </StyledWrapper>
          </Stack>

          {/* Banner Side Animation  */}
          <Box
            mt={[0]}
            height={["100%", "100%", "100%", "100%"]}
            width={["100%", "100%", "100%", "100%"]}
          >
            <Lottie
              loop
              animationData={animationData}
              play
              style={{ height: "100%", width: "100%" }}
            />
          </Box>
        </Stack>
      </Box>
    </>
  );
}

const StyledWrapper = styled.div`
  .animated-button {
    position: relative;
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 12px 36px;
    border: 4px solid;
    border-color: var(--color-primary-hover);
    font-size: 16px;
    background-color: inherit;
    border-radius: 100px;
    font-weight: 600;
    color: var(--color-primary-hover);
    cursor: pointer;
    overflow: hidden;
    transition: all 0.6s cubic-bezier(0.23, 1, 0.32, 1);
  }

  .animated-button svg {
    position: absolute;
    width: 24px;
    fill: var(--color-primary-hover);
    z-index: 9;
    transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
  }

  @media (max-width: 500px) {
    .animated-button {
      padding: 10px 26px;
      border: 3px solid;
      font-size: 14px;
    }
    .animated-button svg {
      width: 20px;
    }
  }

  .animated-button .arr-1 {
    right: 16px;
  }

  .animated-button .arr-2 {
    left: -25%;
  }

  .animated-button .circle {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 20px;
    height: 20px;
    background-color: var(--color-primary);
    border-radius: 50%;
    opacity: 0;
    transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
  }

  .animated-button .text {
    position: relative;
    z-index: 1;
    transform: translateX(-12px);
    transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
  }

  @media (min-width: 900px) {
    .animated-button:hover {
      box-shadow: 0 0 0 12px transparent;
      color: white;
      border-radius: 12px;
    }

    .animated-button:hover .arr-1 {
      right: -25%;
    }

    .animated-button:hover .arr-2 {
      left: 16px;
    }

    .animated-button:hover .text {
      transform: translateX(12px);
    }

    .animated-button:hover svg {
      fill: white;
    }

    .animated-button:active {
      scale: 0.95;
      box-shadow: 0 0 0 4px var(--color-primary);
    }

    .animated-button:hover .circle {
      width: 220px;
      height: 220px;
      opacity: 1;
    }
  }
`;

export default Banner;
