/*
IndustryProcess Component:

1. Outlines the step-by-step process for delivering industry-specific solutions.
2. Fetches content (image, heading, description, steps) from `Industries.json`.
3. Divides layout into a descriptive left section and a dynamic steps section.
4. Left section includes an image, heading, and explanatory text with responsive alignment.
5. Right section displays process steps as styled cards with icons, titles, and descriptions.
6. Uses MUI `Stack` for layout, applying box shadows, padding, and rounded borders.
7. Applies AOS `fade-left` animation for smooth on-scroll effects.
8. Left section stays sticky on large screens for better visibility.
9. Adjusts background color based on theme (light/dark) using `useTheme` hook.
10. Fully responsive, optimized for both mobile and desktop views.
*/

import { Stack, Typography, useTheme } from "@mui/material";
import React from "react";
import IndustriesData from "../Industries.json";

function IndustryProcess() {
  const industryProcessData = IndustriesData.industryProcessSection; //Fetching Industry Process data from Industries.json file
  const theme = useTheme();
  return (
    // Main Container
    <Stack
      p={3}
      px={[1, 1, 5, 15]}
      py={10}
      my={10}
      direction={["column", "column", "row"]}
      justifyContent={"space-evenly"}
      gap={[3, 3, 3]}
      bgcolor={theme.palette.mode === "dark" ? "transparent" : "#f4f4f5"}
    >
      {/* How we work? Section  */}
      <Stack
        p={1}
        height={"100%"}
        minWidth={["100%", "100%", "45%"]}
        alignItems={"center"}
        position={["unset", "unset", "sticky"]}
        top={"12%"}
        px={[3, 10, 0]}
      >
        <img
          src={industryProcessData?.industryProcessImage}
          alt=""
          width={"100%"}
        />
        <Typography fontSize={"var(--heading)"} mb={1} mt={3}>
          {" "}
          {industryProcessData?.heading}
        </Typography>
        <Typography
          fontSize={"var(--description)"}
          textAlign={"center"}
          lineHeight={1.5}
          color="#898989"
        >
          {industryProcessData?.description}
        </Typography>
      </Stack>

      {/* Industry Process Steps Section */}
      <Stack
        p={1}
        gap={5}
        position={"relative"}
        zIndex={99}
        direction={["row"]}
        flexWrap={"wrap"}
        justifyContent={"center"}
        sx={{
          overflowX: "hidden",
        }}
      >
        {industryProcessData?.processSteps.map((step, index) => (
          <Stack
            key={index}
            data-aos="fade-left"
            justifyContent={"center"}
            gap={1}
            p={2}
            minHeight={200}
            maxWidth={[400, 300, 400, 600]}
            borderRadius={"var(--radius)"}
            bgcolor={"white"}
            boxShadow={3}
          >
            <img src={step.img} alt={step.title} height={50} width={50} />
            <Typography variant="h5" color="black">
              {step.title}
            </Typography>
            <Typography color="#898989">{step.description}</Typography>
          </Stack>
        ))}
      </Stack>
    </Stack>
  );
}

export default IndustryProcess;
