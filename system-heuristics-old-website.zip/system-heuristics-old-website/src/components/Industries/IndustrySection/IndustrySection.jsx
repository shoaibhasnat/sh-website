/*
IndustriesSection Component:

1. Displays industries served by the company in a dynamic card layout.
2. Fetches heading, description, and industry data from `Industries.json`.
3. Each card features an animated icon, title, and short description for engagement.
4. Uses a responsive `Stack` with `flexWrap` for optimal display on all screens.
5. Cards scale up, deepen shadows, and animate a gradient underline on hover.
6. Titles animate with gradient text and slight font-size increase on hover.
7. Icons have a zoom-in-out animation for subtle motion.
8. Clicking a card navigates to a specified route and saves the industry title in `localStorage`.
9. Uses `useTheme` to adjust text colors based on light/dark mode.
10. Fully responsive with smooth interactions and custom animations.
*/

import React from "react";
import { Box, Typography, Stack, useTheme } from "@mui/material";
import { useNavigate } from "react-router-dom";
import IndustriesData from "../IndustrySection/SpecificIndustry/SpecificIndustry.json";

const IndustriesSection = () => {
  const allIndustriesData = IndustriesData?.industries; //Fetching All Industries data from Industries.json file

  const navigate = useNavigate(); //function used for navigation
  const theme = useTheme();

  return (
    <>
      {allIndustriesData.length > 0 && (
        <Box
          id={"industriesSection"}
          textAlign="center"
          py={10}
          mx={[3, 3, 3, 0]}
        >
          <Typography fontSize={"var(--heading)"} fontWeight="bold">
            Industries We Serve
          </Typography>
          <Typography
            fontSize={"var(--description)"}
            color="text.secondary"
            mt={1}
            mx={[0, 0, 0, 50]}
          >
            Discover the transformative potential of custom software development
            across diverse industries customized to solve hurdles for e-commerce
            stakeholders.
          </Typography>

          {/* Industry Cards Section  */}
          <Stack
            alignItems="center"
            mt={4}
            direction={"row"}
            justifyContent={"space-evenly"}
            mx={[0, 0, 0, 10]}
            flexWrap={"wrap"}
            flex={"1 1 calc(33.33% -16px)"}
            gap={[0, 0, 5]}
          >
            {allIndustriesData?.map((industry, index) => (
              // Single Industry Card
              <Stack
                bgcolor={"white"}
                data-aos="fade-up"
                key={index}
                justifyContent={"flex-start"}
                alignItems={"center"}
                borderRadius={"var(--radius)"}
                mt={[5, 5, 3]}
                maxWidth={[400, 400, 300]}
                minHeight={[250, 250, 250]}
                // gap={5}
                mx={[0, 0, 5]}
                sx={{
                  p: 2,
                  cursor: "pointer",
                  boxShadow: 3,

                  borderBottom: "4px solid transparent",
                  transition:
                    "transform 0.4s ease-in-out, box-shadow 0.3s ease-in-out",
                  transform: "scale(1)", // Initial scale
                  "&:hover": {
                    transform: "scale(1.1)",

                    boxShadow: 6, // Increase shadow for elevation effect
                    "&::after": {
                      content: '""',
                      position: "absolute",
                      bottom: -5,
                      left: 0,
                      width: "100%",
                      height: "8px", // Border thickness
                      background:
                        "linear-gradient(90deg, #62b6ff, #2769d9, #62b6ff, #62d6ff)",
                      backgroundSize: "300% 100%",
                      animation: "gradientMove 3s ease-in-out infinite",
                      borderBottomRightRadius: 10,
                      borderBottomLeftRadius: 10,
                    },

                    borderBottomRightRadius: 10,
                    borderBottomLeftRadius: 10,
                  },
                  "@keyframes gradientMove": {
                    "0%": { backgroundPosition: "0% 50%" },
                    "50%": { backgroundPosition: "100% 50%" },
                    "100%": { backgroundPosition: "0% 50%" },
                  },

                  "&:hover .cardTitle": {
                    color: "var(--color-primary)",
                    fontSize: 30,
                    background:
                      "linear-gradient(90deg, #62b6ff, #2769d9, #62b6ff, #62d6ff)",
                    backgroundSize: "300% 100%",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    animation: "gradientMove 4s ease-in-out infinite",
                    "@keyframes gradientMove": {
                      "0%": { backgroundPosition: "0% 50%" },
                      "50%": { backgroundPosition: "100% 50%" },
                      "100%": { backgroundPosition: "0% 50%" },
                    },
                  },
                }}
                onClick={() => {
                  navigate(industry?.path);
                  localStorage.setItem("selectedIndustry", industry?.title);
                  window.scrollTo(0, 0);
                }}
              >
                <Box
                  height={60}
                  width={60}
                  borderRadius={"var(--rounded)"}
                  bgcolor={"white"}
                >
                  {/* Zoom-in-out Animation  */}
                  <style>
                    {`
    @keyframes zoomInOut {
      0% {
        transform: scale(0.8);
      }
      50% {
        transform: scale(1.1);
      }
      100% {
        transform: scale(0.8);
      }
    }

    .zooming-img {
      animation: zoomInOut 1.5s infinite ease-in-out;
    }
  `}
                  </style>

                  <img
                    src={industry?.icon}
                    alt={industry?.title}
                    className="zooming-img"
                    height={"100%"}
                    width={"100%"}
                    loading="lazy"
                  />
                </Box>
                <Typography
                  className="cardTitle"
                  variant="h6"
                  fontWeight="bold"
                  mt={1}
                  textAlign={"left"}
                  sx={{
                    transition: "0.3s",
                  }}
                  color="black"
                >
                  {industry?.title}
                </Typography>
                <Typography
                  variant="body2"
                  color={
                    theme.palette.mode === "dark" ? "black" : "text.secondary"
                  }
                  textAlign={"justify"}
                  mt={1}
                >
                  {industry?.description}
                </Typography>
              </Stack>
            ))}
          </Stack>
        </Box>
      )}
    </>
  );
};

export default IndustriesSection;
