/*
IndustryChallenges Component:

1. Displays dynamic problem cards related to the selected industry from localStorage.
2. Fetches industry-specific data from `SpecificIndustry.json` using `selectedIndustry`.
3. Cards have a 3D flip effect, showing an image and title (`frontText`), flipping to reveal a description (`backText`) on hover.
4. Flip animation is handled with `styled-components` for smooth transitions.
5. The front side includes a jumping image animation for interactive feedback.
6. The section background features a branded SVG for a unique design.
7. Fully responsive, with media queries adjusting card sizes for different screens.
8. Cards resemble physical tiles with shadows, border-radius, and intuitive hover effects.
9. Arranges cards in flexbox rows, wrapping neatly on smaller screens.
10. Uses `data-aos` for scroll-triggered animations, enhancing visual appeal.
*/

import { Box, Typography } from "@mui/material";
import React from "react";
import styled from "styled-components";
import SpecificIndustryData from "./SpecificIndustry.json";

const IndustryChallenges = () => {
  const selectedIndustry = localStorage.getItem("selectedIndustry")?.trim();

  const cardsData =
    SpecificIndustryData?.industries?.find(
      (industry) => industry?.title === selectedIndustry
    )?.challenges || null;

  return (
    <>
      {cardsData?.length > 0 && (
        <Box mb={[10, 10, 20]}>
          <Typography
            textAlign={"center"}
            fontSize={["30px", "30px", "var(--heading)"]}
          >
            Specific Problems Related To {selectedIndustry}
          </Typography>
          {/* Animated Cards  */}
          <StyledWrapper>
            {cardsData?.map((card, index) => (
              <div
                className="card"
                key={index}
                data-aos="fade-up"
                data-aos-anchor-placement="top-bottom"
              >
                <div className="card-inner">
                  <div className="card-front">
                    <img
                      src={card.image}
                      alt={card.title}
                      className="card-image"
                    />
                    <h4>{card.frontText}</h4>
                  </div>
                  <div className="card-back">
                    <p>{card.backText}</p>
                  </div>
                </div>
              </div>
            ))}
          </StyledWrapper>
        </Box>
      )}
    </>
  );
};

// Card Animations
const StyledWrapper = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  padding: 50px 20px;
  background: url("https://invozone.com/static/business-model-bg-65a0059f82559be841a4287bd6fbc8a6.svg")
    no-repeat center center/cover;
  border-radius: var(--radius);
  margin: 3% 5% 0 5%;
  spacing: 20px;

  .card {
    margin: 3%;
    width: 100%;

    max-width: 350px;
    height: 300px;
    perspective: 1000px;
    border-radius: var(--radius);
  }

  .card-inner {
    width: 100%;
    height: 100%;
    position: relative;
    transform-style: preserve-3d;
    transition: transform 0.6s;
  }

  .card:hover .card-inner {
    transform: rotateY(180deg);
  }

  .card-front,
  .card-back {
    position: absolute;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
    width: 100%;
    height: 100%;
    backface-visibility: hidden;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    border-radius: var(--radius);
    text-align: center;
    padding: 15px;
  }

  .card-front {
    background-color: white;
    color: black;
  }

  .card-back {
    background-color: var(--color-primary-hover);
    color: white;
    transform: rotateY(180deg);
  }

  .card-image {
    width: 80px;
    height: 80px;
    object-fit: contain;
    animation: jump 2s infinite ease-in-out;
  }

  @keyframes jump {
    0%,
    100% {
      transform: translateY(0);
    }
    50% {
      transform: translateY(-10px);
    }
  }

  @media (max-width: 1024px) {
    .card {
      max-width: 300px;

      margin: 3%;
    }
  }

  @media (max-width: 768px) {
    .card {
      max-width: 300px;
    }
  }

  @media (max-width: 480px) {
    .card {
      max-width: 280px;
    }
  }
`;

export default IndustryChallenges;
