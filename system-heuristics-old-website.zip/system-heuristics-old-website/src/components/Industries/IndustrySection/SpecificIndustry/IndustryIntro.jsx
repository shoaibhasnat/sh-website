/*
Component Description: IndustryIntro

1. Displays an introduction section for the selected industry using dynamically fetched data.
2. Retrieves the industry identifier from `localStorage` using the key `selectedIndustry`.
3. Fetches industry-specific content (title, highlight, description) from `SpecificIndustry.json`.
4. Features a bold heading (`title`), a distinctively colored subheading (`highlight`), and a descriptive paragraph (`description`).
5. Wraps all content in an MUI `Box` with padding and margin for structured spacing.
6. Uses MUI typography utilities to ensure responsive, center-aligned content layout.
7. Integrates AOS (`data-aos="fade-up"`) for smooth scroll-triggered animations.
8. Highlights the subheading in a vibrant blue for visual emphasis.
9. Optimizes readability with muted description text, max-width constraints, and centered alignment.
10. Fully reusable and dynamically updates its content based on the selected industry.
*/

import React from "react";
import { Typography, Box } from "@mui/material";
import SpecificIndustryData from "./SpecificIndustry.json";

const IndustryIntro = () => {
  const selectedIndustry = localStorage.getItem("selectedIndustry")?.trim(); // Fetch the selected industru from local storage

  const introData =
    SpecificIndustryData?.industries?.find(
      (industry) => industry?.title === selectedIndustry
    )?.introSection || null; // Storing specific industry intro data

  if (!introData || Object.keys(introData).length === 0) {
    return null;
  }

  return (
    <Box
      id="industryIntro"
      mb={[5]}
      py={10}
      sx={{
        textAlign: "center",
        px: 2,
      }}
    >
      <Box data-aos="fade-up">
        <Typography
          fontSize={"var(--heading)"}
          component="h2"
          fontWeight="bold"
        >
          {introData?.title}
        </Typography>
        <Typography fontSize={"var(--heading)"} sx={{ color: "#007bff" }}>
          {" "}
          {introData?.highlight}
        </Typography>
        <Typography
          fontSize={"var(--description)"}
          sx={{ color: "#6c757d", mt: 2, maxWidth: "600px", mx: "auto" }}
        >
          {introData?.description}
        </Typography>
      </Box>
    </Box>
  );
};

export default IndustryIntro;
