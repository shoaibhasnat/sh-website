/*
Component Description: IndustryServicesSlider

1. Displays a responsive carousel of industry-specific services using `react-slick`.
2. Retrieves the selected industry name from `localStorage` and fetches relevant data from `SpecificIndustry.json`.
3. Uses `react-slick` to render an autoplay-enabled slider with dynamic responsiveness.
4. Configured to show 1-3 service cards per view based on screen width for optimal layout.
5. Each card presents an icon, title, and description, structured with MUI’s `Card` and `Typography` components.
6. Integrates AOS animations (`flip-left`) for smooth scroll-triggered effects.
7. Custom navigation buttons (`ArrowBackIcon` and `ArrowForwardIcon`) are placed on the sides of the slider.
8. Uses `useRef` to control slider navigation programmatically via the custom buttons.
9. Enhances interactivity with a hover effect that increases box shadow for a lifting appearance.
10. Structured within a centered, responsive container using MUI’s `Box` and `Typography` for seamless adaptability.
*/

import React, { useRef } from "react";
import Slider from "react-slick";
import { Card, CardContent, Typography, Box, IconButton } from "@mui/material";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import SpecificIndustryData from "./SpecificIndustry.json";

const IndustryServicesSlider = () => {
  const selectedIndustry =
    localStorage.getItem("selectedIndustry")?.trim() || null; //Fetching Specific Industry slider data from Industries.json file

  const industryServicesData =
    SpecificIndustryData?.industries?.find(
      (industry) => industry?.title === selectedIndustry
    )?.industryServices?.header || null;

  const sliderData =
    SpecificIndustryData?.industries?.find(
      (industry) => industry?.title === selectedIndustry
    )?.industryServices?.sliderCardsData || null;

  const sliderRef = useRef(null);

  //   Slider customize settings
  const settings = {
    dots: false,
    infinite: true,
    speed: 800,
    autoplay: true,
    autoplaySpeed: 3000,
    slidesToShow: 3,
    slidesToScroll: 1,
    pauseOnHover: true,
    responsive: [
      {
        breakpoint: 1340, // Tablets
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 900, // Mobile
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  return (
    <>
      {sliderData?.length > 0 && (
        <Box sx={{ width: "80%", margin: "auto" }} mb={[10]}>
          {/* Heading Title  */}
          <Typography
            fontSize={"var(--heading)"}
            textAlign={"center"}
            fontWeight="bold"
            gutterBottom
          >
            {industryServicesData?.heading}
          </Typography>
          {/* Description  */}
          <Typography
            fontSize={"var(--description)"}
            textAlign={"center"}
            color="textSecondary"
            gutterBottom
          >
            {industryServicesData?.description}
          </Typography>

          {/* Carousel Box  */}
          <Box
            sx={{ position: "relative", display: "flex", alignItems: "center" }}
            mt={3}
          >
            {/* Custom Previous Arrow */}
            <IconButton
              onClick={() => sliderRef.current.slickPrev()}
              sx={{
                position: "absolute",
                left: {
                  xs: "-30px",
                  sm: "-50px",
                },
                top: "50%",
                transform: "translateY(-50%)",
                zIndex: 1,

                boxShadow: 2,
                background: "var(--color-primary)",
                color: "white",
                "&:hover": {
                  background: "var(--color-primary)",
                  color: "white",
                },
              }}
            >
              <ArrowBackIcon fontSize="small" />
            </IconButton>

            {/* Slider Section  */}
            <Box sx={{ width: "100%", overflow: "hidden" }} py={3}>
              <Slider ref={sliderRef} {...settings}>
                {sliderData?.map((card, index) => (
                  // Single Card
                  <Box
                    data-aos="flip-left"
                    key={index}
                    sx={{
                      px: 2,
                      display: "flex",
                      justifyContent: "center",
                      py: 3,
                    }}
                  >
                    <Card
                      sx={{
                        minHeight: 360,
                        width: "100%",
                        display: "flex",
                        flexDirection: "column",
                        justifyContent: "flex-start",
                        alignItems: "flex-start",
                        boxShadow: 3,
                        borderRadius: "var(--radius)",
                        px: {
                          xs: 0,
                          sm: 2,
                        },
                        pt: 5,

                        "&:hover": { boxShadow: 6 },
                      }}
                    >
                      <img
                        src={card.image}
                        alt={card.title}
                        style={{
                          width: "80px",
                          height: "80px",
                          objectFit: "contain",
                          marginLeft: "12px",
                        }}
                      />
                      <CardContent>
                        <Typography variant="h6" fontWeight="bold">
                          {card.title}
                        </Typography>
                        <Typography
                          variant="body2"
                          color="textSecondary"
                          textAlign={"justify"}
                        >
                          {card.description}
                        </Typography>
                      </CardContent>
                    </Card>
                  </Box>
                ))}
              </Slider>
            </Box>

            {/* Custom Next Arrow */}
            <IconButton
              onClick={() => sliderRef.current.slickNext()}
              sx={{
                position: "absolute",
                right: {
                  xs: "-30px",
                  sm: "-50px",
                },
                top: "50%",
                transform: "translateY(-50%)",
                zIndex: 1,
                "&:hover": {
                  background: "var(--color-primary)",
                  color: "white",
                },
                boxShadow: 2,
                background: "var(--color-primary)",
                color: "white",
              }}
            >
              <ArrowForwardIcon fontSize="small" />
            </IconButton>
          </Box>
        </Box>
      )}
    </>
  );
};

export default IndustryServicesSlider;
