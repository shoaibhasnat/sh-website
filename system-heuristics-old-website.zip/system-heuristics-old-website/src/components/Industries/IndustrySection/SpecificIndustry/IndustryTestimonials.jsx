/*
Component Description: IndustryTestimonials

1. Displays testimonials filtered based on the currently selected industry from `localStorage`.
2. Retrieves testimonials from `SpecificIndustry.json`, filtering by the `category` field matching the selected industry.
3. Uses `currentIndex` state to track the currently displayed testimonial in a slider format.
4. Implements `useEffect` to auto-transition testimonials every 3 seconds, pausing when `isPaused` is true.
5. Renders a layered slider where only the active testimonial has full opacity for smooth visual transitions.
6. Autoplay pauses on hover, allowing users to read testimonials without interruptions.
7. Provides manual navigation using FontAwesome chevron icons to move forward or backward through testimonials.
8. Displays each testimonial in a card format with:
   - A circular profile image,
   - Quote text,
   - Customer’s name,
   - Star-based rating,
   - Location.
9. Dynamically generates star ratings using a helper function based on the testimonial's `rating` value.
10. Uses a decorative background with brand colors to maintain a visually appealing and industry-specific design.
*/

import React from "react";
import { Box, Stack, Typography } from "@mui/material";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircleChevronLeft, faStar } from "@fortawesome/free-solid-svg-icons";
import { useEffect } from "react";
import { useState } from "react";
import SpecificIndustryData from "./SpecificIndustry.json";

const IndustryTestimonials = () => {
  const selectedIndustry =
    localStorage.getItem("selectedIndustry")?.trim() || null; //Gettting Selected Industry from local storage

  const testimonialsData =
    SpecificIndustryData?.industries?.find(
      (industry) => industry?.title === selectedIndustry
    )?.testimonials || null;

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Moving to Next Testimonial
  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonialsData?.length);
  };

  // Moving to Previous Testimonial
  const prevSlide = () => {
    setCurrentIndex(
      (prevIndex) =>
        (prevIndex - 1 + testimonialsData?.length) % testimonialsData?.length
    );
  };

  useEffect(() => {
    if (!isPaused) {
      const interval = setInterval(nextSlide, 3000);
      return () => clearInterval(interval);
    }
  });

  // Dynamic Rating Function
  const renderStars = (rating) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(
        <FontAwesomeIcon
          key={i}
          icon={faStar}
          color={i <= rating ? "#FFEE00" : "lightgray"} // Yellow for filled stars, light gray for empty
        />
      );
    }
    return stars;
  };

  return (
    <>
      {testimonialsData.length > 0 ? (
        <Box
          pt={5}
          color={"white"}
          bgcolor={"var(--color-primary)"}
          sx={{
            backgroundImage: "url('/images/Testimonials-Bg.avif')", // Background image for larger screens

            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat",
            //   backgroundAttachment: "fixed",
          }}
        >
          <Typography
            fontSize={[
              "var(--font-standard)",
              "var(--font-standard)",
              "var(--font-lg)",
            ]}
            textAlign={"center"}
          >
            Testimonials
          </Typography>
          <Typography
            fontSize={"var(--font-md)"}
            textAlign={"center"}
            // color="grey"
            pb={1}
          >
            See what Our Client Say's
          </Typography>
          <Stack
            data-aos="zoom-in"
            mb={[0, 10, 10]}
            direction={"row"}
            justifyContent={"space-between"}
            alignItems={"center"}
            mx={["1%", "3%", "5%", "18%"]}
          >
            <FontAwesomeIcon
              icon={faCircleChevronLeft}
              style={{
                color: "white",
                // color: "var(--color-primary)",
                cursor: "pointer",
              }}
              size="2x"
              onClick={currentIndex === 0 ? undefined : prevSlide}
            />
            {/* Testimonials Box  */}
            <Box
              position="relative"
              overflow="hidden"
              display="flex"
              alignItems="center"
              width="100%"
              height={["600px", "600px", "400px"]}
            >
              {testimonialsData?.map((item, index) => (
                <Stack
                  direction={"row"}
                  justifyContent={"space-evenly"}
                  alignItems={"center"}
                  key={index}
                  sx={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    opacity: index === currentIndex ? 1 : 0,
                    transition: "opacity 0.5s ease-in-out",

                    textAlign: "center",
                  }}
                  onMouseEnter={() => setIsPaused(true)}
                  onMouseLeave={() => setIsPaused(false)}
                >
                  <Stack
                    direction={["column", "column", "row"]}
                    justifyContent={"center"}
                    alignItems={["center", "center", "flex-start"]}
                    gap={[10, 10, 20]}
                  >
                    <Box
                      ml={[-10]}
                      width={["150px", "150px", "160px"]}
                      height={["150px", "150px", "160px"]}
                      sx={{
                        backgroundColor: "white",
                        borderRadius: "50%",
                        position: "relative",
                        zIndex: 1,
                      }}
                    >
                      <Box
                        width={["200px", "200px", "200px"]}
                        height={["200px", "200px", "200px"]}
                        sx={{
                          mt: "12%",
                          ml: "20%",
                          backgroundColor: "white",
                          borderRadius: "50%",
                          position: "relative",
                          zIndex: 2,
                        }}
                      >
                        <Box
                          component="img"
                          src={item.profile}
                          alt=""
                          mt={["10%", "10%", "10%"]}
                          sx={{
                            zIndex: 3,
                            borderRadius: "100%",
                            borderTop: "3px solid white",
                            borderLeft: "3px solid white",
                            borderRight: "3px solid white",
                            backgroundColor: "#E4F2FF",
                            height: {
                              xs: 180,
                              sm: 180,
                              md: 180,
                            },
                            width: {
                              xs: 180,
                              sm: 180,
                              md: 180,
                            },
                          }}
                        />
                      </Box>
                    </Box>

                    {/* Testimonial Content */}
                    <Box textAlign={["center", "center", "left"]}>
                      <Typography
                        variant="body1"
                        sx={{
                          fontStyle: "italic",
                          maxWidth: "500px",
                        }}
                        component={"span"}
                      >
                        "{item.content}"
                      </Typography>
                      <Typography
                        mt={1}
                        variant="h4"
                        sx={{
                          fontWeight: "var(--font-bold)",
                          color: "white",
                          // color: "var(--color-primary)",
                        }}
                      >
                        {item.name}
                      </Typography>
                      {/* Stars */}

                      <Stack
                        direction={"row"}
                        my={1}
                        justifyContent={["center", "center", "flex-start"]}
                      >
                        {renderStars(item.rating)}{" "}
                      </Stack>

                      <Typography
                        fontSize={"var(--font-xs)"}
                        // sx={{ color: "gray" }}
                      >
                        {item.location}
                      </Typography>
                    </Box>
                  </Stack>
                </Stack>
              ))}
            </Box>

            <FontAwesomeIcon
              icon={faCircleChevronLeft}
              style={{
                color: "white",
                // color: "var(--color-primary)",
                cursor: "pointer",
              }}
              size="2x"
              rotation={180}
              onClick={nextSlide}
            />
          </Stack>{" "}
        </Box>
      ) : (
        ""
      )}
    </>
  );
};

export default IndustryTestimonials;
