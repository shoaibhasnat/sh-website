// Main component for rendering the specific industry page layout
// Includes Banner, Introduction, Services, Portfolio, Challenges, Testimonials, and FAQ sections

import React from "react";
import Banner from "./Banner";
import IndustryIntro from "./IndustryIntro";
import IndustryServicesSlider from "./IndustryServicesSlider";
import SpecificIndustryFAQ from "./SpecificIndustryFAQ";
import IndustryChallenges from "./IndustryChallenges";
// import IndustryPortfolio from "./IndustryPortfolio";
import IndustryTestimonials from "./IndustryTestimonials";

function Main() {
  return (
    <>
      <Banner />
      <IndustryIntro />
      <IndustryServicesSlider />
      {/* updated by nadeem */}
      {/* <IndustryPortfolio /> */}
      <IndustryChallenges />
      <IndustryTestimonials />
      <SpecificIndustryFAQ />
    </>
  );
}

export default Main;
