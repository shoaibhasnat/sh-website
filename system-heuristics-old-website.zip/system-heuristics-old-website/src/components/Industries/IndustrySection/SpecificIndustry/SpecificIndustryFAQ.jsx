/*
Component: SpecificIndustryFAQ

1. Displays industry-specific FAQs fetched from `SpecificIndustry.json` via `localStorage`.
2. Uses MUI’s `Accordion` for collapsible panels, ensuring only one is open at a time.
3. Tracks expanded state with `expandedIndex`, toggling on click.
4. Adds `ArrowDownwardIcon` for visual expand/collapse cues.
5. Implements Framer Motion for smooth animations.
6. Ensures responsive spacing with MUI’s `Box` props.
7. Hides the section if no FAQs are available.
*/

import React, { useState } from "react";
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  Box,
} from "@mui/material";
import { motion } from "framer-motion";
import ArrowDownwardIcon from "@mui/icons-material/ArrowDownward";
import SpecificIndustryData from "./SpecificIndustry.json";

const SpecificIndustryFAQ = () => {
  const selectedIndustry = localStorage.getItem("selectedIndustry");
  const industryFAQData =
    SpecificIndustryData?.industries?.find(
      (industry) => industry?.title === selectedIndustry
    )?.faqs || null;

  const [expandedIndex, setExpandedIndex] = useState(null);

  const handleAccordionChange = (index) => {
    setExpandedIndex(expandedIndex === index ? null : index);
  };

  return (
    <>
      {industryFAQData?.length > 0 ? (
        <Box my={10} mx={[3, 5, 10, 20]} data-aos="zoom-in">
          {/* FAQ's Main Section  */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl mx-auto p-6"
          >
            <Typography fontSize={"var(--heading)"} align="center" gutterBottom>
              {selectedIndustry} FAQ's
            </Typography>
            {industryFAQData?.map((faq, index) => (
              // framer motion for animation
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                {/* Accordion */}
                <Accordion
                  expanded={expandedIndex === index}
                  onChange={() => handleAccordionChange(index)}
                  sx={{
                    my: 2,
                    marginTop: expandedIndex === index ? "20px" : "20px",
                    transition: "margin-top 0.3s ease-in-out",
                  }}
                >
                  <AccordionSummary
                    expandIcon={<ArrowDownwardIcon />}
                    aria-controls="panel1-content"
                    id={`panel1-header-${index}`}
                  >
                    <Typography component="span">{faq.question}</Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Typography>{faq.answer}</Typography>
                  </AccordionDetails>
                </Accordion>
              </motion.div>
            ))}
          </motion.div>
        </Box>
      ) : (
        ""
      )}
    </>
  );
};

export default SpecificIndustryFAQ;
