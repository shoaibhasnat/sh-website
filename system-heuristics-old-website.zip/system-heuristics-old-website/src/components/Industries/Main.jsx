/*
Industries Page Component:

1. Serves as the main container for the Industries page layout.
2. Renders key sections: Banner, IndustrySection, IndustryProcess, and ContactForm.
3. <Banner /> provides a visual introduction to the page.
4. <IndustrySection /> showcases industries served by the company.
5. <IndustryProcess /> explains the step-by-step service process.
6. <ContactForm /> enables users to inquire about services.
7. Sections are modular, imported for clean organization and reusability.
8. Uses a React fragment to prevent unnecessary wrapper elements.
9. Optimized for responsiveness, readability, and user engagement.
10. Acts as the entry point for the Industries route, exported as the default module.
*/

import React from "react";
import Banner from "./Banner/Banner";
import IndustrySection from "./IndustrySection/IndustrySection";
import ContactForm from "../ContactUs/Form/ContactForm";
import IndustryProcess from "./IndustrySection/IndustryProcess";

function Main() {
  return (
    <>
      <Banner />
      <IndustrySection />
      <IndustryProcess />
      <ContactForm />
    </>
  );
}

export default Main;
