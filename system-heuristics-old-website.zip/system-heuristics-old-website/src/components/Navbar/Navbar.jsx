/*
Navbar Component:

1. Renders a responsive navigation bar using MUI’s AppBar and Drawer for desktop and mobile views.
2. Dynamically loads branding and menu items from `About.json` for easy updates.
3. Mobile menu toggles via a FontAwesome hamburger icon (`faBars`) and MUI’s Drawer.
4. Highlights the active tab based on route and scroll position for user feedback.
5. Background color and width adjust dynamically based on scroll and route for a sticky, glassmorphic effect.
6. `ScrollLogger` listens for scroll events to toggle navbar background visibility.
7. Uses `react-router-dom` for navigation, ensuring smooth route updates and scroll-to-top behavior.
8. Displays a `Loader` component during route changes with a simulated delay.
9. Uses media queries (`sx` and responsive props) to adjust visibility across screen sizes.
10. Supports branding, routing logic, and customizable styles with CSS variables and MUI system props.
*/

import { useEffect, useState } from "react";
import * as React from "react";
import PropTypes from "prop-types";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import CssBaseline from "@mui/material/CssBaseline";
import Divider from "@mui/material/Divider";
import Drawer from "@mui/material/Drawer";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemText from "@mui/material/ListItemText";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import { Link, useLocation, useNavigate } from "react-router-dom";
import "../../global.css";
import NavbarData from "../About/About.json";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faBars } from "@fortawesome/free-solid-svg-icons";
import { Stack } from "@mui/material";
import Loader from "../Loader/Loader";

const drawerWidth = 240;

const ScrollLogger = ({ onScrollChange }) => {
  useEffect(() => {
    const handleScroll = () => {
      onScrollChange(window.scrollY > 0);
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, [onScrollChange]);

  return null;
};

ScrollLogger.propTypes = {
  onScrollChange: PropTypes.func.isRequired,
};

function Navbar({ window: windowProp }) {
  const navbarData = NavbarData.navbar;
  // const { window } = props;
  const [activeTab, setActiveTab] = useState("/home");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [navbarBg, setNavbarBg] = useState(false);
  const [toolbarWidth, setToolbarWidth] = useState("90%");

  const location = useLocation(); // Get the current URL
  const [navbarColor, setNavbarColor] = useState();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true); // Show loader
    const timeout = setTimeout(() => setLoading(false), 1000); // Simulate loading
    return () => clearTimeout(timeout);
  }, [location.pathname]);

  // Effect to update navbar color on route change
  useEffect(() => {
    setNavbarColor(
      location.pathname === "/" ||
        location.pathname === "/home" ||
        location.pathname === "/home/"
        ? "rgba(255, 255, 255, 0.1)"
        : "var(--color-primary)"
    );
  }, [location.pathname]); // Runs every time the route changes

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 0) {
        setToolbarWidth("80%");
        setNavbarColor("var(--color-primary)");
      } else {
        setToolbarWidth("90%");
        setNavbarColor(
          location.pathname === "/" ||
            location.pathname === "/home" ||
            location.pathname === "/home/"
            ? "rgba(255, 255, 255, 0.1)"
            : "var(--color-primary)"
        );
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [location.pathname]);

  const handleDrawerToggle = () => {
    setMobileOpen((prevState) => !prevState);
  };

  const drawer = (
    <Box onClick={handleDrawerToggle} sx={{ textAlign: "center" }}>
      <Typography
        variant="h5"
        sx={{ my: 2 }}
        onClick={() => handleClick("/home")}
      >
        {navbarData.name}
      </Typography>
      <Divider />
      <List>
        {navbarData.navItems.map((item) => (
          <ListItem key={item.name} disablePadding>
            <ListItemButton
              sx={{ textAlign: "center" }}
              onClick={() => handleClick(item.path)}
            >
              <ListItemText>
                <Link
                  to={item.path}
                  style={{
                    textDecoration: "none",
                    color: "inherit",
                  }}
                >
                  {item.name}
                </Link>
              </ListItemText>
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </Box>
  );

  const navigate = useNavigate();

  const handleClick = (path) => {
    setActiveTab(path);
    navigate(path);
    window.scrollTo(0, 0); // Explicitly refer to the global window
  };

  const container =
    windowProp !== undefined ? () => windowProp().document.body : undefined;
  return (
    <>
      {loading && (
        <Stack
          justifyContent="center"
          alignItems="center"
          height="100vh"
          width="100vw"
          position="fixed"
          top={0}
          left={0}
          bgcolor="rgba(0, 0, 0, 0.58)"
          zIndex={10000} // Ensure it's on the topmost layer
        >
          <Loader />
        </Stack>
      )}
      <ScrollLogger onScrollChange={setNavbarBg} />

      {/* <Box sx={{ display: "flex" }}> */}
      <CssBaseline />
      <AppBar
        component="nav"
        sx={{
          height: 60,
          justifyContent: "center",
          mt: 1,
          backgroundColor: navbarBg ? "transparent" : "transparent", // Correct usage of ternary operator

          boxShadow: "none",
          position: "fixed",
        }}
      >
        <Toolbar
          sx={{
            maxWidth: "1540px",
            width: toolbarWidth,
            minHeight: "auto !important", // Override default minHeight
            height: "unset", // Reset height to default behavior
            mx: "auto",
            transition: "width 0.3s ease-in-out",
            // backgroundColor: "rgba(0, 128, 255, 0.46)",
            backgroundColor: navbarColor,
            backdropFilter: "blur(10px)", // Blurred glass effect
            WebkitBackdropFilter: "blur(10px)", // For Safari support
            boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)", // Soft shadow for depth
            borderRadius: "var(--rounded)", // Optional, for a rounded glass look
          }}
        >
          <Box mt={1}>
            <img
              src={navbarData.logo}
              alt="logo"
              height={40}
              width={40}
              style={{
                borderRadius: "var(--rounded)",
              }}
              loading="lazy"
            />
          </Box>

          <Typography variant="h5" component="div" sx={{ flexGrow: 1, ml: 1 }}>
            <Link
              to={"/home"}
              style={{
                textDecoration: "none",
                color: "inherit",
                textTransform: "none",
              }}
              onClick={() => handleClick("/home")}
            >
              {navbarData.name}
            </Link>
          </Typography>

          <Box sx={{ display: { xs: "none", md: "block" } }}>
            {navbarData.navItems.map((item) => (
              <Button
                key={item.name}
                sx={{
                  // color: "white",
                  color:
                    activeTab === item.path ? "var(--color-primary)" : "white",
                  backgroundColor:
                    activeTab === item.path ? "white" : "transparent",
                  mx: 1,
                  fontSize: 16,
                  "&:hover": {
                    backgroundColor: "white",
                    color: "var(--color-primary)",
                  },
                }}
                onClick={() => handleClick(item.path)}
              >
                <Link
                  to={item.path}
                  style={{
                    textDecoration: "none",
                    color: "inherit",
                    textTransform: "none",
                  }}
                >
                  {item.name}
                </Link>
              </Button>
            ))}
          </Box>

          <Box sx={{ display: { xs: "block", md: "none" } }}>
            <FontAwesomeIcon
              icon={faBars}
              size="xl"
              onClick={handleDrawerToggle}
            />
          </Box>
        </Toolbar>
      </AppBar>
      <nav>
        <Drawer
          container={container}
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true,
          }}
          sx={{
            display: { xs: "block", md: "none" },
            "& .MuiDrawer-paper": {
              boxSizing: "border-box",
              width: drawerWidth,
            },
          }}
        >
          {drawer}
        </Drawer>
      </nav>
      {/* </Box> */}
    </>
  );
}

Navbar.propTypes = {
  window: PropTypes.func,
};

export default Navbar;
