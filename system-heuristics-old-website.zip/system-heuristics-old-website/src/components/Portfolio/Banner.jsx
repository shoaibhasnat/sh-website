/*
Component: Banner (Portfolio Page)

1. Renders the portfolio page's hero section with data from `Portfolio.json`.
2. Uses `lottie-react-player` to load and play an animation dynamically.
3. Arranges text and animation in a responsive `Stack` with `row-reverse` for large screens.
4. Adapts background color based on MUI theme (light/dark).
5. Includes a smooth scrolling button linking to `#portfolioSection`.
6. Features hover effects like color transition, icon movement, and scale bounce.
7. Uses styled-components for scoped CSS.
8. Ensures accessibility with semantic elements and fallback mechanisms.
*/

import { Box, Link, Stack, Typography, useTheme } from "@mui/material";
import React from "react";
import { useState, useEffect } from "react";
import styled from "styled-components";
import Lottie from "react-lottie-player";
import PortfolioData from "./Portfolio.json";

function Banner() {
  const [animationData, setAnimationData] = useState(null);
  const bannerData = PortfolioData.banner; //Fetching portfolio banner data from Portfolio.json file

  useEffect(() => {
    // Fetch JSON file from public folder
    fetch(bannerData?.bannerAnimation)
      .then((response) => response.json()) // Parse JSON
      .then((data) => setAnimationData(data)) // Store data in state
      .catch((error) =>
        console.error("Error loading Lottie animation:", error)
      );
  }, [bannerData.bannerAnimation]);

  const theme = useTheme(); // Access the theme to detect mode

  return (
    <>
      <Box
        // mt={7}
        pt={[7, 7, 0]}
        height={["100vh"]}
        position={"relative"}
        overflow={"hidden"}
        bgcolor={theme.palette.mode === "dark" ? "black" : "#F0F8FF"}
      >
        <Stack
          mx={[1, 5, 2, 10]}
          color={theme.palette.mode === "dark" ? "white" : "black"}
          direction={["column", "column", "row-reverse"]}
          justifyContent={"center"}
          alignItems={"center"}
          height={"100%"}
          zIndex={1}
          position={"absolute"}
          gap={1}
          pt={["20%", "15%", 0]}
        >
          {/* Background Heading & Description  */}
          <Stack px={2} maxWidth={["100%", "100%", "50%"]}>
            <Typography
              fontSize={[
                "var(--font-standard)",
                "var(--font-lg)",
                "var(--font-lg)",
                "var(--font-2xl)",
              ]}
              fontWeight={[
                "var(--font-medium)",
                "var(--font-medium)",
                "var(--font-regular)",
              ]}
            >
              {bannerData.heading}
            </Typography>
            <Typography mt={1} lineHeight={[1.5, 1.5, 2]} textAlign={"justify"}>
              {bannerData.description}
            </Typography>

            {/* Animated Button  */}

            <StyledWrapper style={{ marginTop: 30 }}>
              <Link
                href="#portfolioSection"
                sx={{
                  scrollBehavior: "smooth",
                  textDecoration: "none",
                }}
              >
                <button className="animated-button">
                  <svg
                    viewBox="0 0 24 24"
                    className="arr-2"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z" />
                  </svg>

                  <span className="text">{bannerData.buttonText} </span>
                  <span className="circle" />
                  <svg
                    viewBox="0 0 24 24"
                    className="arr-1"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z" />
                  </svg>
                </button>
              </Link>
            </StyledWrapper>
          </Stack>
          {/* Banner Animation  */}
          <Box
            mt={[0]}
            height={["100%", "100%", "100%", "100%"]}
            width={["100%", "100%", "100%", "100%"]}
          >
            <Lottie
              loop
              animationData={animationData}
              play
              style={{ height: "100%", width: "100%" }}
            />
          </Box>
        </Stack>
      </Box>
    </>
  );
}
//Custom styling & animation for button
const StyledWrapper = styled.div`
  .animated-button {
    position: relative;
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 12px 36px;
    border: 4px solid;
    border-color: var(--color-primary-hover);
    font-size: 16px;
    background-color: inherit;
    border-radius: 100px;
    font-weight: 600;
    color: var(--color-primary-hover);
    cursor: pointer;
    overflow: hidden;
    transition: all 0.6s cubic-bezier(0.23, 1, 0.32, 1);
  }

  .animated-button svg {
    position: absolute;
    width: 24px;
    fill: var(--color-primary-hover);
    z-index: 9;
    transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
  }

  @media (max-width: 500px) {
    .animated-button {
      padding: 10px 26px;
      border: 3px solid;
      font-size: 14px;
    }
    .animated-button svg {
      width: 20px;
    }
  }

  .animated-button .arr-1 {
    right: 16px;
  }

  .animated-button .arr-2 {
    left: -25%;
  }

  .animated-button .circle {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 20px;
    height: 20px;
    background-color: var(--color-primary);
    border-radius: 50%;
    opacity: 0;
    transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
  }

  .animated-button .text {
    position: relative;
    z-index: 1;
    transform: translateX(-12px);
    transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
  }

  @media (min-width: 900px) {
    .animated-button:hover {
      box-shadow: 0 0 0 12px transparent;
      color: white;
      border-radius: 12px;
    }

    .animated-button:hover .arr-1 {
      right: -25%;
    }

    .animated-button:hover .arr-2 {
      left: 16px;
    }

    .animated-button:hover .text {
      transform: translateX(12px);
    }

    .animated-button:hover svg {
      fill: white;
    }

    .animated-button:active {
      scale: 0.95;
      box-shadow: 0 0 0 4px var(--color-primary);
    }

    .animated-button:hover .circle {
      width: 220px;
      height: 220px;
      opacity: 1;
    }
  }
`;

export default Banner;
