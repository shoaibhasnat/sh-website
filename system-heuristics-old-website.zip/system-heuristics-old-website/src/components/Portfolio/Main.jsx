/*
Component: Main (Portfolio Page)

1. Serves as the entry point for the portfolio page layout.
2. Imports and renders `Banner`, `PortfolioIntro`, `PortfolioSection`, and `ContactForm`.
3. `Banner` presents the header section with a title and visuals.
4. `PortfolioIntro` provides an overview of the showcased work.
5. `PortfolioSection` displays portfolio items dynamically.
6. `ContactForm` allows users to inquire or connect.
7. Uses React fragments for a clean vertical layout.
8. Ensures modularity by keeping sections in separate components.
9. Assumes child components handle their own data and animations.
10. Designed for full-page rendering on the `/portfolio` route.
*/

import React from "react";
import Banner from "./Banner";
import PortfolioSection from "./PortfolioSection";
import PortfolioIntro from "./PortfolioIntro";
import ContactForm from "../ContactUs/Form/ContactForm";

function Main() {
  return (
    <>
      <Banner />
      <PortfolioIntro />
      <PortfolioSection />
      <ContactForm />
    </>
  );
}

export default Main;
