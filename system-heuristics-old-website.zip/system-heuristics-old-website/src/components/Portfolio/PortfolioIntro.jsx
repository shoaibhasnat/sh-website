/*
Component: PortfolioIntro

1. Displays an introduction for the portfolio page.
2. Fetches title, highlight, and description from `Portfolio.json`.
3. Uses MUI’s `Box` for central alignment and responsive spacing.
4. Styled with `Typography`, adapting colors for dark/light themes.
5. Highlights key text in blue for emphasis.
6. Ensures readability with a muted grey description and max width.
7. Uses `framer-motion` for fade-in and slide-up animations.
8. Includes AOS (`fade-up`) for additional scroll-based animation.
9. Responsive spacing handled via MUI’s `sx` and `my` props.
10. Animation runs only once when entering the viewport.
*/

import React from "react";
import { Typography, Box, useTheme } from "@mui/material";
import { motion } from "framer-motion";
import PortfolioData from "./Portfolio.json";

const PortfolioIntro = () => {
  const introData = PortfolioData?.introSection;
  const theme = useTheme();

  return (
    <Box
      data-aos="fade-up"
      id="servicesSection"
      my={[10, 10, 15]}
      component={motion.div}
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      viewport={{ once: true }}
      sx={{
        textAlign: "center",
        mt: 10,
        px: 2,
      }}
    >
      <Typography
        fontSize={"var(--heading)"}
        component="h2"
        fontWeight="bold"
        color={theme.palette.mode === "dark" ? "white" : "black"}
      >
        {introData?.title}
      </Typography>
      <Typography fontSize={"var(--heading)"} sx={{ color: "#007bff" }}>
        {" "}
        {introData?.highlight}
      </Typography>
      <Typography
        fontSize={"var(--description)"}
        sx={{ color: "#6c757d", mt: 2, maxWidth: "600px", mx: "auto" }}
      >
        {introData?.description}
      </Typography>
    </Box>
  );
};

export default PortfolioIntro;
