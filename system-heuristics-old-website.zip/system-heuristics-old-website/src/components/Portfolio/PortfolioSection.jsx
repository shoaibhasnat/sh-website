/*
Component: PortfolioSection

1. Displays a filterable portfolio grid from `Portfolio.json`.
2. Projects are categorized (e.g., "A.I", "Web Apps") with toggleable filter buttons.
3. Filters projects dynamically, showing a default of 9 with "See More/Less" controls.
4. Uses MUI’s `Stack` for responsive card layout with hover effects.
5. Animates project entries with `framer-motion` (`AnimatePresence`, `motion.li`).
6. Clicking “View Project” saves the project title in `localStorage` and navigates to its details page.
7. Filter buttons have active styling and smooth animations.
8. Includes a hover "snake-border" effect using keyframe animations.
9. Background features a fixed image for a parallax effect.
10. Fully responsive with media queries for adaptive layouts.
*/

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import PatternBg from "../images/Portfolio-Background.png";
import { Box, Stack, Typography, Button } from "@mui/material";
import PortfolioData from "./SpecificProject/SpecificProject.json";
import { useNavigate } from "react-router-dom";

const PortfolioSection = () => {
  const allProjectsData = Object.values(PortfolioData?.projects || {}).flat(); //fetching portfolio slider data from Portfolio.json
  const [filter, setFilter] = useState("*");
  const [visibleCount, setVisibleCount] = useState(9);
  const navigate = useNavigate();

  const filteredData =
    filter === "*"
      ? allProjectsData
      : allProjectsData.filter((item) => item.category.includes(filter));

  const displayedData = filteredData.slice(0, visibleCount);

  const handleSeeMore = () => {
    setVisibleCount((prev) => prev + 9);
  };

  const handleSeeLess = () => {
    setVisibleCount(9);
  };

  const handleOpenProject = (project) => {
    navigate(`/project/${project?.id}`);
    // setSelectedProject(project?.title);

    localStorage.setItem("selectedProject", project?.projectName);
    window.scrollTo(0, 0);
  };

  return (
    <Box
      id="portfolioSection"
      data-js="hero-demo"
      pt={10}
      sx={{
        backgroundImage: `url(${PatternBg})`,
        backgroundRepeat: "no-repeat",
        backgroundPosition: "center",
        backgroundSize: "cover",
        backgroundAttachment: "fixed",
      }}
    >
      <style>{`

        .grid {
          max-width: 1200px;
          margin: 40px auto;
          padding: 0;
          display: flex;
          flex-wrap: wrap;
          list-style-type: none;
        }
        .grid > li {
          width: calc(100% / 3 - 40px);
          margin: 0px 20px 40px;
          overflow: hidden;
        }
        .filters {
          margin-top: 40px;
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
        }

        .filters button {
          padding: 10px 25px;
          margin: 0px 10px;
          background-color:#f4f4f5;
          border: none;
          border-radius: var(--radius);
          transition: 150ms;
          color:rgb(0, 0, 0);
          font-size: 16px;
          line-height: 25px;
          font-weight: 700;
          outline: none;
          cursor: pointer;
          box-shadow: 3px 3px 10px rgba(0, 0, 0, 0.2);
        }
          .filters button:hover {
          margin-top:-10px;
          }
        .filters button.is-checked {
          background-color: var(--color-primary);
          color:rgb(255, 255, 255);
        }

        @media (max-width: 767px) {
          .filters button {
            padding: 5px 10px;
            margin: 5px;
          }
          .grid > li {
            width: calc(100% - 30px);
          }
          .element-item p {
            font-size: 16px;
            line-height: 22px;
          }
        }
      `}</style>
      <Typography fontSize={"var(--heading)"} textAlign={"center"}>
        Check Our Diverse Portfolio
      </Typography>
      <Box className="ui-group">
        <Box className="filters button-group js-radio-button-group device-type">
          <Button
            className={`button ${filter === "*" ? "is-checked" : ""}`}
            onClick={() => {
              setFilter("*");
              setVisibleCount(9);
            }}
          >
            All
          </Button>
          <Button
            className={`button ${filter === "A.I" ? "is-checked" : ""}`}
            onClick={() => {
              setFilter("A.I");
              setVisibleCount(9);
            }}
          >
            A.I
          </Button>
          <Button
            className={`button ${
              filter === "Custom Software" ? "is-checked" : ""
            }`}
            onClick={() => {
              setFilter("Custom Software");
              setVisibleCount(9);
            }}
          >
            Custom Software
          </Button>
          <Button
            className={`button ${filter === "Web Apps" ? "is-checked" : ""}`}
            onClick={() => {
              setFilter("Web Apps");
              setVisibleCount(9);
            }}
          >
            Web Apps
          </Button>
        </Box>
      </Box>
      <ul className="grid">
        <AnimatePresence>
          {displayedData.map((project, index) => (
            <motion.li
              key={index}
              className={`element-item ${project.category}`}
              data-category={project.category}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.3 }}
            >
              <Stack
                data-aos="zoom-in"
                borderRadius={"var(--radius)"}
                justifyContent={"center"}
                alignItems={"center"}
                gap={1}
                p={3}
                textAlign={"center"}
                sx={{
                  transition: "0.3s",
                  color: "black",
                  "&:hover": {
                    bgcolor: "var(--color-primary)",
                    color: "white",
                    p: 2,
                    cursor: "pointer",
                    "& .btn--snakeBorder": {
                      color: "white",
                    },
                  },
                }}
                bgcolor={"#f4f4f5"}
              >
                <Box maxWidth={300} maxHeight={300}>
                  <img
                    src={project?.banner?.bannerImage}
                    alt=""
                    height={"100%"}
                    width={"100%"}
                  />
                </Box>
                <Typography variant="h5">{project?.projectName}</Typography>
                {/* <Typography>{project?.banner?.description}</Typography> */}
                <style>
                  {`.btn {
  position: relative;
  display: inline-block;
  padding: 12px 20px;
  color: var(--color-primary);
  font-size: 12px;
  font-weight: bold;
  letter-spacing: 2px;
  border-radius: 5px;
  outline: none;
  border: none;
  cursor: pointer;
  text-transform: uppercase;
  box-sizing: border-box;
  box-shadow:120px
}


/* Hover effect */
.btn--snakeBorder:hover {
  background-color: var(--color-primary-hover); 
  
  color: white;
}

.btn--snakeBorder {
  background: var(--color0primary);
  overflow: hidden;
}

.btn--snakeBorder::before {
  content: "";
  position: absolute;
  top: 2px;
  left: 2px;
  bottom: 2px;
}

.btn--snakeBorder span {
  position: absolute;
}

.btn--snakeBorder span:nth-child(1) {
  top: 0;
  left: 0;
  width: 100%;
  height: 2px;
  background: linear-gradient(to right,rgb(255, 255, 255), #1779ff);
  animation: borderAnimation1 2s linear infinite;
}

@keyframes borderAnimation1 {
  0% {
    transform: translateX(-100%);
  }
  100% {
    transform: translateX(100%);
  }
}

.btn--snakeBorder span:nth-child(2) {
  top: 0;
  right: 0;
  width: 2px;
  height: 100%;
  background: linear-gradient(to bottom,rgb(255, 255, 255), #1779ff);
  animation: borderAnimation2 2s linear infinite;
  animation-delay: 1s;
}

@keyframes borderAnimation2 {
  0% {
    transform: translateY(-100%);
  }
  100% {
    transform: translateY(100%);
  }
}

.btn--snakeBorder span:nth-child(3) {
  bottom: 0;
  left: 0;
  width: 100%;
  height: 2px;
  background: linear-gradient(to left,rgb(255, 255, 255), #1779ff);
  animation: borderAnimation3 2s linear infinite;
}

@keyframes borderAnimation3 {
  0% {
    transform: translateX(100%);
  }
  100% {
    transform: translateX(-100%);
  }
}

.btn--snakeBorder span:nth-child(4) {
  top: 0;
  left: 0;
  width: 2px;
  height: 100%;
  background: linear-gradient(to top,rgb(255, 255, 255), #1779ff);
  animation: borderAnimation4 2s linear infinite;
  animation-delay: 1s;
}

@keyframes borderAnimation4 {
  0% {
    transform: translateY(100%);
  }
  100% {
    transform: translateY(-100%);
  }
}
`}
                </style>

                <button
                  className="btn btn--snakeBorder"
                  onClick={() => {
                    handleOpenProject(project);
                  }}
                >
                  <span></span>
                  <span></span>
                  <span></span>
                  <span></span>
                  View Project
                </button>
              </Stack>
            </motion.li>
          ))}
        </AnimatePresence>
      </ul>
      <div style={{ textAlign: "center" }}>
        {visibleCount < filteredData.length && (
          <Button variant="contained" onClick={handleSeeMore}>
            See More
          </Button>
        )}
        {visibleCount >= filteredData.length && filteredData.length > 9 && (
          <Button variant="contained" onClick={handleSeeLess}>
            See Less
          </Button>
        )}
      </div>
    </Box>
  );
};

export default PortfolioSection;
