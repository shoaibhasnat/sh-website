/*
Component: Banner (Specific Project Page)

1. Renders the hero section for a specific project.
2. Fetches project name from `localStorage` ("selectedProject").
3. Retrieves banner data from `SpecificProject.json`.
4. Displays a heading, description, and project-specific image.
5. Uses MUI’s `Stack` for responsive column/row alignment.
6. Adapts colors based on the current theme (dark/light).
7. Includes an animated "Explore Project" button with hover effects.
8. Clicking the button scrolls smoothly to `#projectIntro`.
9. Ensures responsiveness for mobile and desktop layouts.
10. Adds animations for a polished user experience.
*/

import { Box, Link, Stack, Typography, useTheme } from "@mui/material";
import React from "react";
import styled from "styled-components";
import SpecificProjectData from "./SpecificProject.json";
import { useState } from "react";
import { useEffect } from "react";

function Banner() {
  const theme = useTheme();
  const [bannerData, setBannerData] = useState(null);

  useEffect(() => {
    const selectedProject = localStorage.getItem("selectedProject")?.trim();
    if (!selectedProject) return;
    // Find the project object whose projectName matches
    const project = SpecificProjectData.projects.find(
      (p) => p.projectName === selectedProject
    );

    setBannerData(project?.banner ?? null);
  }, []);

  return (
    <>
      {/* Main Box  */}

      <Box
        id="SpecificService"
        // mt={7}
        pt={[7, 7, 0]}
        height={"100vh"}
        position={"relative"}
        overflow={"hidden"}
        mb={10}
        bgcolor={theme.palette.mode === "dark" ? "black" : "#F0F8FF"}
      >
        <Stack
          mx={[2, 5, 2, 20]}
          // mt={[5, 5, 0]}
          color={theme.palette.mode === "dark" ? "white" : "black"}
          direction={["column", "column", "row"]}
          justifyContent={"center"}
          alignItems={"center"}
          height={"100%"}
          zIndex={1}
          position={"absolute"}
          gap={11}
        >
          <Stack px={2} justifyContent={"center"} alignItems={"flex-start"}>
            <Typography
              fontSize={[
                "var(--font-standard)",
                "var(--font-lg)",
                "var(--font-xl)",
                "var(--font-xl)",
              ]}
              fontWeight={[
                "var(--font-medium)",
                "var(--font-medium)",
                "var(--font-regular)",
              ]}
            >
              {bannerData?.heading}
            </Typography>
            <Typography mt={1} lineHeight={[1.5, 1.5, 2]} textAlign={"justify"}>
              {bannerData?.description}
            </Typography>

            {/* Animated Button  */}
            <StyledWrapper style={{ marginTop: 30 }}>
              <Link
                href="#projectIntro"
                sx={{
                  scrollBehavior: "smooth",
                  textDecoration: "none",
                }}
              >
                <button className="animated-button">
                  <svg
                    viewBox="0 0 24 24"
                    className="arr-2"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z" />
                  </svg>

                  <span className="text">Explore Project </span>
                  <span className="circle" />
                  <svg
                    viewBox="0 0 24 24"
                    className="arr-1"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z" />
                  </svg>
                </button>
              </Link>
            </StyledWrapper>
          </Stack>
          {bannerData?.bannerImage && (
            <Box maxWidth={["100%", "50%"]} maxHeight={"100%"}>
              <img
                style={{ borderRadius: "var(--radius)" }}
                src={bannerData?.bannerImage}
                alt="Banner"
                height={"100%"}
                width={"100%"}
              />
            </Box>
          )}
        </Stack>
      </Box>
    </>
  );
}

// Wrapper for animated button
const StyledWrapper = styled.div`
  .animated-button {
    position: relative;
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 12px 36px;
    border: 4px solid;
    border-color: var(--color-primary-hover);
    font-size: 16px;
    background-color: inherit;
    border-radius: 100px;
    font-weight: 600;
    color: var(--color-primary-hover);
    cursor: pointer;
    overflow: hidden;
    transition: all 0.6s cubic-bezier(0.23, 1, 0.32, 1);
  }

  .animated-button svg {
    position: absolute;
    width: 24px;
    fill: var(--color-primary-hover);
    z-index: 9;
    transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
  }

  @media (max-width: 500px) {
    .animated-button {
      padding: 10px 26px;
      border: 3px solid;
      font-size: 14px;
    }
    .animated-button svg {
      width: 20px;
    }
  }

  .animated-button .arr-1 {
    right: 16px;
  }

  .animated-button .arr-2 {
    left: -25%;
  }

  .animated-button .circle {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 20px;
    height: 20px;
    background-color: var(--color-primary);
    border-radius: 50%;
    opacity: 0;
    transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
  }

  .animated-button .text {
    position: relative;
    z-index: 1;
    transform: translateX(-12px);
    transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
  }

  @media (min-width: 900px) {
    .animated-button:hover {
      box-shadow: 0 0 0 12px transparent;
      color: white;
      border-radius: 12px;
    }

    .animated-button:hover .arr-1 {
      right: -25%;
    }

    .animated-button:hover .arr-2 {
      left: 16px;
    }

    .animated-button:hover .text {
      transform: translateX(12px);
    }

    .animated-button:hover svg {
      fill: white;
    }

    .animated-button:active {
      scale: 0.95;
      box-shadow: 0 0 0 4px var(--color-primary);
    }

    .animated-button:hover .circle {
      width: 220px;
      height: 220px;
      opacity: 1;
    }
  }
`;

export default Banner;
