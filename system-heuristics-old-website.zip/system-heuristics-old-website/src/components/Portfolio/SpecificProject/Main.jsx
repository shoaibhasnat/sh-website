/*
Component: Main (Project Page)

1. Renders the detailed view of a specific project.
2. `Banner` displays project title, subtitle, and hero visual.
3. `ProjectIntro` provides an overview of the project’s purpose.
4. `ProjectFeatures` highlights key functionalities.
5. `ProjectChallenges` outlines technical difficulties faced.
6. `ProposedSolution` explains the solutions implemented.
7. `TeamSection` showcases the project team members.
8. `ProjectGallery` displays images/screenshots of the project.
9. `ProjectVideo` embeds a demo or promotional video.
10. `ProjectTestimonials` presents user/client feedback.
11. `SpecificProjectFAQ` answers common project-related questions.
*/

import React from "react";
import Banner from "./Banner";
import ProjectIntro from "./ProjectIntro";
import SpecificProjectFAQ from "./SpecificProjectFAQ";
import ProjectChallenges from "./ProjectChallenges";
import ProposedSolution from "./ProposedSolution";
import ProjectGallery from "./ProjectGallery";
import ProjectVideo from "./ProjectVideo";
import ProjectFeatures from "./ProjectFeatures";
import TeamSection from "./TeamSection";
import ProjectTestimonials from "./ProjectTestimonials";

function Main() {
  return (
    <>
      <Banner />
      <ProjectIntro />
      <ProjectFeatures />
      <ProjectChallenges />
      <ProposedSolution />
      <TeamSection />
      <ProjectGallery />
      <ProjectVideo />
      <ProjectTestimonials />
      <SpecificProjectFAQ />
    </>
  );
}

export default Main;
