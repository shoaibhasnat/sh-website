/*
Component: ProjectChallenges (Specific Project Page)

1. Displays key challenges faced during project execution.
2. Fetches project name from `localStorage` ("selectedProject").
3. Retrieves challenge data from `SpecificProject.json`.
4. Uses a full-width background image with light text on dark.
5. Organized in a responsive `Stack` (row/column layout).
6. Each challenge appears in a white card with shadow & rounded corners.
7. AOS (`zoom-in`) animations for interactive appearance.
8. Heading: “CHALLENGES FACED” with a descriptive subheading.
9. Adapts styling dynamically for light/dark themes.
10. Ensures proper spacing, padding, and responsiveness.
*/

import React from "react";
import { Stack, Typography, useTheme } from "@mui/material";
import SpecificProjectData from "./SpecificProject.json";
import { useState } from "react";
import { useEffect } from "react";

const ProjectChallenges = () => {
  const theme = useTheme();
  const [challenges, setChallenges] = useState([]);

  // Load challenges for the selected project
  useEffect(() => {
    const selectedProject = localStorage.getItem("selectedProject")?.trim();
    if (!selectedProject) return;
    const project = SpecificProjectData.projects.find(
      (p) => p.projectName === selectedProject
    );
    setChallenges(project?.challengesFaced || []);
  }, []);

  return (
    <>
      {challenges.length > 0 && (
        <Stack
          pb={[5, 5, 10]}
          spacing={2}
          alignItems="center"
          sx={{
            backgroundImage: `url("/images/Portfolio-Slider-Bg.jpg")`,
            backgroundSize: "cover", // Ensures the image covers the entire box
            backgroundPosition: "center", // Centers the image
            backgroundRepeat: "no-repeat", // Prevents repeating
            backgroundColor: "var(--color-primary)",
            padding: "50px 20px",
          }}
        >
          <Typography
            data-aos="fade-up"
            variant="h6"
            color="white"
            fontWeight={"bold"}
          >
            CHALLENGES FACED
          </Typography>
          <Typography
            data-aos="fade-up"
            fontSize={["24px", "var(--heading)"]}
            color="#E6E6E6"
            fontWeight={700}
            textAlign="center"
          >
            Overcoming Complexities in <br /> Project Execution
          </Typography>

          <Stack spacing={3}>
            <Stack
              direction={{ xs: "column", md: "row" }}
              justifyContent={"center"}
              alignItems={"center"}
              flexWrap={"wrap"}
            >
              {/* Map Project challenges data  */}
              {challenges?.map((challenge, index) => (
                <Stack
                  data-aos="zoom-in"
                  key={index}
                  sx={{ maxWidth: 500, minHeight: 200 }}
                  maxWidth={500}
                  minHeight={200}
                  justifyContent={"center"}
                  borderRadius={"var(--radius)"}
                  m={2}
                  p={5}
                  bgcolor={"white"}
                  boxShadow={3}
                  color={"black"}
                >
                  <Typography variant="h6" fontWeight={700}>
                    {challenge.title}
                  </Typography>
                  <Typography
                    variant="body2"
                    color={
                      theme.palette.mode === "dark" ? "grey" : "text.secondary"
                    }
                  >
                    {challenge.description}
                  </Typography>
                </Stack>
              ))}
            </Stack>
          </Stack>
        </Stack>
      )}
    </>
  );
};

export default ProjectChallenges;
