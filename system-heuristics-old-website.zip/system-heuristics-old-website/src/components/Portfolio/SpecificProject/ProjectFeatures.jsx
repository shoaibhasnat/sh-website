/*
Component: ProjectFeatures (Specific Project Page)

1. Displays the "Main Features" section for the selected project.
2. Fetches project name from `localStorage` ("selectedProject").
3. Retrieves feature data from `SpecificProject.json`.
4. Organized into two columns using MUI's `Stack`:
   - Left: heading, description, and bullet-style feature list.
   - Right: an image with rounded corners.
5. Features use `ArrowCircleRightIcon` for clarity.
6. Responsive—image moves below text on smaller screens.
7. AOS animations (`fade-up`, `fade-down`) for smooth scrolling effects.
8. Dynamically adjusts based on the number of features in JSON.
9. Theming applied via CSS variables (`--color-primary`, `--radius`).
10. Clean, structured layout ensuring readability and visual appeal.
*/

import React, { useState, useEffect } from "react";
import { Box, Stack, Typography } from "@mui/material";
import ArrowCircleRightIcon from "@mui/icons-material/ArrowCircleRight";
import SpecificProjectData from "./SpecificProject.json";

function ProjectFeatures() {
  // 1) State for this project’s features
  const [mainFeatures, setMainFeatures] = useState(null);

  // 2) On mount, pick up the stored project name and load its mainFeatures
  useEffect(() => {
    const selectedProject = localStorage.getItem("selectedProject")?.trim();
    if (!selectedProject) return;

    const project = SpecificProjectData.projects.find(
      (p) => p.projectName === selectedProject
    );
    setMainFeatures(project?.mainFeatures ?? null);
  }, []);

  // 3) If there's no data or no feature items, render nothing
  if (!mainFeatures) {
    return null;
  }

  return (
    <>
      {mainFeatures && (
        <Box mb={[5, 5, 10]}>
          <Stack
            mx={[3, 5, 20]}
            mb={[5, 5, 20]}
            direction={["column-reverse", "column-reverse", "row"]}
            justifyContent="space-between"
            alignItems="center"
            gap={5}
          >
            {/* Left Section: Text Content */}
            <Stack spacing={3} p={[1, 1, 3]} data-aos="fade-up">
              <Typography
                color="var(--color-primary)"
                variant="h5"
                fontWeight="bold"
              >
                {mainFeatures?.heading}
              </Typography>
              <Typography color="#6e777f">
                {mainFeatures?.description}
              </Typography>

              {/* Features List */}
              <Stack spacing={1}>
                {mainFeatures?.features?.map((item, idx) => (
                  <Stack key={idx} direction="row" alignItems="center" gap={1}>
                    <ArrowCircleRightIcon
                      sx={{ color: "var(--color-primary)" }}
                    />
                    <Typography fontSize={18} fontWeight="bold">
                      {item}
                    </Typography>
                  </Stack>
                ))}
              </Stack>
            </Stack>

            {/* Right Section: Image */}
            {mainFeatures?.image && (
              <Stack
                data-aos="fade-down"
                alignItems="center"
                minWidth={["40%"]}
                maxWidth={["100%", "100%", "50%"]}
              >
                <img
                  src={mainFeatures?.image}
                  alt="Project Feature"
                  height="100%"
                  width="100%"
                  style={{ borderRadius: "var(--radius)" }}
                />
              </Stack>
            )}
          </Stack>
        </Box>
      )}
    </>
  );
}

export default ProjectFeatures;
