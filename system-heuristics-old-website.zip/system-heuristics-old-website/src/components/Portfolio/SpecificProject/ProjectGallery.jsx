/*
Component: ProjectGallery (Specific Project Page)

1. Displays a gallery for the selected project using two auto-scrolling sliders.
2. Retrieves project name from `localStorage` and matches `galleryImages` in `SpecificProject.json`.
3. Styled with a background image and white text for contrast.
4. Shows "Our Gallery" heading and a subheading at the top.
5. Uses `react-slick` sliders:
   - Top row scrolls left to right.
   - Bottom row scrolls right to left (`rtl: true`).
6. Images are inside `Box` with `data-aos` animations (`flip-left`, `flip-right`).
7. Images have a fixed height (`200px`) and consistent border radius (`var(--radius)`).
8. Responsive settings adjust visible slides based on screen width.
9. Smooth scrolling effect (`autoplaySpeed: 1`, `speed: 4000`).
10. Renders gallery only if `galleryData` exists for the selected project.
*/

import React from "react";
import Slider from "react-slick";
import { Box, Typography } from "@mui/material";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import SpecificProjectData from "./SpecificProject.json";
import { useState } from "react";
import { useEffect } from "react";

function ProjectGallery() {
  const [galleryData, setGalleryData] = useState([]);

  useEffect(() => {
    const selectedProject = localStorage.getItem("selectedProject")?.trim();
    if (!selectedProject) return;

    const project = SpecificProjectData.projects.find(
      (p) => p.projectName === selectedProject
    );
    setGalleryData(project?.galleryImages || []);
  }, []);

  // Settings for the first row (left to right)

  const settingsTopRow = {
    infinite: true,
    speed: 4000, // Reduce speed for smoother control
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 1, // Small value to allow pausing
    pauseOnHover: true, // This should now work
    arrows: false,
    responsive: [
      { breakpoint: 1340, settings: { slidesToShow: 3 } },
      { breakpoint: 900, settings: { slidesToShow: 2 } },
      { breakpoint: 600, settings: { slidesToShow: 1 } },
    ],
  };

  // Settings for the second row (right to left)
  const settingsBottomRow = {
    ...settingsTopRow,
    rtl: true, // Enables right-to-left scrolling
  };

  return (
    <>
      {galleryData.length > 0 ? (
        <Box
          sx={{
            backgroundImage: "url('/images/Our-Gallery-Bg.jpg')", // Background image
            backgroundSize: "cover",
            backgroundPosition: "top",
            backgroundRepeat: "no-repeat",
          }}
          color={"white"}
          py={5}
          mb={10}
        >
          <Typography fontSize={"var(--heading)"} textAlign={"center"}>
            Our Gallery
          </Typography>
          <Typography
            fontSize={"var(--description)"}
            textAlign={"center"}
            color="#8EC6FF"
            pb={1}
          >
            Explore our project gallery to see our creativity and craftsmanship
            in action.
          </Typography>

          <Box mx={[3, 5, 10, 20]} mt={3} overflow="hidden">
            {/* First Row (Left to Right) */}
            <Slider {...settingsTopRow}>
              {galleryData.map((image, index) => (
                <>
                  {galleryData && (
                    <Box key={index} p={1} data-aos="flip-left">
                      <img
                        src={image}
                        alt={`Gallery ${index + 1}`}
                        style={{
                          width: "100%",
                          height: "200px",
                          borderRadius: "var(--radius)",
                        }}
                      />
                    </Box>
                  )}
                </>
              ))}
            </Slider>

            {/* Second Row (Right to Left) */}
            <Slider {...settingsBottomRow}>
              {galleryData.map((image, index) => (
                <Box key={index} p={1} data-aos="flip-right">
                  <img
                    src={image}
                    alt={`Gallery ${index + 1}`}
                    style={{
                      width: "100%",
                      height: "200px",
                      borderRadius: "var(--radius)",
                    }}
                  />
                </Box>
              ))}
            </Slider>
          </Box>
        </Box>
      ) : (
        ""
      )}
    </>
  );
}

export default ProjectGallery;
