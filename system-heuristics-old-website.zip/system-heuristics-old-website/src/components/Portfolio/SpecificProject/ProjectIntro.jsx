/*
Component: ProjectIntro (Specific Project Page)

1. Fetches project name from `localStorage` and retrieves details from `SpecificProject.json`.
2. Displays project summary with title, highlighted phrase, and description.
3. Shows "Our Client" section with client’s name, company, and industry from JSON.
4. Lists services provided to the client, each with a `CheckCircleIcon`.
5. Displays "No services available" if no services exist.
6. Features a "Problem Statement" section with a gradient background and animated transition.
7. Lists problem points, each prefixed with a check icon for clarity.
8. Uses `Stack` for a responsive layout, switching between column and row.
9. Includes `data-aos` animations (`fade-up`, `flip-up`) for smooth scrolling effects.
10. Ensures consistent styling with theming variables (`var(--heading)`, `var(--radius)`, etc.).
*/

import React, { useState, useEffect } from "react";
import { Typography, Box, Stack } from "@mui/material";
import SpecificProjectData from "./SpecificProject.json";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";

const ProjectIntro = () => {
  // hold the intro section data for the selected project
  const [introData, setIntroData] = useState(null);

  // on mount, read localStorage and pull the matching project from the JSON array
  useEffect(() => {
    const selectedProject = localStorage.getItem("selectedProject")?.trim();
    if (!selectedProject) return;

    const proj = SpecificProjectData.projects.find(
      (p) => p.projectName === selectedProject
    );
    setIntroData(proj?.introSection ?? null);
  }, []);

  // show a simple loading state until we have introData
  if (!introData) {
    return (
      <Box
        height="50vh"
        display="flex"
        justifyContent="center"
        alignItems="center"
      >
        <Typography>Loading project intro…</Typography>
      </Box>
    );
  }

  // now safe to destructure
  const introSummary = introData.summary;
  const clientDetails = introData.clientDetail;
  const clientServicesData = clientDetails.clientServices || [];

  return (
    <>
      <Box
        id="projectIntro"
        mb={[10]}
        bgcolor={"#f4f4f5"}
        mx={[2, 3, 10, 20]}
        borderRadius={"var(--radius)"}
        py={[10]}
        px={[1, 2, 5]}
      >
        <Box
          data-aos="fade-up"
          sx={{
            textAlign: "center",
            px: 2,
          }}
          mb={[8]}
        >
          <Typography
            fontSize={["24px", "var(--heading)"]}
            component="h2"
            fontWeight="bold"
            sx={{ color: "#000" }}
          >
            {introSummary?.title}
          </Typography>
          <Typography
            fontSize={["24px", "var(--heading)"]}
            sx={{ color: "#007bff" }}
          >
            {" "}
            {introSummary?.highlight}
          </Typography>
          <Typography
            fontSize={"var(--description)"}
            sx={{ color: "#6c757d", mt: 2, maxWidth: "600px", mx: "auto" }}
          >
            {introSummary?.description}
          </Typography>
        </Box>

        {/* Client Details */}
        <Typography
          fontSize={"var(--heading)"}
          textAlign={"center"}
          mb={3}
          color="black"
        >
          Our Client
        </Typography>

        <Stack
          data-aos="flip-up"
          border={"3px solid var(--color-primary)"}
          direction={["column", "column", "row"]}
          justifyContent={"space-evenly"}
          alignItems={"center"}
          textAlign={["center", "center", "left"]}
          gap={1}
          py={5}
          mx={[1, 1, 5, 10, 20]}
          borderRadius={"var(--radius)"}
          bgcolor={"white"}
          color={"black"}
        >
          <Stack spacing={2} p={[1, 2]}>
            <Typography variant="h3" color="var(--color-primary)">
              {clientDetails?.clientName || "N/A"}
            </Typography>
            {clientDetails?.companyName && (
              <Typography>
                <b>Comany:</b> {clientDetails?.companyName}
              </Typography>
            )}
            {clientDetails?.clientIndustry && (
              <Typography>
                <b>Industry: </b>
                {clientDetails?.clientIndustry} Industry
              </Typography>
            )}
          </Stack>

          {/* Client Services */}
          {clientServicesData.length > 0 && (
            <Stack spacing={1} mt={[3, 3, 0]}>
              <Typography variant="h6" fontWeight="bold" mb={1}>
                Services Offering
              </Typography>
              {clientServicesData.map((service, index) => (
                <Stack
                  direction={"row"}
                  alignItems={"center"}
                  gap={1}
                  key={index}
                >
                  <CheckCircleIcon sx={{ color: "var(--color-primary)" }} />
                  <Typography variant="body1">{service}</Typography>
                </Stack>
              ))}
            </Stack>
          )}
        </Stack>
        {/* Problem Statement */}
        {clientDetails?.problemStatement?.length > 0 && (
          <Stack
            data-aos="flip-up"
            mx={[1, 1, 5, 10]}
            border={1}
            borderRadius={"var(--radius)"}
            // bgcolor={"var(--color-primary)"}
            color={"white"}
            mt={5}
            py={[5]}
            px={[2, 5]}
            sx={{
              background:
                "linear-gradient(90deg, #62b6ff,rgb(61, 163, 252), #62b6ff, #62d6ff)",
              backgroundSize: "300% 100%",
              animation: "gradientMove 3s ease-in-out infinite",
              "@keyframes gradientMove": {
                "0%": { backgroundPosition: "0% 50%" },
                "50%": { backgroundPosition: "100% 50%" },
                "100%": { backgroundPosition: "0% 50%" },
              },
            }}
          >
            <Typography
              fontSize={["24px", "var(--heading)"]}
              fontWeight="bold"
              mb={1}
            >
              Problem Statement
            </Typography>
            {clientDetails?.problemStatement?.map((problem, index) => (
              <Stack
                direction={"row"}
                alignItems={"center"}
                gap={1}
                key={index}
              >
                <CheckCircleIcon sx={{ color: "WHite" }} />
                <Typography fontSize={20}>{problem}</Typography>
              </Stack>
            ))}
          </Stack>
        )}
      </Box>
    </>
  );
};

export default ProjectIntro;
