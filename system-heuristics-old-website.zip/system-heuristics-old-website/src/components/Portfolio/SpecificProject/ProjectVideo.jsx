/*
Component: ProjectVideo (Project Demo Section)

1. Fetches the project's video data from `SpecificProject.json` using `localStorage`.
2. Displays video, title, description, and key feature points if data is available.
3. Uses an HTML `video` element with playback controls.
4. Responsive `Stack` layout (column on mobile, row on larger screens).
5. Feature points listed with `ArrowCircleRightIcon`.
6. AOS animations (`zoom-in-right`, `zoom-in-left`) for smooth transitions.
7. Styled dynamically with MUI’s `Typography` and `sx` props.
8. Ensures project-specific content for reusability.
*/

import { Box, Stack, Typography } from "@mui/material";
import React from "react";
import ArrowCircleRightIcon from "@mui/icons-material/ArrowCircleRight";
import SpecificProjectData from "./SpecificProject.json";
import { useState } from "react";
import { useEffect } from "react";

function ProjectVideo() {
  const [projectDemoData, setProjectDemoData] = useState(null);

  // on mount, read the selectedProject and pull its videoSection
  useEffect(() => {
    const selectedProject = localStorage.getItem("selectedProject")?.trim();
    if (!selectedProject) return;

    const project = SpecificProjectData.projects.find(
      (p) => p.projectName === selectedProject
    );
    setProjectDemoData(project?.videoSection ?? null);
  }, []);

  // Check if the videoSection is empty or missing
  if (!projectDemoData || Object.keys(projectDemoData).length === 0) {
    return null; // Do not render the component if videoSection is empty
  }

  return (
    <>
      <Box>
        <Stack
          mx={[1, 1, 5]}
          mb={[5, 5, 20]}
          direction={["column", "column", "row"]}
          justifyContent={"space-between"}
          alignItems={"center"}
          gap={5}
        >
          {projectDemoData?.videoUrl && (
            <Stack
              data-aos="zoom-in-right"
              alignItems={"center"}
              minWidth={"45%"}
              maxWidth={["100%", "100%", "50%"]}
              height={300}
              px={5}
            >
              <video
                src={projectDemoData?.videoUrl}
                controls
                height={"100%"}
                width={"100%"}
              />
            </Stack>
          )}
          <Stack spacing={3} p={3} data-aos="zoom-in-left">
            <Typography
              color="var(--color-primary)"
              variant="h4"
              fontWeight={"bold"}
            >
              {projectDemoData?.heading}
            </Typography>
            <Typography color="#6e777f">
              {projectDemoData?.description}
            </Typography>

            {/* Features List */}
            <Stack spacing={1}>
              {projectDemoData?.points?.map((item, idx) => (
                <Stack key={idx} direction="row" alignItems="center" gap={1}>
                  <ArrowCircleRightIcon
                    sx={{ color: "var(--color-primary)" }}
                  />
                  <Typography fontSize={18} fontWeight="bold">
                    {item}
                  </Typography>
                </Stack>
              ))}
            </Stack>
          </Stack>
        </Stack>
      </Box>
    </>
  );
}

export default ProjectVideo;
