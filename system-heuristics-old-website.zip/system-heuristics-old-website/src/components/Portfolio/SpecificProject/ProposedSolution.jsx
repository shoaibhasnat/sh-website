/*
Component: ProposedSolution (Project Solution Section)

1. Fetches project solution data from `SpecificProject.json` via `localStorage`.
2. Displays heading, description, key solution points, and tech stack used.
3. Two-column layout: image on left, text on right (image hidden on small screens).
4. Bullet-style solution points listed with `ArrowCircleRightIcon` inside a responsive `Grid`.
5. Tech stack icons displayed in a horizontal `Stack`, wrapping on smaller screens.
6. AOS animations (`fade-left` for image, `fade-right` for text) for smooth transitions.
7. Ensures modularity and responsiveness with dynamic spacing (`mx`, `gap`, `pt`, `pr`).
*/

import { Box, Grid, Stack, Typography } from "@mui/material";
import React from "react";
import ArrowCircleRightIcon from "@mui/icons-material/ArrowCircleRight";
import SpecificProjectData from "./SpecificProject.json";
import { useState } from "react";
import { useEffect } from "react";

function ProposedSolution() {
  const [solution, setSolution] = useState(null);

  // 2) On mount, read the stored project name and pull its proposedSolution
  useEffect(() => {
    const selectedProject = localStorage.getItem("selectedProject")?.trim();
    if (!selectedProject) return;

    const project = SpecificProjectData.projects.find(
      (p) => p.projectName === selectedProject
    );
    setSolution(project?.proposedSolution ?? null);
  }, []);

  const pointsData = solution?.points || [];
  const techStackData = solution?.techStackUsed || [];

  return (
    <Stack
      mx={[3, 5, 10]}
      my={[5, 5, 10]}
      direction={["column", "column", "row"]}
      justifyContent={"space-between"}
      alignItems={"center"}
      gap={5}
    >
      {solution?.leftSectionImage && (
        <Stack
          data-aos="fade-left"
          alignItems={"center"}
          minWidth={"40%"}
          maxWidth={"50%"}
          display={["none", "none", "block"]}
        >
          <img
            src={solution?.leftSectionImage}
            alt=""
            height={"100%"}
            width={"100%"}
            style={{
              borderRadius: "var(--radius)",
            }}
          />
        </Stack>
      )}
      <Stack spacing={3} data-aos="fade-right">
        <Typography fontSize={"var(--heading)"} fontWeight={"bold"}>
          {solution?.heading}
        </Typography>
        <Typography color="#6e777f">{solution?.description}</Typography>

        {/* Services Offered */}
        <Grid container spacing={2} overflow={"hidden"}>
          {pointsData?.map((service, index) => (
            <Grid item xs={12} sm={6} key={index} ml={-2}>
              {service && (
                <Stack direction={"row"} alignItems={"center"} gap={1}>
                  <ArrowCircleRightIcon
                    sx={{ color: "var(--color-primary)" }}
                  />
                  <Typography variant="h6" fontWeight={"bold"}>
                    {service}
                  </Typography>
                </Stack>
              )}
            </Grid>
          ))}
        </Grid>

        {/* Tech Stack Used */}
        <Stack
          direction={"row"}
          gap={3}
          pt={[2, 2, 5]}
          flexWrap={"wrap"}
          pr={[0, 5, 10]}
        >
          {techStackData?.map((tech, index) => (
            <>
              {tech && (
                <Box key={index} height={40}>
                  <img
                    src={tech}
                    alt="Tech Stack"
                    height={"100%"}
                    width={"100%"}
                  />
                </Box>
              )}
            </>
          ))}
        </Stack>
      </Stack>
    </Stack>
  );
}

export default ProposedSolution;
