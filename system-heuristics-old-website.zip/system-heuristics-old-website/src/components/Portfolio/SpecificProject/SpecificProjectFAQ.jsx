/*
Component: SpecificProjectFAQ (Project FAQs Section)

1. Retrieves the selected project's FAQs from `SpecificProject.json` via `localStorage`.
2. Manages FAQ expansion state using `useState`, toggling on click.
3. Displays a dynamic section title: "FAQ's" for the selected project.
4. Maps `projectFAQData` to render multiple `Accordion` components.
5. Uses `Framer Motion` for smooth item appearance with slight delays.
6. Adds `data-aos="zoom-in"` for scroll-triggered animations.
7. Ensures accessibility with `aria-controls` and `id` attributes.
8. Responsive padding/margins (`mx`, `my`) maintain a clean layout.
*/

import React, { useState } from "react";
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  Box,
} from "@mui/material";
import { motion } from "framer-motion";
import ArrowDownwardIcon from "@mui/icons-material/ArrowDownward";
import SpecificProjecteData from "./SpecificProject.json";
import { useEffect } from "react";

const SpecificProjectFAQ = () => {
  const [projectFAQData, setProjectFAQData] = useState([]);

  const [selectedProject, setSelectedProject] = useState("");
  // on mount, load FAQs for the selected project
  useEffect(() => {
    const selectedProject = localStorage.getItem("selectedProject")?.trim();
    if (!selectedProject) return;

    setSelectedProject(selectedProject);

    const project = SpecificProjecteData.projects.find(
      (p) => p.projectName === selectedProject
    );
    setProjectFAQData(project?.faqs || []);
  }, []);

  const [expandedIndex, setExpandedIndex] = useState(null);

  const handleAccordionChange = (index) => {
    setExpandedIndex(expandedIndex === index ? null : index);
  };

  return (
    <>
      {projectFAQData.length > 0 ? (
        <>
          {/* Main FAQ's Section  */}
          <Box my={10} mx={[3, 5, 10, 20]} data-aos="zoom-in">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl mx-auto p-6"
            >
              <Typography
                fontSize={"var(--heading)"}
                align="center"
                gutterBottom
              >
                {selectedProject} FAQ's
              </Typography>
              {projectFAQData?.map((faq, index) => (
                // framer motion for animation
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  {/* Accordion */}
                  <Accordion
                    expanded={expandedIndex === index}
                    onChange={() => handleAccordionChange(index)}
                    sx={{
                      my: 2,
                      marginTop: expandedIndex === index ? "20px" : "20px",
                      transition: "margin-top 0.3s ease-in-out",
                    }}
                  >
                    <AccordionSummary
                      expandIcon={<ArrowDownwardIcon />}
                      aria-controls="panel1-content"
                      id={`panel1-header-${index}`}
                    >
                      <Typography component="span">{faq.question}</Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                      <Typography>{faq.answer}</Typography>
                    </AccordionDetails>
                  </Accordion>
                </motion.div>
              ))}
            </motion.div>
          </Box>
        </>
      ) : (
        ""
      )}
    </>
  );
};

export default SpecificProjectFAQ;
