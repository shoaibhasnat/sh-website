/*
Component: TeamSection (Project Team Display)

1. Fetches `teamInvolved` data from `SpecificProject.json` using the selected project from `localStorage`.
2. Manages `selectedTeam` state to track the active team member/department.
3. Lists team roles on the left as clickable `Paper` cards, highlighting the selected one.
4. Clicking a team card updates `selectedTeam`, displaying its details on the right.
5. Uses `Stack` and `Box` for a responsive layout that switches between row and column.
6. Adds hover effects and smooth transitions for better interactivity.
7. Conditionally renders the section only if team data is available.
*/

import React, { useState } from "react";
import { Box, Typography, Stack, Paper, useTheme } from "@mui/material";
import SpecificProjectData from "./SpecificProject.json";
import { useEffect } from "react";

const TeamSection = () => {
  const theme = useTheme();
  const [teamData, setTeamData] = useState([]);
  const [selectedTeam, setSelectedTeam] = useState(null);

  // Load team data on mount
  useEffect(() => {
    const selectedProject = localStorage.getItem("selectedProject")?.trim();
    if (!selectedProject) return;

    const project = SpecificProjectData.projects.find(
      (p) => p.projectName === selectedProject
    );
    const list = project?.teamInvolved || [];
    setTeamData(list);
    setSelectedTeam(list[0] || null);
  }, []);

  return (
    <>
      {teamData.length > 0 && (
        <>
          <Box
            px={1}
            py={5}
            bgcolor={theme.palette.mode === "dark" ? "transparent" : "#f4f4f5"}
          >
            <Typography fontSize={"var(--heading)"} textAlign={"center"}>
              Development Team
            </Typography>
            <Stack
              direction={["column-reverse", "column-reverse", "row"]}
              justifyContent="center"
              alignItems="center"
              py={5}
            >
              {/* Left Side - Team List */}
              {teamData?.length > 0 && (
                <Stack
                  spacing={2}
                  width={["100%", "100%", "40%"]}
                  px={[1, 5]}
                  // data-aos="zoom-in"
                >
                  {teamData?.map((team, index) => (
                    <>
                      <Paper
                        key={index}
                        onClick={() => setSelectedTeam(team)}
                        sx={{
                          display: "flex",
                          color: "black",
                          alignItems: "center",
                          gap: 2,
                          p: 2,
                          borderRadius: "var(--radius)",
                          cursor: "pointer",
                          transition: "0.3s",
                          bgcolor:
                            selectedTeam?.title === team.title
                              ? "#f4f4f5"
                              : "white",
                          border:
                            selectedTeam?.title === team.title
                              ? "2px solid #007bff"
                              : "1px solid #ddd",
                          "&:hover": {
                            bgcolor: "#f0f0f0",
                            borderRadius: "var(--radius)",
                          },
                        }}
                      >
                        {team?.iconImage && (
                          <img
                            src={team?.iconImage}
                            alt={team?.title}
                            width={50}
                            height={50}
                          />
                        )}
                        <Typography variant="h6" fontWeight="bold">
                          {team?.title}
                        </Typography>
                      </Paper>
                    </>
                  ))}
                </Stack>
              )}

              {/* Right Side - Selected Team Details */}
              <Box
                data-aos="zoom-in"
                width={["100%", "100%", "50%"]}
                pl={[3, 3, 5]}
                textAlign={["center", "center", "left"]}
                pr={[3, 3, 20]}
                my={[3, 3, 0]}
              >
                {selectedTeam?.iconImage && (
                  <img
                    src={selectedTeam?.iconImage}
                    alt={selectedTeam?.title}
                    width={100}
                  />
                )}
                <Typography variant="h5" fontWeight="bold" mt={2}>
                  {selectedTeam?.title}
                </Typography>
                <Typography variant="body1" color="textSecondary" mt={1}>
                  {selectedTeam?.description}
                </Typography>
              </Box>
            </Stack>
          </Box>
        </>
      )}
    </>
  );
};

export default TeamSection;
