/*
Component: Main (Services Page Container)

1. Renders the complete Services page layout sequentially.
2. Displays `Banner` as the hero section with animation and heading.
3. Shows `ServicesOverview` for an introduction to offered services.
4. Lists service categories via `ServicesSection`.
5. Explains the process interactively in `ServicesProcess`.
6. Showcases technologies used in `TechStack`.
7. Uses a clean JSX structure with semantic ordering.
8. Each section independently handles its data and rendering.
9. Wraps components in a fragment (`<> </>`) to avoid extra DOM nodes.
10. Encapsulates the full layout for scalability and reusability.
*/

import React from "react";
import TechStack from "./TechStack";
import Banner from "./Banner";
import ServicesOverview from "./ServicesOverview";
import ServicesSection from "./ServicesSection/ServicesSection";
import ServicesProcess from "./ServicesProcess";

function Main() {
  return (
    <>
      <Banner />
      <ServicesOverview />
      <ServicesSection />
      <ServicesProcess />
      <TechStack />
    </>
  );
}

export default Main;
