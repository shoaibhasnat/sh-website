/*
Component: ServicesOverview (Intro Section for Services Page)

1. Fetches `introSection` data from `Services.json` (title, highlight, description).
2. Uses `framer-motion` for fade-in and upward slide animation.
3. Adapts text color via MUI’s `useTheme` for light/dark mode.
4. Displays a bold title (`introData.title`) and a blue-highlighted sub-title (`introData.highlight`).
5. Renders a concise, readable description with muted text styling.
6. Maintains responsive spacing for a consistent layout on all devices.
7. Adds AOS animation (`data-aos="fade-up"`) for smooth scroll effects.
8. Uses centered text alignment for a clean, modern design.
9. Ensures animations trigger only once per viewport entry (`viewport: { once: true }`).
10. Provides a structured and visually appealing introduction to services.
*/

import React from "react";
import { Typography, Box, useTheme } from "@mui/material";
import { motion } from "framer-motion";
import ServicesData from "./Services.json";

const ServicesOverview = () => {
  const theme = useTheme();
  const introData = ServicesData?.introSection; //Getting data from Services.json file

  return (
    // Parent Box
    <Box
      data-aos="fade-up"
      mt={[10]}
      component={motion.div}
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      viewport={{ once: true }}
      sx={{
        textAlign: "center",
        px: 2,
      }}
    >
      {/* Title  */}
      <Typography
        fontSize={"var(--heading)"}
        component="h2"
        fontWeight="bold"
        color={theme.palette.mode === "dark" ? "white" : "#000"}
      >
        {introData?.title}
      </Typography>

      {/* Highlighted Text  */}
      <Typography fontSize={"var(--heading)"} sx={{ color: "#007bff" }}>
        {" "}
        {introData?.highlight}
      </Typography>

      {/* Services Description  */}
      <Typography
        fontSize={"var(--description)"}
        sx={{ color: "text.secondary", mt: 2, maxWidth: "600px", mx: "auto" }}
      >
        {introData?.description}
      </Typography>
    </Box>
  );
};

export default ServicesOverview;
