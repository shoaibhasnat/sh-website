/*
Component: ServicesProcess (Interactive Steps for Service Flow)

1. Fetches `processSection` data from `Services.json` (step titles & descriptions).
2. Initializes `activeStep` state with "Planning" as the default highlighted step.
3. Displays section heading and a brief introduction to the service process.
4. Renders step titles in a vertical clickable list using `Stack`.
5. Highlights the active step with a bold primary-colored icon and text.
6. Updates `activeStep` state on click to show the corresponding step details.
7. Shows the selected step’s title, icon, and description dynamically.
8. Adapts layout (column on small screens, row on larger screens) for responsiveness.
9. Adjusts text color based on light/dark mode using MUI’s `useTheme`.
10. Adds AOS animations (`data-aos`) for smooth appearance on scroll.
*/

import React, { useState } from "react";
import { Stack, Typography, Box, useTheme } from "@mui/material";
import CheckCircleRoundedIcon from "@mui/icons-material/CheckCircleRounded";
import ServicesData from "./Services.json";

const ServicesProcess = () => {
  const theme = useTheme(); // Use theme for dark mode adustment
  const processData = ServicesData?.processSection; //Getting processSection data from Services.json file
  const steps = processData?.stepTitles;
  const descriptions = processData?.descriptions;
  const [activeStep, setActiveStep] = useState("Planning"); //Set the active step of the process section

  return (
    //Parent Box
    <Box sx={{ textAlign: "center", p: 4 }} my={10}>
      {/* Heading Section  */}
      <Box mx={[1, 2, 20, 30]} data-aos="fade-down">
        {/* Process Title  */}
        <Typography fontSize={"var(--heading)"} fontWeight="bold">
          Discover Our Fine-Tuned
          <Typography
            component="span"
            fontSize={"var(--heading)"}
            color="var(--color-primary-hover)"
            fontWeight="bold"
          >
            {" "}
            Services
          </Typography>{" "}
          Process
        </Typography>

        {/* Process Description */}
        <Typography
          fontSize={"var(--description)"}
          color="text.secondary"
          mt={1}
        >
          Journey with us into the universal service process to paint the canvas
          of your next big project.
        </Typography>
      </Box>

      {/* Main Stack  */}
      <Stack
        direction={["column-reverse", "column-reverse", "row"]}
        spacing={2}
        alignItems="center"
        justifyContent="center"
        mt={5}
        gap={[5, 5, 10]}
      >
        {/* Left side steps section  */}
        <Stack spacing={3} data-aos="flip-right">
          {steps.map((step, index) => (
            <Stack
              key={step}
              direction={["row", "row", "row-reverse"]}
              alignItems="center"
              spacing={2}
              sx={{ cursor: "pointer" }}
              onClick={() => setActiveStep(step)}
              gap={2}
            >
              <CheckCircleRoundedIcon
                sx={{
                  color:
                    activeStep === step ? "var(--color-primary-hover)" : "#ccc",
                }}
              />

              <Typography
                textAlign={"left"}
                sx={{
                  color:
                    activeStep === step
                      ? "var(--color-primary-hover)"
                      : theme.palette.mode === "dark"
                      ? "white"
                      : "black",
                  fontWeight: activeStep === step ? "bold" : "bold",
                  fontSize: 20,
                }}
              >
                {step}
              </Typography>
            </Stack>
          ))}
        </Stack>

        {/* Right Side step detail section  */}
        <Stack
          data-aos="flip-left"
          justifyContent={"flex-start"}
          textAlign={"left"}
          sx={{
            p: 5,
            borderRadius: "var(--radius)",
            boxShadow: 3,
          }}
          minWidth={[200, 250, 500]}
          maxWidth={[500, 500, 500]}
        >
          <img
            src="https://invozone.com/static/56a364853799f2fd238d2997d7dfb5b1/Frame_9_eddb25dcdb.svg"
            alt={activeStep}
            style={{
              borderRadius: "var(--radius)",
              marginBottom: "15px",
            }}
            height={50}
            width={50}
          />
          <Typography variant="h5" fontWeight={"bold"} mb={1}>
            {activeStep}
          </Typography>
          <Typography>{descriptions[activeStep]}</Typography>
        </Stack>
      </Stack>
    </Box>
  );
};

export default ServicesProcess;
