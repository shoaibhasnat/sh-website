/*
Component: ServicesSection (All Services Cards)

1. Fetches service data from `Services.json` (`allServices.serviceCards`).
2. Displays a responsive grid using MUI `Stack`, adapting to different screen sizes.
3. Each card includes:
   - Floating circular icon (`Box` with `position: absolute`)
   - Service title and description
   - Hover animation with gradient effect and white text.
4. Adds AOS animation (`data-aos="fade-down"`) for smooth entry.
5. On click:
   - Navigates to the selected service page (`navigate(service?.path)`)
   - Saves `selectedService` in `localStorage`
   - Scrolls to the top.
6. Adjusts layout dynamically via MUI props (`mx`, `gap`, `flexWrap`).
7. Handles dark mode styling using `theme.palette.mode`.
8. Uses `@keyframes gradientMove` for hover animation.
9. Fully modular, fits seamlessly into the Services landing page.
*/

import React from "react";
import { Box, Typography, Stack, useTheme } from "@mui/material";
import { useNavigate } from "react-router-dom";
import ServicesData from "../ServicesSection/SpecificService/SpecificService.json";

const ServicesSection = () => {
  const navigate = useNavigate(); // Use navigate for route navigation
  const allServicesData = ServicesData?.services; //Get All Services Data from Services.json file
  const theme = useTheme(); // Use theme for darkmode adjustments

  return (
    <>
      {allServicesData.length > 0 && (
        //  Parent Box
        <Box
          textAlign="center"
          py={5}
          pt={[10]}
          mx={[3, 3, 3, 0]}
          id="servicesSection"
        >
          {/* Heading  */}
          <Typography
            fontSize={"var(--heading)"}
            fontWeight="bold"
            fontFamily={"var(--font-family-primary)"}
          >
            {/* {allServicesData?.heading} */}
            Services We Offer
          </Typography>

          {/* Description  */}
          <Typography
            fontSize={"var(--description)"}
            color="text.secondary"
            mt={1}
            mx={[0, 0, 0, 50]}
          >
            Unlock the power of Artificial Intelligence with our cutting-edge
            solutions designed to revolutionize industries and drive innovation.
            {/* {allServicesData?.description} */}
          </Typography>

          {/* Cards Section  */}
          <Stack
            alignItems="center"
            mt={10}
            direction={"row"}
            justifyContent={"space-evenly"}
            mx={[0, 0, 0, 10]}
            flexWrap={"wrap"}
            flex={"1 1 calc(33.33% -16px)"}
            gap={[8, 8, 10]}
          >
            {allServicesData?.map((service, index) => (
              // Single Card
              <Stack
                data-aos="fade-down"
                key={index}
                borderRadius={"var(--radius)"}
                boxShadow={5}
                p={3}
                justifyContent={"center"}
                alignItems={"center"}
                gap={1}
                bgcolor={"white"}
                maxWidth={[400, 400, 300]}
                minHeight={[250, 250, 200]}
                textAlign={"center"}
                position={"relative"}
                sx={{
                  "&:hover": {
                    transition: " -0.3s", // Fixed transition syntax
                    cursor: "pointer",
                    mt: -3,
                    // bgcolor: "var(--color-primary)",
                    background:
                      "linear-gradient(90deg, #62b6ff, #2769d9, #62b6ff, #62d6ff)",
                    backgroundSize: "300% 100%",
                    animation: "gradientMove 5s ease-in-out infinite",
                    "@keyframes gradientMove": {
                      "0%": { backgroundPosition: "0% 50%" },
                      "50%": { backgroundPosition: "100% 50%" },
                      "100%": { backgroundPosition: "0% 50%" },
                    },
                    color: "white",
                  },
                  "&:hover .cardSummary": {
                    color: "white",
                  },
                }}
                onClick={() => {
                  navigate(service?.path);
                  localStorage.setItem("selectedService", service?.title);
                  window.scrollTo(0, 0);
                }}
              >
                <Box
                  height={80}
                  width={80}
                  position={"absolute"}
                  top={-40}
                  borderRadius={100}
                  bgcolor={"white"}
                  p={1}
                >
                  <img
                    src={service?.icon}
                    alt={service?.title}
                    height={"100%"}
                    width={"100%"}
                    loading="lazy"
                  />
                </Box>

                {/* Service Tittile  */}
                <Typography
                  className="cardSummary"
                  variant="h6"
                  fontWeight="bold"
                  mt={1}
                  color="black"
                >
                  {service?.title}
                </Typography>

                {/* Service Description  */}
                <Typography
                  variant="body2"
                  className="cardSummary"
                  mt={1}
                  color={
                    theme.palette.mode === "dark" ? "black" : "text.secondary"
                  }
                >
                  {service?.description}
                </Typography>
              </Stack>
            ))}
          </Stack>
        </Box>
      )}
    </>
  );
};

export default ServicesSection;
