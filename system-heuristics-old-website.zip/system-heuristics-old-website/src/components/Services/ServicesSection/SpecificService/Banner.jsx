/*
Component: Banner (Specific Service Page Hero Section)

1. Retrieves `selectedService` from `localStorage` to load relevant banner data.
2. Dynamically fetches Lottie animation from `SpecificService.json`.
3. Displays a full-screen hero section with theme-adaptive background.
4. Uses `MUI Stack` for a responsive layout (text left, animation right).
5. Features an animated CTA button with SVG arrows and hover effects.
6. Smoothly scrolls to `#serviceIntro` via anchor `<Link>`.
7. Ensures responsiveness using MUI props (`mx`, `gap`, `pt`) and breakpoints.
8. Supports dark/light mode via `useTheme()`.
9. Safely handles missing data with optional chaining.
10. `StyledWrapper` manages custom hover animations and pulse effects.
*/

import { Box, Link, Stack, Typography, useTheme } from "@mui/material";
import React from "react";
import styled from "styled-components";
import Lottie from "react-lottie-player";
import SpecificServiceData from "./SpecificService.json";
import { useEffect } from "react";
import { useState } from "react";

function Banner() {
  const [animationData, setAnimationData] = useState(null);
  const selectedService = localStorage.getItem("selectedService")?.trim(); // Fetch the selected service from local storage

  const bannerData =
    SpecificServiceData?.services?.find(
      (service) => service.title === selectedService
    )?.banner || null; // Storing specific service banner data

  useEffect(() => {
    if (bannerData?.bannerAnimation) {
      // Fetch JSON file from the public folder
      fetch(bannerData?.bannerAnimation)
        .then((response) => response.json()) // Parse JSON
        .then((data) => setAnimationData(data)) // Store data in state
        .catch((error) =>
          console.error("Error loading Lottie animation:", error)
        );
    }
  }, [bannerData?.bannerAnimation]);

  const theme = useTheme(); // Access the theme to detect mode

  if (!bannerData || Object.keys(bannerData).length === 0) {
    return null; // Do not render the component if videoSection is empty
  }

  return (
    <>
      {/* Main Box  */}
      <Box
        pt={[7, 7, 0]}
        height={"100vh"}
        position={"relative"}
        overflow={"hidden"}
        mb={10}
        bgcolor={theme.palette.mode === "dark" ? "black" : "#F0F8FF"}
      >
        <Stack
          mx={[2, 5, 2, 10]}
          mt={[5, 5, 0]}
          color={theme.palette.mode === "dark" ? "white" : "black"}
          direction={["column", "column", "row"]}
          justifyContent={"center"}
          alignItems={"center"}
          height={"100%"}
          zIndex={1}
          position={"absolute"}
          gap={1}
        >
          <Stack px={2} maxWidth={["100%", "100%", "50%"]}>
            {/* Banner Heading  */}
            <Typography
              fontSize={[
                "var(--font-standard)",
                "var(--font-lg)",
                "var(--font-xl)",
                "var(--font-xl)",
              ]}
              fontWeight={[
                "var(--font-medium)",
                "var(--font-medium)",
                "var(--font-regular)",
              ]}
            >
              {bannerData?.heading}
            </Typography>

            {/* Banner Description  */}
            <Typography mt={1} lineHeight={[1.5, 1.5, 2]} textAlign={"justify"}>
              {bannerData?.description}
            </Typography>

            {/* Animated Button  */}
            <StyledWrapper style={{ marginTop: 30 }}>
              <Link
                href="#serviceIntro"
                sx={{
                  scrollBehavior: "smooth",
                  textDecoration: "none",
                }}
              >
                <button className="animated-button">
                  <svg
                    viewBox="0 0 24 24"
                    className="arr-2"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z" />
                  </svg>

                  <span className="text">Explore </span>
                  <span className="circle" />
                  <svg
                    viewBox="0 0 24 24"
                    className="arr-1"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path d="M16.1716 10.9999L10.8076 5.63589L12.2218 4.22168L20 11.9999L12.2218 19.778L10.8076 18.3638L16.1716 12.9999H4V10.9999H16.1716Z" />
                  </svg>
                </button>
              </Link>
            </StyledWrapper>
          </Stack>

          {/* Banner Animation  */}
          {animationData && (
            <Box
              mt={[-5, -5, 0]}
              height={["100%", "80%", "80%", "70%"]}
              width={["100%", "80%", "80%", "70%"]}
            >
              <Lottie
                loop
                animationData={animationData}
                play
                style={{ height: "100%", width: "100%" }}
              />
            </Box>
          )}
        </Stack>
      </Box>
    </>
  );
}

// Wrapper for animated button
const StyledWrapper = styled.div`
  .animated-button {
    position: relative;
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 12px 36px;
    border: 4px solid;
    border-color: var(--color-primary-hover);
    font-size: 16px;
    background-color: inherit;
    border-radius: 100px;
    font-weight: 600;
    color: var(--color-primary-hover);
    cursor: pointer;
    overflow: hidden;
    transition: all 0.6s cubic-bezier(0.23, 1, 0.32, 1);
  }

  .animated-button svg {
    position: absolute;
    width: 24px;
    fill: var(--color-primary-hover);
    z-index: 9;
    transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
  }

  @media (max-width: 500px) {
    .animated-button {
      padding: 10px 26px;
      border: 3px solid;
      font-size: 14px;
    }
    .animated-button svg {
      width: 20px;
    }
  }

  .animated-button .arr-1 {
    right: 16px;
  }

  .animated-button .arr-2 {
    left: -25%;
  }

  .animated-button .circle {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 20px;
    height: 20px;
    background-color: var(--color-primary);
    border-radius: 50%;
    opacity: 0;
    transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
  }

  .animated-button .text {
    position: relative;
    z-index: 1;
    transform: translateX(-12px);
    transition: all 0.8s cubic-bezier(0.23, 1, 0.32, 1);
  }

  @media (min-width: 900px) {
    .animated-button:hover {
      box-shadow: 0 0 0 12px transparent;
      color: white;
      border-radius: 12px;
    }

    .animated-button:hover .arr-1 {
      right: -25%;
    }

    .animated-button:hover .arr-2 {
      left: 16px;
    }

    .animated-button:hover .text {
      transform: translateX(12px);
    }

    .animated-button:hover svg {
      fill: white;
    }

    .animated-button:active {
      scale: 0.95;
      box-shadow: 0 0 0 4px var(--color-primary);
    }

    .animated-button:hover .circle {
      width: 220px;
      height: 220px;
      opacity: 1;
    }
  }
`;

export default Banner;
