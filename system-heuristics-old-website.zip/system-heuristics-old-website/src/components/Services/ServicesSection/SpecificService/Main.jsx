/*
Component: Main (Service Page Layout)

1. Renders all sections for the specific service page, starting with `Banner` (Lottie animation and hero content).
2. Displays `ServiceIntro` with title, description, and visuals.
3. Shows `SpecificServiceSlider` for a carousel of service features.
4. Includes `ServicePortfolio` to highlight case studies or previous work.
5. Adds `SpecificServiceFAQ` to address FAQs related to the service.
6. Fetches data using `selectedService` from `localStorage`.
7. Utilizes React fragment (`<>`) for clean layout.
8. Promotes modularity with reusable components and dynamic theming.
*/

import React from "react";
import Banner from "./Banner";
import ServiceIntro from "./ServiceIntro";
import SpecificServiceFAQ from "./SpecificServiceFAQ";
import SpecificServiceSlider from "./SpecificServiceSlider";
// import ServicePortfolio from "./ServicePortfolio";

function Main() {
  return (
    <>
      <Banner />
      <ServiceIntro />
      <SpecificServiceSlider />
      {/* updated by nadeem */}
      {/* <ServicePortfolio /> */}
      <SpecificServiceFAQ />
    </>
  );
}

export default Main;
