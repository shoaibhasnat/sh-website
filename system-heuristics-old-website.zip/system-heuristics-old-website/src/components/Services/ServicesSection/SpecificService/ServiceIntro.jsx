/*
Component: ServiceIntro

1. Fetches the selected service name from localStorage and trims whitespace.
2. Uses the service key to access `introSection` data from `SpecificService.json`.
3. Renders a centered intro section with title, highlighted subtitle, and description.
4. Applies dynamic text color based on theme (dark/light mode) using `useTheme`.
5. Adds `data-aos="fade-up"` for scroll animation with AOS.
6. Limits description width for readability with margin and padding for spacing.
7. Supports responsive styling with array-based `sx` props across breakpoints.
8. Identified with `serviceIntro` ID for smooth internal navigation.
9. Handles null `introData` with conditional rendering.
*/

import React from "react";
import { Typography, Box, useTheme } from "@mui/material";
import SpecificServiceData from "./SpecificService.json";

const ServiceIntro = () => {
  const theme = useTheme();

  const selectedService = localStorage.getItem("selectedService")?.trim(); // Fetch the selected industru from local storage

  const introData =
    SpecificServiceData?.services?.find(
      (service) => service.title === selectedService
    )?.introSection || null; // Storing specific service intro data

  if (!introData || Object.keys(introData).length === 0) {
    return null;
  }

  return (
    <>
      <Box
        id="serviceIntro"
        my={[5]}
        py={10}
        sx={{
          textAlign: "center",
          mt: 10,
          px: 2,
        }}
      >
        <Box data-aos="fade-up">
          {/* Titile  */}
          <Typography
            fontSize={"var(--heading)"}
            component="h2"
            fontWeight="bold"
            color={theme.palette.mode === "dark" ? "white" : "black"}
          >
            {introData?.title}
          </Typography>

          {/* Highlighted Text  */}
          <Typography fontSize={"var(--heading)"} sx={{ color: "#007bff" }}>
            {" "}
            {introData?.highlight}
          </Typography>

          {/* Description  */}
          <Typography
            fontSize={"var(--description)"}
            sx={{ color: "#6c757d", mt: 2, maxWidth: "600px", mx: "auto" }}
          >
            {introData?.description}
          </Typography>
        </Box>
      </Box>
    </>
  );
};

export default ServiceIntro;
