/*
Component: ServicePortfolio

1. Fetches selected service from localStorage to filter related projects from `Portfolio.json`.
2. Filters and displays portfolio items matching the selected service category.
3. Implements a responsive horizontal slider using `react-slick` for dynamic project cards.
4. Disables autoplay and infinite scroll if only one project exists for a clean UX.
5. Custom previous/next navigation buttons styled with `MUI`'s `IconButton`, placed below the slider.
6. Each portfolio card displays title overlay, project description, and "View Project" button.
7. On "View Project" click, navigates to project route and sets it in localStorage.
8. Card background set dynamically using `styled-components` `background` prop.
9. Title fades out, description slides up smoothly on hover with CSS transitions.
10. Layout adapts across screen sizes using responsive breakpoints and `Slick Slider` settings.
*/

import React from "react";
import { Box, Button, IconButton, Stack, Typography } from "@mui/material";
import styled from "styled-components";
import PortfolioData from "../../../Portfolio/SpecificProject/SpecificProject.json";
import { useNavigate } from "react-router-dom";
import ArrowBack from "@mui/icons-material/ArrowBack";
import ArrowForward from "@mui/icons-material/ArrowForward";
import Slider from "react-slick";

const ServicePortfolio = () => {
  const sliderRef = React.useRef(null); // Use reference for the slider

  const navigate = useNavigate();

  const selectedService = localStorage.getItem("selectedService"); //getting active industry from localStorage

  // Filtering projects based on the selected Service
  const sliderData =
    PortfolioData?.projects?.filter((project) =>
      project?.category?.includes(selectedService)
    ) || [];

  // React Slick Slider Settings
  const settings = {
    dots: false,
    arrows: false, // Disable left and right navigation arrows
    infinite: sliderData.length > 1, // Disable infinite scrolling if only one item
    speed: 800,
    autoplay: sliderData.length > 1, // Disable autoplay if only one item
    autoplaySpeed: 3000,
    slidesToShow: sliderData.length > 1 ? 3 : 1, // Show only one slide if length is 1
    slidesToScroll: 1,
    pauseOnHover: true,
    responsive: [
      {
        breakpoint: 1340,
        settings: {
          slidesToShow: sliderData.length > 1 ? 2 : 1,
          slidesToScroll: 1,
        },
      },
      { breakpoint: 900, settings: { slidesToShow: 1, slidesToScroll: 1 } },
    ],
  };

  return (
    <>
      {sliderData.length > 0 && (
        // Parent Box
        <Box
          sx={{
            textAlign: "center",
            mt: 4,
            backgroundImage: `url("/images/Portfolio-Slider-Bg.jpg")`,
            backgroundSize: "cover", // Ensures the image covers the entire box
            backgroundPosition: "center", // Centers the image
            backgroundRepeat: "no-repeat", // Prevents repeating
          }}
          bgcolor={"var(--color-primary)"}
          py={5}
        >
          {/* Heading  */}
          <Typography
            fontSize={"var(--heading)"}
            fontWeight="bold"
            color="white"
          >
            Our {selectedService} Portfolio
          </Typography>

          {/* Slider Box  */}
          <Box
            mx={[1, 1, 10, 10]}
            sx={{
              mt: 6,
              position: "relative",
              "&:hover": {
                cursor: "grabbing",
              },
            }}
          >
            <Slider ref={sliderRef} {...settings}>
              {sliderData?.map((cardItem, index) => (
                // Single Sliding Card
                <Card
                  key={index}
                  background={cardItem?.banner?.bannerImage}
                  data-aos="zoom-in-up"
                >
                  <Stack
                    justifyContent={"center"}
                    alignItems={"center"}
                    height={"100%"}
                    width={"100%"}
                    className="cardHeader"
                  >
                    {/* Project title  */}
                    <Typography
                      bgcolor={"rgba(255, 255, 255, 0.54)"}
                      color="black"
                      variant="h4"
                      borderRadius={"var(--rounded)"}
                      px={3}
                      py={1}
                    >
                      {cardItem?.projectName}
                    </Typography>
                  </Stack>
                  <Stack className="content" mx={2}>
                    {/* Project Description  */}
                    <Typography
                      className="title"
                      maxHeight={150}
                      sx={{
                        overflowY: "auto",
                        scrollbarWidth: "thin", // for Firefox
                        scrollbarColor: "#888 #f1f1f1", // for Firefox
                        "&::-webkit-scrollbar": {
                          width: "6px",
                        },
                        "&::-webkit-scrollbar-track": {
                          background: "#f1f1f1",
                        },
                        "&::-webkit-scrollbar-thumb": {
                          backgroundColor: "#888",
                          borderRadius: "10px",
                          border: "2px solid transparent",
                          backgroundClip: "content-box",
                        },
                        "&::-webkit-scrollbar-thumb:hover": {
                          background: "#555",
                        },
                      }}
                    >
                      {cardItem?.banner?.description}
                    </Typography>

                    <Button
                      variant="outlined"
                      size="small"
                      sx={{
                        color: "white",
                        bgcolor: "var(--color-primary)",
                        mt: 2,
                      }}
                      onClick={() => {
                        navigate(`/project/${cardItem?.id}`);

                        localStorage.setItem(
                          "selectedProject",
                          cardItem?.projectName
                        );
                        window.scrollTo(0, 0);
                      }}
                    >
                      View Project
                    </Button>
                  </Stack>
                </Card>
              ))}
            </Slider>
          </Box>

          {/* Navigation Buttons */}
          <Stack
            mt={2}
            direction={"row"}
            alignItems={"center"}
            justifyContent={"center"}
            gap={1}
          >
            {/* Previous Button  */}
            <IconButton
              sx={{
                bgcolor: "var(--color-primary-hover)",
                color: "white",
                "&:hover": {
                  bgcolor: "var(--color-primary)",
                  color: "white",
                },
              }}
              onClick={() => sliderRef.current.slickPrev()}
            >
              <ArrowBack />
            </IconButton>

            {/* Next Button  */}
            <IconButton
              sx={{
                bgcolor: "var(--color-primary-hover)",
                color: "white",
                "&:hover": {
                  bgcolor: "var(--color-primary)",
                  color: "white",
                },
              }}
              onClick={() => sliderRef.current.slickNext()}
            >
              <ArrowForward />
            </IconButton>
          </Stack>
        </Box>
      )}
    </>
  );
};

// Pass background dynamically as props
// Animation for card
const Card = styled.div`
  position: relative;
  width: 400px;
  max-width: 400px;
  height: 254px;
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 0 10px;
  border-top-right-radius: 50px;
  border-bottom-left-radius: 50px;
  border-bottom-right-radius: 5px;
  border-top-left-radius: 5px;
  background: url(${(props) => props.background}) center/cover no-repeat;
  flex-shrink: 0; /* Prevent cards from shrinking */

  /* Hover effect */
  &:hover .cardHeader {
    scale: 0.5;
    opacity: 0;
    transform: translateY(-70px);
  }

  &::after {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border-top-right-radius: 50px;
    border-bottom-left-radius: 50px;
    border-bottom-right-radius: 5px;
    border-top-left-radius: 5px;
    background: rgba(0, 0, 0, 0);
    transition: background 0.3s ease-in-out;
  }

  &:hover::after {
    background: rgba(0, 0, 0, 0.5);
  }

  .cardHeader {
    position: absolute;
    z-index: 3;
    scale: 0.8;
    transition: 0.5s;
  }

  .content {
    position: absolute;
    z-index: 3;
    bottom: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    transform: scale(0);
    transition: 0.5s;
  }

  &:hover .content {
    transform: scale(1);
    justify-content: center;
    align-items: center;
    margin-bottom: 25px;
  }

  .content .title {
    color: white;
    font-weight: 500;
    font-size: 1em;
    letter-spacing: 0.1em;
    text-align: center;
  }

  @media (max-width: 450px) {
    max-width: 320px;
  }
`;

export default ServicePortfolio;
