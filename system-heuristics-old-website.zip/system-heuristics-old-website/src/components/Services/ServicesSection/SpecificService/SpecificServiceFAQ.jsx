/*
Component: SpecificServiceFAQ

1. Retrieves selected service from `localStorage` to filter relevant FAQs from `SpecificService.json`.
2. Filters FAQ data based on selected service name.
3. Uses `useState` to control the expanded accordion item by index.
4. Renders the section only if FAQs exist for the selected service.
5. Wraps content in a `motion.div` for entrance animation with `framer-motion`.
6. Maps through FAQ array to generate animated accordion items.
7. Expands or collapses accordion items based on selected index.
8. Uses MUI’s `Accordion`, `AccordionSummary`, and `AccordionDetails` for layout.
9. Adds smooth margin-top transition for accordion expansion.
10. Combines `AOS` and `framer-motion` for enhanced scroll and entry animations.
*/

import React, { useState } from "react";
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  Box,
} from "@mui/material";
import { motion } from "framer-motion";
import ArrowDownwardIcon from "@mui/icons-material/ArrowDownward";
import SpecificServiceData from "./SpecificService.json";

const SpecificServiceFAQ = () => {
  const selectedService = localStorage.getItem("selectedService"); // Getting selected service from local storage

  const serviceFAQData =
    SpecificServiceData?.services?.find(
      (service) => service.title === selectedService
    )?.faqs || null;

  const [expandedIndex, setExpandedIndex] = useState(null);

  const handleAccordionChange = (index) => {
    setExpandedIndex(expandedIndex === index ? null : index);
  };

  return (
    <>
      {serviceFAQData?.length > 0 ? (
        <>
          {/* Main FAQ's Section  */}
          <Box my={10} mx={[3, 5, 10, 20]} data-aos="zoom-in">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-3xl mx-auto p-6"
            >
              <Typography
                fontSize={"var(--heading)"}
                align="center"
                gutterBottom
              >
                {selectedService} FAQ's
              </Typography>
              {serviceFAQData?.map((faq, index) => (
                // framer motion for animation
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  {/* Accordion */}
                  <Accordion
                    expanded={expandedIndex === index}
                    onChange={() => handleAccordionChange(index)}
                    sx={{
                      my: 2,
                      marginTop: expandedIndex === index ? "20px" : "20px",
                      transition: "margin-top 0.3s ease-in-out",
                    }}
                  >
                    {/* Question  */}
                    <AccordionSummary
                      expandIcon={<ArrowDownwardIcon />}
                      aria-controls="panel1-content"
                      id={`panel1-header-${index}`}
                    >
                      <Typography component="span">{faq.question}</Typography>
                    </AccordionSummary>

                    {/* Answer  */}
                    <AccordionDetails>
                      <Typography>{faq.answer}</Typography>
                    </AccordionDetails>
                  </Accordion>
                </motion.div>
              ))}
            </motion.div>
          </Box>
        </>
      ) : (
        ""
      )}
    </>
  );
};

export default SpecificServiceFAQ;
