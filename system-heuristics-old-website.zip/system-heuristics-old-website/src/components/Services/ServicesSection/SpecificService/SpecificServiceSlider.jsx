/*
/*
Component: SpecificServiceSlider

1. Retrieves the selected service from `localStorage` to fetch slider content from `SpecificService.json`.
2. Loads heading and description from `SpecificService.json` using the selected service key.
3. Extracts slider card data for the selected service and initializes a `ref` to control the slider.
4. Uses `React.useState` to track slide progress and updates on every slide change.
5. Implements `react-slick` with custom settings: autoplay, responsive breakpoints, and custom navigation.
6. Renders slider cards with an image, title, and description inside a styled `Stack` with animations.
7. Displays a `LinearProgress` bar below the slider to indicate active slide based on the index.
8. Provides navigation arrows for manual slide control using `slickPrev` and `slickNext`.
9. Uses `sx` and `Stack` for responsive layout, hover effects, and theme consistency.
10. Gracefully handles missing data, rendering only if slider data exists for the selected service.
*/

import React from "react";
import Slider from "react-slick";
import {
  Box,
  Typography,
  LinearProgress,
  Stack,
  IconButton,
} from "@mui/material";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import ArrowBack from "@mui/icons-material/ArrowBack";
import ArrowForward from "@mui/icons-material/ArrowForward";
import serviceSliderBG from "../../../images/Portfolio-Background.png";
import SpecificServiceData from "./SpecificService.json";

const SpecificServiceSlider = () => {
  const selectedService =
    localStorage.getItem("selectedService")?.trim() || null; //Fetching Specific Service slider data from Services.json file

  const allServicesData =
    SpecificServiceData?.services?.find(
      (service) => service.title === selectedService
    )?.servicesSlider?.header || null;

  const sliderData =
    SpecificServiceData?.services?.find(
      (service) => service.title === selectedService
    )?.servicesSlider?.cardsData || null;

  const sliderRef = React.useRef(null);
  const progressLength = sliderData?.length;
  const [progress, setProgress] = React.useState(100 / progressLength); // Step progress

  const [currentIndex, setCurrentIndex] = React.useState(0);
  const progressPerSlide = 100 / progressLength;

  React.useEffect(() => {
    setProgress((currentIndex + 1) * progressPerSlide);
  }, [currentIndex, progressPerSlide]); // Update progress when index changes

  // Slider settings
  const settings = {
    dots: false,
    infinite: true,
    arrows: false,
    speed: 800,
    autoplay: true,
    autoplaySpeed: 3000,
    slidesToShow: 3,
    slidesToScroll: 1,
    pauseOnHover: true,
    responsive: [
      { breakpoint: 1340, settings: { slidesToShow: 2, slidesToScroll: 1 } },
      { breakpoint: 900, settings: { slidesToShow: 1, slidesToScroll: 1 } },
    ],
    afterChange: (index) => setCurrentIndex(index), // Store index separately
  };

  return (
    <>
      {sliderData?.length > 0 && (
        <Box
          mb={20}
          sx={{
            textAlign: "center",
            mt: 4,
            backgroundImage: `url(${serviceSliderBG})`, // Correct syntax
            backgroundSize: "cover", // Ensures the image covers the entire box
            backgroundPosition: "center", // Centers the image
            backgroundRepeat: "no-repeat", // Prevents repeating
          }}
          mx={[2.2, 2.2, 1]}
        >
          {/* heading  */}
          <Typography fontSize={"var(--heading)"} fontWeight="bold" color="">
            {allServicesData?.heading}
          </Typography>

          {/* Description  */}
          <Typography
            fontSize={"var(--description)"}
            sx={{ mt: 1, color: "gray" }}
          >
            {allServicesData?.description}
          </Typography>

          {/* Slider Section  */}
          <Box
            mx={[1, 1, 10, 20]}
            sx={{
              mt: 6,
              position: "relative",
              "&:hover": {
                cursor: "grabbing",
              },
            }}
          >
            <Slider ref={sliderRef} {...settings}>
              {sliderData?.map((card, index) => (
                // Single slider card
                <Stack
                  data-aos="flip-left"
                  direction={"column"}
                  justifyContent={"center"}
                  alignItems={"center"}
                  border={"5px solid var(--color-primary)"}
                  my={3}
                  key={index}
                  sx={{
                    p: 3,
                    borderRadius: "var(--radius)",
                    boxShadow: 3,
                    backgroundColor: "#fff",
                    minHeight: "300px",
                  }}
                  maxWidth={300}
                >
                  <Box height={80} width={80} mx={"auto"}>
                    {card?.image && (
                      <img
                        src={card?.image}
                        alt={card?.title}
                        style={{
                          width: "100%",
                          height: "100%",
                        }}
                      />
                    )}
                  </Box>
                  <Typography
                    variant="h6"
                    fontWeight="bold"
                    sx={{ mt: 2 }}
                    color="black"
                  >
                    {card?.title}
                  </Typography>
                  <Typography sx={{ mt: 1, color: "gray" }}>
                    {card?.description}
                  </Typography>
                </Stack>
              ))}
            </Slider>
          </Box>

          {/* Progress Bar */}
          <LinearProgress
            variant="determinate"
            value={progress}
            sx={{
              maxWidth: "50%",
              mx: "auto",
              mt: 3,
              height: 8,
              borderRadius: "var(--radius)",
              backgroundColor: "#e0e0e0",
            }}
          />

          {/* Navigation Buttons */}
          <Stack
            mt={2}
            direction={"row"}
            alignItems={"center"}
            justifyContent={"center"}
            gap={1}
          >
            <IconButton
              sx={{
                bgcolor: "var(--color-primary-hover)",
                color: "white",
                "&:hover": {
                  bgcolor: "var(--color-primary)",
                  color: "white",
                },
              }}
              onClick={() => sliderRef.current.slickPrev()}
            >
              <ArrowBack />
            </IconButton>
            <IconButton
              sx={{
                bgcolor: "var(--color-primary-hover)",
                color: "white",
                "&:hover": {
                  bgcolor: "var(--color-primary)",
                  color: "white",
                },
              }}
              onClick={() => sliderRef.current.slickNext()}
            >
              <ArrowForward />
            </IconButton>
          </Stack>
        </Box>
      )}
    </>
  );
};

export default SpecificServiceSlider;
