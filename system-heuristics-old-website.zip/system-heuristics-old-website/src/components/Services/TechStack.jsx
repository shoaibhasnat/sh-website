/*
Component: TechStack (Technology Showcase with Tabs)

1. Fetches categorized `technologies` data from `Services.json`.
2. Initializes "Frameworks" as the default selected tab using `useState`.
3. Uses MUI’s `useMediaQuery` to make tabs scrollable on small screens.
4. Plays a looping background video for a modern visual effect.
5. Displays a heading and subheading with high contrast over the video.
6. Renders category tabs dynamically from `technologies` object keys.
7. Switches content based on the active tab to show relevant technologies.
8. Displays tech items as icon-based cards in a responsive grid.
9. Applies custom border radius and box shadow for aesthetic appeal.
10. Uses AOS animations (`data-aos`) for smooth tab and card transitions.
*/

import React, { useState } from "react";
import {
  Tabs,
  Tab,
  Box,
  Typography,
  Stack,
  useMediaQuery,
} from "@mui/material";
import SpecificServiceData from "./Services.json";

const TechStack = () => {
  const technologies = SpecificServiceData?.technologies || null; //Getting data from json
  const [value, setValue] = useState("Frameworks"); //By default Frameworks tab selected
  const isSmallScreen = useMediaQuery("(max-width:400px)"); // Set width for small screen

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    //Parent Box
    <Box
      sx={{
        width: "100%",
        textAlign: "center",
        padding: "20px",
        backgroundAttachment: "fixed",
      }}
      mb={-1}
      position={"relative"}
    >
      {/* Background video */}
      <video
        autoPlay
        loop
        loading="lazy"
        muted
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          objectFit: "cover",
          zIndex: -1,
        }}
      >
        <source src="/images/Neon-Sphere.mp4" type="video/mp4" />
        {/* <source src="/images/Neon-Pattern.mp4" type="video/mp4" /> */}
        Your browser does not support the video tag.
      </video>
      {/* Content */}
      <Typography
        fontSize={"var(--heading)"}
        fontWeight="bold"
        gutterBottom
        color="white"
        mt={5}
      >
        Technologies
      </Typography>
      <Typography
        fontSize={"var(--description)"}
        sx={{ color: "whitesmoke" }}
        gutterBottom
      >
        Our comprehensive range of expertise empowers businesses to seize new
        opportunities and achieve remarkable results.
      </Typography>

      {/* Tabs Bar  */}
      <Stack
        direction={"row"}
        justifyContent={"center"}
        alignItems={"center"}
        borderRadius={"var(--rounded)"}
        mx={["0%", "auto", "auto"]}
        width={["100%", "80%", "50%"]}
        backgroundColor={"#EAEAEA"}
        mt={8}
      >
        <Tabs
          value={value}
          onChange={handleChange}
          variant={isSmallScreen ? "scrollable" : "standard"} // Apply scrollable only on small screens
          scrollButtons={isSmallScreen} // Enable scroll buttons only if the screen is small
          allowScrollButtonsMobile={isSmallScreen} // Enable mobile scroll buttons only on small screens
          sx={{
            display: "flex",
            justifyContent: {
              xs: "center",
              md: "space-between",
            },
            "& .MuiTabs-indicator": {
              // display: "none",
              height: 5,
            },
            "& .MuiTab-root": {
              borderRadius: "30px",
              padding: "10px 20px",
              margin: {
                xs: "5px",
                md: "10px",
              },
              fontWeight: "bold",
              fontSize: {
                xs: 14,
                md: 18,
              },
              textTransform: "none",
              color: "black",
              "&:hover": {
                color: "var(--color-primary)",
              },
            },
          }}
        >
          {/* Tabs  */}
          {Object.keys(technologies)?.map((category) => (
            <Tab
              key={category}
              label={category}
              value={category}
              data-aos="zoom-in"
            />
          ))}
        </Tabs>
      </Stack>

      {/* Tech Stack  */}
      <Stack
        py={[3, 3, 5]}
        direction={"row"}
        justifyContent="center"
        alignItems={"center"}
        sx={{ marginTop: "20px" }}
        gap={[3, 3, 5, 8]}
        flexWrap={"wrap"}
      >
        {technologies[value]?.map((tech, index) => (
          // Single Tech Stack
          <Stack
            data-aos="flip-down"
            boxShadow={3}
            p={2}
            key={index}
            justifyContent="center"
            alignItems={"center"}
            gap={1}
            minHeight={120}
            minWidth={120}
            sx={{
              borderTopLeftRadius: 30,
              borderBottomRightRadius: 30,
            }}
            bgcolor={"white"}
          >
            <Box minHeight={50} minWidth={50} maxWidth={140}>
              <img
                src={tech.icon}
                alt={tech.name}
                width={"100%"}
                height={60}
                // loading="lazy"
              />
            </Box>
            {/* <LazyLoadImage src={tech.icon} alt={tech.name} /> */}
            <Typography variant="body1" fontWeight="bold" color="black">
              {tech.name}
            </Typography>
          </Stack>
        ))}
      </Stack>
    </Box>
  );
};

export default TechStack;
