/*
Component Description: Entry Point (index.js / main.js)

1. Main entry file using React 18's `createRoot` API.
2. Renders the app inside the `root` element in `public/index.html`.
3. Wraps the app in `<BrowserRouter>` for client-side routing.
4. Uses `<React.StrictMode>` to highlight potential development issues.
5. Wraps `<App />` in MUI's `Box` for layout consistency (max width 1550px).
6. `App` component handles routes, theming, and layout structure.
7. Ensures uniform responsive layout across all pages.
8. Imports MUI and React Router for styling and navigation.
*/

import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { BrowserRouter } from "react-router-dom";
import { Box } from "@mui/material";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <BrowserRouter>
    <React.StrictMode>
      <Box maxWidth={"1550px"} mx={"auto"}>
        <App />
      </Box>
    </React.StrictMode>
  </BrowserRouter>
);
