// Importing Main ABout Component

import React from "react";
import Main from "../components/About/Main";

function About() {
  return (
    <>
      <Main />
    </>
  );
}

export default About;
