// Importing Main Careers Component

import React from "react";
import Main from "../components/Careers/Main";

function Careers() {
  return (
    <>
      <Main />
    </>
  );
}

export default Careers;
