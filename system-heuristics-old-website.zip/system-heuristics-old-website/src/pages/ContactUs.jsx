// Importing Main ContactUs Component

import React from "react";
import Main from "../components/ContactUs/Main";

function ContactUs() {
  return (
    <>
      <Main />
    </>
  );
}

export default ContactUs;
