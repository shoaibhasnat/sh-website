// Importing Main Industries Component

import React from "react";
import Main from "../../components/Industries/Main";

function Industries() {
  return (
    <>
      <Main />
    </>
  );
}

export default Industries;
