// Importing Specific Industries Component

import React from "react";

import Main from "../../components/Industries/IndustrySection/SpecificIndustry/Main";

function HealthCare() {
  return <Main />;
}

export default HealthCare;
