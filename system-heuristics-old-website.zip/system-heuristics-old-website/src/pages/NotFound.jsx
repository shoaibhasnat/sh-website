/*
Component Description: NotFound

1. Acts as a fallback component for undefined or non-existent routes, displaying a user-friendly 404 page.
2. Uses the `useNavigate` hook from React Router to allow redirection when the "Go Back" button is clicked.
3. The `navigate(-1)` function navigates the user to the previous page in their browsing history.
4. Displays a large 404 heading with a descriptive message to inform users that the page doesn't exist.
5. Includes a "Go Back" button styled using MUI that allows users to return easily to the previous page.
6. The entire layout is centered vertically and horizontally using Flexbox and fills the full viewport height.
7. Adds padding and background color for better spacing and a light neutral background tone (`#f8f9fa`).
8. Text elements use different MUI `Typography` variants for visual hierarchy and clarity.
9. Inline styling via `sx` is used to control color, spacing, and layout responsiveness.
10. This component is typically mapped to a wildcard route (`*`) in the React Router configuration.
*/

import React from "react";
import { Box, Typography, Button } from "@mui/material";
import { useNavigate } from "react-router-dom";

const NotFound = () => {
  const navigate = useNavigate();

  const handleGoBack = () => {
    navigate(-1); // Navigates to the previous page
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        height: "100vh",
        textAlign: "center",
        bgcolor: "#f8f9fa",
        p: 2,
      }}
    >
      <Typography variant="h1" sx={{ fontWeight: "bold", color: "#1976d2" }}>
        404
      </Typography>
      <Typography variant="h5" sx={{ mb: 2, color: "#555" }}>
        Oops! Page Not Found
      </Typography>
      <Typography variant="body1" sx={{ mb: 4, color: "#777" }}>
        The page you are looking for doesn't exist or has been moved.
      </Typography>
      <Button
        variant="contained"
        color="primary"
        size="large"
        onClick={handleGoBack}
        sx={{
          textTransform: "none",
          borderRadius: "12px",
          px: 3,
          py: 1.5,
        }}
      >
        Go Back
      </Button>
    </Box>
  );
};

export default NotFound;
