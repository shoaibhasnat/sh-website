// Importing Main Portfolio Component

import React from "react";
import Main from "../../components/Portfolio/Main";

function Portfolio() {
  return (
    <>
      <Main />
    </>
  );
}

export default Portfolio;
