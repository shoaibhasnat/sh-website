// Importing Specific Portfolio Component

import React from "react";
import Main from "../../components/Portfolio/SpecificProject/Main";
import NotFound from "../NotFound";
import { useParams } from "react-router-dom";
import PortfolioData from "../../components/Portfolio/SpecificProject/SpecificProject.json";

function SpecificProject() {
  const { projectId } = useParams();
  const project = PortfolioData?.projects?.find(
    (p) => p.id === parseInt(projectId)
  );

  if (!project) {
    return <NotFound />;
  }

  return <Main />;
}

export default SpecificProject;
