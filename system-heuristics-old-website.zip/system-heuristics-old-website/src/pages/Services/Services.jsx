// Importing Main Services Component

import React from "react";
import Main from "../../components/Services/Main";

function Services() {
  return (
    <>
      <Main />
    </>
  );
}

export default Services;
