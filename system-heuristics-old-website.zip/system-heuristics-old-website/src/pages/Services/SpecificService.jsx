// Importing Specific Services Component

import React from "react";
import Main from "../../components/Services/ServicesSection/SpecificService/Main";

function SpecificService() {
  return <Main />;
}

export default SpecificService;
