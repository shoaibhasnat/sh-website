import React from "react";
import { Dialog, DialogContent, Typography, Box } from "@mui/material";
import ConstructionIcon from "@mui/icons-material/Construction";

const UnderDevelopment = () => {
  const handleNavigate = () => {
    window.location.href = "/home";
  };

  return (
    <Dialog open={true} fullScreen>
      <DialogContent
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          height: "100vh",
          textAlign: "center",
          backgroundColor: "var(--color-primary)",
        }}
      >
        <Box>
          <ConstructionIcon
            onClick={handleNavigate}
            sx={{ fontSize: 80, color: "white" }}
          />
          <Typography
            variant="h4"
            sx={{ mt: 2, fontWeight: "bold", color: "white" }}
          >
            Website Under Development
          </Typography>
          <Typography variant="body1" sx={{ mt: 1, color: "white" }}>
            We are working hard to bring you an amazing experience. Stay tuned!
          </Typography>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default UnderDevelopment;
